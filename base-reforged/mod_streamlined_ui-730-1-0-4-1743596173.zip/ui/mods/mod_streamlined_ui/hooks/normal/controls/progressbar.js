SUI.Generic.wrapWithCache('changeProgressbarLabel');

SUI.Generic.wrapWithCache('changeProgressbarNormalWidth', 'sui', SUI.Generic.__wrapProgressBarWidth);
SUI.Generic.wrapWithCache('changeProgressbarPreviewWidth', 'sui', SUI.Generic.__wrapProgressBarWidth);

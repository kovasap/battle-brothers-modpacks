SUI.Generic.wrapWithCache('setRepairImageVisible');
SUI.Generic.wrapWithCache('assignListItemImage');
SUI.Generic.wrapWithCache('assignListItemOverlayImage');
SUI.Generic.wrapWithCache('assignListItemAmount');
SUI.Generic.wrapWithCache('assignListItemPrice');
SUI.Generic.wrapWithCache('assignListItemPriceColor');

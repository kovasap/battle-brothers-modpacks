SUI.Generic.wrapWithCache('assignListBrotherImage');
SUI.Generic.wrapWithCache('showListBrotherLockImage');
SUI.Generic.wrapWithCache('showListBrotherMoodImage');
SUI.Generic.wrapWithCache('assignListBrotherDailyMoneyCost');
SUI.Generic.wrapWithCache('assignListBrotherName');

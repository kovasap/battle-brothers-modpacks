SUI.Generic.wrapWithCache('setPaperdollRepairImageVisible');
SUI.Generic.wrapWithCache('assignPaperdollItemImage');
SUI.Generic.wrapWithCache('assignPaperdollItemOverlayImage');
SUI.Generic.wrapWithCache('showPaperdollLockedImage');
SUI.Generic.wrapWithCache('assignPaperdollItemAmount');

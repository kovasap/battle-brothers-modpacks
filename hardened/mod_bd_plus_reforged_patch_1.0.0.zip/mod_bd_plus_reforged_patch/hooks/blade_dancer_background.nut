::modBDPRF.HooksMod.hook("scripts/skills/backgrounds/blade_dancer_background", function(q) {
	q.createPerkTreeBlueprint = @() function()
	{
		return ::new(::DynamicPerks.Class.PerkTree).init({
			DynamicMap = {
				"pgc.rf_exclusive_1": @(_perkTree) [
					::MSU.Class.WeightedContainer([
						[25, "pg.rf_knave"],
						[50, "pg.rf_raider"],
						[10, "pg.rf_soldier"],
						[15, "pg.rf_trapper"]
					]).roll()
				],
				"pgc.rf_shared_1": [],
				"pgc.rf_weapon": [],
				"pgc.rf_armor": [
					"pg.rf_light_armor",
					"pg.rf_medium_armor"
				],
				"pgc.rf_fighting_style": []
			}
		});
	}

	q.getPerkGroupCollectionMin = @() { function getPerkGroupCollectionMin( _collection )
	{
		switch (_collection.getID())
		{
			case "pgc.rf_weapon":
			case "pgc.rf_fighting_style":
				return _collection.getMin() + 1;
		}
	}}.getPerkGroupCollectionMin;

	q.getPerkGroupMultiplier = @(__original) function( _groupID, _perkTree )
	{
		switch(_groupID)
		{
			case "pg.rf_agile":
			case "pg.rf_fast":
				return 3;

			case "pg.rf_tactician":
			case "pg.rf_trained":
			case "pg.rf_vicious":
				return 2;

			case "pg.rf_tough":
				return 0.75;

			case "pg.rf_vigorous":
				return 0.5;

			case "pg.rf_dagger":
			case "pg.rf_flail":
			case "pg.rf_hammer":
			case "pg.rf_mace":
			case "pg.rf_spear":
			case "pg.special.rf_leadership":
				return 0;

			default:
				return __original(_groupID, _perkTree);
		}
	}
});

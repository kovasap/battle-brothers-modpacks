::modBDPRF.HooksMod.hook("scripts/skills/backgrounds/priest_background", function(q) {
	q.createPerkTreeBlueprint = @() function()
	{
		return ::new(::DynamicPerks.Class.PerkTree).init({
			DynamicMap = {
				"pgc.rf_exclusive_1": [],
				"pgc.rf_shared_1": [],
				"pgc.rf_weapon": [],
				"pgc.rf_armor": [],
				"pgc.rf_fighting_style": []
			}
		});
	}

	q.getPerkGroupCollectionMin = @() { function getPerkGroupCollectionMin( _collection )
	{
		switch (_collection.getID())
		{
			case "pgc.rf_armor":
			case "pgc.rf_fighting_style":
				return _collection.getMin() - 1;
		}
	}}.getPerkGroupCollectionMin;

	q.getPerkGroupMultiplier = @(__original) function( _groupID, _perkTree )
	{
		switch(_groupID)
		{
			case "pg.special.rf_leadership": // Leadership group guaranteed
				return -1;

			case "pg.rf_vicious":
			case "pg.rf_vigorous":
			case "pg.rf_heavy_armor":
				return 0.5;

			default:
				return __original(_groupID, _perkTree);
		}
	}
});

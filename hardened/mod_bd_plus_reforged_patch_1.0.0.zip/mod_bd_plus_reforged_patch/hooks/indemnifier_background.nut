::modBDPRF.HooksMod.hook("scripts/skills/backgrounds/indemnifier_background", function(q) {
	q.createPerkTreeBlueprint = @() function()
	{
		return ::new(::DynamicPerks.Class.PerkTree).init({
			DynamicMap = {
				"pgc.rf_exclusive_1": [
					"pg.rf_laborer"
				],
				"pgc.rf_shared_1": [],
				"pgc.rf_weapon": [],
				"pgc.rf_armor": [],
				"pgc.rf_fighting_style": []
			}
		});
	}

	q.getPerkGroupCollectionMin = @() { function getPerkGroupCollectionMin( _collection )
	{
		switch (_collection.getID())
		{
			case "pgc.rf_weapon":
			case "pgc.rf_fighting_style":
				return _collection.getMin() + 1;
		}
	}}.getPerkGroupCollectionMin;

	q.getPerkGroupMultiplier = @(__original) function( _groupID, _perkTree )
	{
		switch(_groupID)
		{
			case "pg.special.rf_discovered_talent":
			case "pg.special.rf_gifted":
			case "pg.special.rf_rising_star":
			case "pg.rf_dagger":
			case "pg.special.rf_leadership":
				return 0;

			case "pg.rf_fast":
				return 0.5;

			case "pg.rf_tough":
				return 2;

			case "pg.rf_vigorous":
				return 2.5;

			default:
				return __original(_groupID, _perkTree);
		}
	}
});

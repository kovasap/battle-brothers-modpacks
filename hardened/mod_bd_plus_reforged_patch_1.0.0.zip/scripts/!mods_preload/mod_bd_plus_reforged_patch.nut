::modBDPRF <- {
	ID = "mod_bd_plus_reforged_patch",
	Name = "Blazing Deserts Plus and Reforged Patch",
	Version = "1.0.0"
}

::modBDPRF.HooksMod <- ::Hooks.register(::modBDPRF.ID, ::modBDPRF.Version, ::modBDPRF.Name);
::modBDPRF.HooksMod.require(["mod_msu", "mod_reforged"]);
::modBDPRF.HooksMod.queue(">mod_reforged" ,">mod_msu", function() {
	::modBDPRF.Mod <- ::MSU.Class.Mod(::modBDPRF.ID, ::modBDPRF.Version, ::modBDPRF.Name);

	// // Add an official mod source and turn on automatic in-game reminder about new updates
	// ::modBDPRF.Mod.Registry.addModSource(::MSU.System.Registry.ModSourceDomain.GitHub, "https://github.com/Sile735/mod_backgrounds_reforged_compatibility");
	// ::modBDPRF.Mod.Registry.setUpdateSource(::MSU.System.Registry.ModSourceDomain.GitHub);

	foreach (file in ::IO.enumerateFiles("mod_bd_plus_reforged_patch"))
	{
		::include(file);
	}
});

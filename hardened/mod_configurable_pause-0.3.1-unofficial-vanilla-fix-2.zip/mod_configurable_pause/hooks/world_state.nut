::ConfigurablePause.MH.hook("scripts/states/world_state", function(q) {
	q.m.ConfigurablePause_Pause <- false;
	q.m.ConfigurablePause_OldDestination <- null;
	q.m.ConfigurablePause_OldPath <- null;
	q.m.ConfigurablePause_LastPauseOnSeeEnemy <- 0.0;
	q.m.ConfigurablePause <- {
		LastPauseOnSeeEnemy = 0.0,
		IsInThread = false
	};

	q.onInit = @(__original) function() {
		__original();
		this.m.Flags.add(::ConfigurablePause.FlagID.WasDay, false)
	}

	q.setEscortedEntity = @(__original) function( _entity, _fastEscort = false ) {
		local ret = __original(_entity, _fastEscort);
		if (_entity != null && this.m.EscortedEntity != null) {
			this.m.Player.m.ConfigurablePause_PausedTile = this.m.EscortedEntity.getTile();
		}
	}

	q.onUpdate = @(__original) function() {
		local oldPath = this.m.ConfigurablePause_OldPath;
		local newPath = this.getPlayer().getPath();
		local oldDest = this.m.ConfigurablePause_OldDestination;
		local newDest = this.getPlayer().m.Destination;

		if ((oldPath != newPath && newPath != null) || (newPath == null && oldDest != newDest && newDest != null)) {
			if (::ConfigurablePause.Mod.ModSettings.getSetting("UnpauseOnNewDestination").getValue()) {
				this.setPause(false);
			}
		} else if ((oldPath != null || oldDest != null) && (newPath == null && newDest == null)) {
			if (::ConfigurablePause.Mod.ModSettings.getSetting("PauseOnArrival").getValue()) {
				this.setPause(true);
			}
		}
		this.m.ConfigurablePause_OldDestination = newDest;
		this.m.ConfigurablePause_OldPath = newPath;

		if (this.m.ConfigurablePause_Pause) {
			this.setPause(true);
			this.m.ConfigurablePause_Pause = false;
		}

		local ret = __original();
		local isDayTime = ::World.getTime().IsDaytime;

		if (::ConfigurablePause.Mod.ModSettings.getSetting("PauseOnCampingNewDay").getValue()) {
			if (isDayTime && this.m.Flags.get(::ConfigurablePause.FlagID.WasDay) != isDayTime) {
				if (::World.Assets.isCamping()) {
					this.setPause(true);
				}
			}
		}

		if (::ConfigurablePause.Mod.ModSettings.getSetting("PauseOnCampingNewNight").getValue()) {
			if (!isDayTime && this.m.Flags.get(::ConfigurablePause.FlagID.WasDay) != isDayTime) {
				if (::World.Assets.isCamping()) {
					this.setPause(true);
				}
			}
		}
		this.m.Flags.set(::ConfigurablePause.FlagID.WasDay, ::World.getTime().IsDaytime);

		return ret;
	}

	q.setPause = @(__original) function( _f ) {
		if (_f || this.m.ConfigurablePause_LastPauseOnSeeEnemy + ::ConfigurablePause.Mod.ModSettings.getSetting("DelayBeforeUnpause").getValue() < ::Time.getExactTime()) {
			return __original(_f);
		}
	}

	q.onProcessInThread = @(__original) function() {
		this.m.ConfigurablePause.IsInThread = true;
		local ret = __original()
		this.m.ConfigurablePause.IsInThread = false;
		return ret;
	}

	q.ConfigurablePause_setPause <- function( _f ) {
		this.m.ConfigurablePause_Pause = _f;
	}
})

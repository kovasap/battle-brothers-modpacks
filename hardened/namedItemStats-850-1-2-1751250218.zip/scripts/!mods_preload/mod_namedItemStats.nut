::modNamedItemStats <- {
	Version = "1.2",
	ID = "namedItemStats",
	Name = "Named Item Stats",
};

::modNamedItemStats.HooksMod <- ::Hooks.register(::modNamedItemStats.ID, ::modNamedItemStats.Version, ::modNamedItemStats.Name);

::modNamedItemStats.HooksMod.queue(">mod_msu", function() {

	::modNamedItemStats.HooksMod.hook("scripts/items/weapons/named/named_weapon", function(q) {

		q.m.NISConditionOrig <- null;
		q.m.NISRegularDamageOrig <- null;
		q.m.NISRegularDamageMaxOrig <- null;
		q.m.NISDirectDamageMultOrig <- null;
		q.m.NISDirectDamageAddOrig <- null;
		q.m.NISArmorDamageMultOrig <- null;
		q.m.NISShieldDamageOrig <- null;
		q.m.NISChanceToHitHeadOrig <- null;
		q.m.NISAdditionalAccuracyOrig <- null;
		q.m.NISStaminaModifierOrig <- null;
		q.m.NISFatigueOnSkillUseOrig <- null;
		q.m.NISAmmoOrig <- null;

		q.randomizeValues = @(__original) function()
		{
			this.m.NISConditionOrig = this.m.Condition;
			this.m.NISRegularDamageOrig = this.m.RegularDamage;
			this.m.NISRegularDamageMaxOrig = this.m.RegularDamageMax;
			this.m.NISDirectDamageMultOrig = this.m.DirectDamageMult;
			this.m.NISDirectDamageAddOrig = this.m.DirectDamageAdd;
			this.m.NISArmorDamageMultOrig = this.m.ArmorDamageMult;
			this.m.NISShieldDamageOrig = this.m.ShieldDamage;
			this.m.NISChanceToHitHeadOrig = this.m.ChanceToHitHead;
			this.m.NISAdditionalAccuracyOrig = this.m.AdditionalAccuracy;
			this.m.NISStaminaModifierOrig = this.m.StaminaModifier;
			this.m.NISFatigueOnSkillUseOrig = this.m.FatigueOnSkillUse;
			this.m.NISAmmoOrig = this.m.Ammo;
			local ret = __original();
			return ret;
		}

		q.getTooltip = @(__original) function()
		{
			local ret = __original();
			local rangeText = "Named Weapon Ranges:";

			local condOriginal = this.m.NISConditionOrig;
			if(condOriginal != null && condOriginal > 1)
			{
				rangeText += "\n- Durability: " + this.Math.round(condOriginal * 0.9) + " to " + this.Math.round(condOriginal * 1.4);
			}
			local regularDamageOrig = this.m.NISRegularDamageOrig;
			local regularDamageMaxOrig = this.m.NISRegularDamageMaxOrig;
			if(regularDamageOrig != null && regularDamageOrig != this.m.RegularDamage)
			{
				rangeText += "\n- Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.1) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageMaxOrig * 1.1) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.3) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + Math.round(regularDamageMaxOrig * 1.3) + "[/color]";
			}
			local directDamageAddOrig = this.m.NISDirectDamageAddOrig;
			local directDamageMultOrig = this.m.NISDirectDamageMultOrig;
			if(directDamageAddOrig != null && this.Math.round(directDamageAddOrig*1000) != this.Math.round(this.m.DirectDamageAdd*1000))
			{
				rangeText += "\n- Armor Ignore: [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.08) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.16) * 100) + "%[/color]";
			}
			local armorDamageMultOrig = this.m.NISArmorDamageMultOrig;
			if(armorDamageMultOrig != null && this.Math.round(armorDamageMultOrig*1000) != this.Math.round(this.m.ArmorDamageMult*1000))
			{
				rangeText += "\n- Armor Effectiveness: [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.1) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.3) * 100) + "%[/color]";
			}
			local shieldDamageOrig = this.m.NISShieldDamageOrig;
			if (shieldDamageOrig != null && shieldDamageOrig != this.m.ShieldDamage)
			{
				rangeText += "\n- Shield Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 1.5) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 2.0) + "[/color]";
			}
			local chanceToHitHeadOrig = this.m.NISChanceToHitHeadOrig;
			if (chanceToHitHeadOrig != null && chanceToHitHeadOrig != this.m.ChanceToHitHead)
			{
				rangeText += "\n- Head Hit Chance: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 10) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 20) + "%[/color]";
			}
			local additionalAccuracyOrig = this.m.NISAdditionalAccuracyOrig;
			if (additionalAccuracyOrig != null && additionalAccuracyOrig != this.m.AdditionalAccuracy)
			{
				rangeText += "\n- Hit Bonus: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 5) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 15) + "%[/color]";
			}
			local staminaModifierOrig = this.m.NISStaminaModifierOrig;
			if (staminaModifierOrig != null && staminaModifierOrig != this.m.StaminaModifier)
			{
				rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.8) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.5) + "[/color]";
			}
			local fatigueOnSkillUseOrig = this.m.NISFatigueOnSkillUseOrig;
			if (fatigueOnSkillUseOrig != null && fatigueOnSkillUseOrig != this.m.FatigueOnSkillUse)
			{
				rangeText += "\n- Skill Use Fatigue: [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 1) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 3) + "[/color]";
			}
			local ammoOrig = this.m.NISAmmoOrig;
			if (ammoOrig != null && ammoOrig != this.m.Ammo)
			{
				rangeText += "\n- Ammo: [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 1) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 3) + "[/color]";
			}
			ret.push({
				id = 4,
				type = "text",
				icon = "ui/icons/special.png",
				text = rangeText
			});
			return ret;
		}
	});

	::modNamedItemStats.HooksMod.hook("scripts/items/armor/named/named_armor", function(q) {

		q.m.NISConditionOrig <- null;
		q.m.NISStaminaModifierOrig <- null;

		q.randomizeValues = @(__original) function()
		{
			this.m.NISConditionOrig = this.m.Condition;
			this.m.NISStaminaModifierOrig = this.m.StaminaModifier;
			local ret = __original();
			return ret;
		}

		q.getTooltip = @(__original) function()
		{
			local ret = __original();
			local rangeText = "Named Armor Ranges:";

			local condOriginal = this.m.NISConditionOrig;
			if(condOriginal != null)
			{
				rangeText += "\n- Durability: " + this.Math.floor(condOriginal * 1.1) + " to " + this.Math.floor(condOriginal * 1.25);
			}

			local stamOriginal = this.m.NISStaminaModifierOrig;
			if(stamOriginal != null)
			{
				rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.min(-8, stamOriginal + 3) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.min(-8, stamOriginal + 9) + "[/color]";
			}
			ret.push({
				id = 4,
				type = "text",
				icon = "ui/icons/special.png",
				text = rangeText
			});
			return ret;
		}
	});

	::modNamedItemStats.HooksMod.hook("scripts/items/helmets/named/named_helmet", function(q) {

		q.m.NISConditionOrig <- null;
		q.m.NISStaminaModifierOrig <- null;
		
		q.randomizeValues = @(__original) function()
		{
			this.m.NISConditionOrig = this.m.Condition;
			this.m.NISStaminaModifierOrig = this.m.StaminaModifier;
			local ret = __original();
			return ret;
		}

		q.getTooltip = @(__original) function()
		{
			local ret = __original();
			local rangeText = "Named Helmet Ranges:";

			local condOriginal = this.m.NISConditionOrig;
			if(condOriginal != null)
			{
				rangeText += "\n- Durability: " + this.Math.floor(condOriginal * 1.1) + " to " + this.Math.floor(condOriginal * 1.25);
			}

			local stamOriginal = this.m.NISStaminaModifierOrig;
			if(stamOriginal != null)
			{
				rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.min(-4, stamOriginal + 1) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.min(-4, stamOriginal + 4) + "[/color]";
			}
			ret.push({
				id = 4,
				type = "text",
				icon = "ui/icons/special.png",
				text = rangeText
			});
			return ret;
		}
	});

	::modNamedItemStats.HooksMod.hook("scripts/items/shields/named/named_shield", function(q) {

		q.m.NISConditionOrig <- null;
		q.m.NISMeleeDefenseOrig <- null;
		q.m.NISRangedDefenseOrig <- null;
		q.m.NISFatigueOnSkillUseOrig <- null;
		q.m.NISStaminaModifierOrig <- null;
		
		q.randomizeValues = @(__original) function()
		{
			this.m.NISConditionOrig = this.m.Condition;
			this.m.NISMeleeDefenseOrig = this.m.MeleeDefense;
			this.m.NISRangedDefenseOrig = this.m.RangedDefense;
			this.m.NISFatigueOnSkillUseOrig = this.m.FatigueOnSkillUse;
			this.m.NISStaminaModifierOrig = this.m.StaminaModifier;
			local ret = __original();
			return ret;
		}

		q.getTooltip = @(__original) function()
		{
			local ret = __original();
			local rangeText = "Named Shield Ranges:";

			local condOriginal = this.m.NISConditionOrig;
			if(condOriginal != null && condOriginal != this.m.ConditionMax)
			{
				rangeText += "\n- Durability: " + this.Math.round(condOriginal * 1.2) + " to " + this.Math.round(condOriginal * 1.6);
			}
			local meleeDefenseOriginal = this.m.NISMeleeDefenseOrig;
			if(meleeDefenseOriginal != null && meleeDefenseOriginal != this.m.MeleeDefense)
			{
				rangeText += "\n- Melee Defense: [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(meleeDefenseOriginal * 1.2) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(meleeDefenseOriginal * 1.4) + "[/color]";
			}
			local rangedDefenseOriginal = this.m.NISRangedDefenseOrig;
			if(rangedDefenseOriginal != null && rangedDefenseOriginal != this.m.RangedDefense)
			{
				rangeText += "\n- Ranged Defense: [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(rangedDefenseOriginal * 1.2) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(rangedDefenseOriginal * 1.4) + "[/color]";
			}
			local fatigueOnSkillUseOrig = this.m.NISFatigueOnSkillUseOrig;
			if (fatigueOnSkillUseOrig != null && fatigueOnSkillUseOrig != this.m.FatigueOnSkillUse)
			{
				rangeText += "\n- Skill Use Fatigue: [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 1) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 3) + "[/color]";
			}
			local stamOriginal = this.m.NISStaminaModifierOrig;
			if(stamOriginal != null && stamOriginal != this.m.StaminaModifier)
			{
				rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(stamOriginal * 0.9) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(stamOriginal * 0.7) + "[/color]";
			}
			ret.push({
				id = 4,
				type = "text",
				icon = "ui/icons/special.png",
				text = rangeText
			});
			return ret;
		}
	});

	//for some reason vanilla crossbow, handgonne, lindwurm helmet, and lindwurm armor overwrite the named_weapon tooltip, so have to do these manually
	::modNamedItemStats.HooksMod.hook("scripts/items/weapons/named/named_crossbow", function(q) {

		q.getTooltip = @(__original) function()
		{
			local ret = __original();
			local rangeText = "Named Weapon Ranges:";

			local condOriginal = this.m.NISConditionOrig;
			if(condOriginal != null && condOriginal > 1)
			{
				rangeText += "\n- Durability: " + this.Math.round(condOriginal * 0.9) + " to " + this.Math.round(condOriginal * 1.4);
			}
			local regularDamageOrig = this.m.NISRegularDamageOrig;
			local regularDamageMaxOrig = this.m.NISRegularDamageMaxOrig;
			if(regularDamageOrig != null && regularDamageOrig != this.m.RegularDamage)
			{
				rangeText += "\n- Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.1) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageMaxOrig * 1.1) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.3) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + Math.round(regularDamageMaxOrig * 1.3) + "[/color]";
			}
			local directDamageAddOrig = this.m.NISDirectDamageAddOrig;
			local directDamageMultOrig = this.m.NISDirectDamageMultOrig;
			if(directDamageAddOrig != null && this.Math.round(directDamageAddOrig*1000) != this.Math.round(this.m.DirectDamageAdd*1000))
			{
				rangeText += "\n- Armor Ignore: [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.08) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.16) * 100) + "%[/color]";
			}
			local armorDamageMultOrig = this.m.NISArmorDamageMultOrig;
			if(armorDamageMultOrig != null && this.Math.round(armorDamageMultOrig*1000) != this.Math.round(this.m.ArmorDamageMult*1000))
			{
				rangeText += "\n- Armor Effectiveness: [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.1) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.3) * 100) + "%[/color]";
			}
			local shieldDamageOrig = this.m.NISShieldDamageOrig;
			if (shieldDamageOrig != null && shieldDamageOrig != this.m.ShieldDamage)
			{
				rangeText += "\n- Shield Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 1.5) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 2.0) + "[/color]";
			}
			local chanceToHitHeadOrig = this.m.NISChanceToHitHeadOrig;
			if (chanceToHitHeadOrig != null && chanceToHitHeadOrig != this.m.ChanceToHitHead)
			{
				rangeText += "\n- Head Hit Chance: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 10) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 20) + "%[/color]";
			}
			local additionalAccuracyOrig = this.m.NISAdditionalAccuracyOrig;
			if (additionalAccuracyOrig != null && additionalAccuracyOrig != this.m.AdditionalAccuracy)
			{
				rangeText += "\n- Hit Bonus: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 5) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 15) + "%[/color]";
			}
			local staminaModifierOrig = this.m.NISStaminaModifierOrig;
			if (staminaModifierOrig != null && staminaModifierOrig != this.m.StaminaModifier)
			{
				rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.8) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.5) + "[/color]";
			}
			local fatigueOnSkillUseOrig = this.m.NISFatigueOnSkillUseOrig;
			if (fatigueOnSkillUseOrig != null && fatigueOnSkillUseOrig != this.m.FatigueOnSkillUse)
			{
				rangeText += "\n- Skill Use Fatigue: [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 1) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 3) + "[/color]";
			}
			local ammoOrig = this.m.NISAmmoOrig;
			if (ammoOrig != null && ammoOrig != this.m.Ammo)
			{
				rangeText += "\n- Ammo: [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 1) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 3) + "[/color]";
			}
			ret.push({
				id = 4,
				type = "text",
				icon = "ui/icons/special.png",
				text = rangeText
			});
			return ret;
		}
	});

	::modNamedItemStats.HooksMod.hook("scripts/items/weapons/named/named_handgonne", function(q) {

		q.getTooltip = @(__original) function()
		{
			local ret = __original();
			local rangeText = "Named Weapon Ranges:";

			local condOriginal = this.m.NISConditionOrig;
			if(condOriginal != null && condOriginal > 1)
			{
				rangeText += "\n- Durability: " + this.Math.round(condOriginal * 0.9) + " to " + this.Math.round(condOriginal * 1.4);
			}
			local regularDamageOrig = this.m.NISRegularDamageOrig;
			local regularDamageMaxOrig = this.m.NISRegularDamageMaxOrig;
			if(regularDamageOrig != null && regularDamageOrig != this.m.RegularDamage)
			{
				rangeText += "\n- Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.1) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageMaxOrig * 1.1) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.3) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + Math.round(regularDamageMaxOrig * 1.3) + "[/color]";
			}
			local directDamageAddOrig = this.m.NISDirectDamageAddOrig;
			local directDamageMultOrig = this.m.NISDirectDamageMultOrig;
			if(directDamageAddOrig != null && this.Math.round(directDamageAddOrig*1000) != this.Math.round(this.m.DirectDamageAdd*1000))
			{
				rangeText += "\n- Armor Ignore: [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.08) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.16) * 100) + "%[/color]";
			}
			local armorDamageMultOrig = this.m.NISArmorDamageMultOrig;
			if(armorDamageMultOrig != null && this.Math.round(armorDamageMultOrig*1000) != this.Math.round(this.m.ArmorDamageMult*1000))
			{
				rangeText += "\n- Armor Effectiveness: [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.1) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.3) * 100) + "%[/color]";
			}
			local shieldDamageOrig = this.m.NISShieldDamageOrig;
			if (shieldDamageOrig != null && shieldDamageOrig != this.m.ShieldDamage)
			{
				rangeText += "\n- Shield Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 1.5) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 2.0) + "[/color]";
			}
			local chanceToHitHeadOrig = this.m.NISChanceToHitHeadOrig;
			if (chanceToHitHeadOrig != null && chanceToHitHeadOrig != this.m.ChanceToHitHead)
			{
				rangeText += "\n- Head Hit Chance: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 10) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 20) + "%[/color]";
			}
			local additionalAccuracyOrig = this.m.NISAdditionalAccuracyOrig;
			if (additionalAccuracyOrig != null && additionalAccuracyOrig != this.m.AdditionalAccuracy)
			{
				rangeText += "\n- Hit Bonus: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 5) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 15) + "%[/color]";
			}
			local staminaModifierOrig = this.m.NISStaminaModifierOrig;
			if (staminaModifierOrig != null && staminaModifierOrig != this.m.StaminaModifier)
			{
				rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.8) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.5) + "[/color]";
			}
			local fatigueOnSkillUseOrig = this.m.NISFatigueOnSkillUseOrig;
			if (fatigueOnSkillUseOrig != null && fatigueOnSkillUseOrig != this.m.FatigueOnSkillUse)
			{
				rangeText += "\n- Skill Use Fatigue: [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 1) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 3) + "[/color]";
			}
			local ammoOrig = this.m.NISAmmoOrig;
			if (ammoOrig != null && ammoOrig != this.m.Ammo)
			{
				rangeText += "\n- Ammo: [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 1) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 3) + "[/color]";
			}
			ret.push({
				id = 4,
				type = "text",
				icon = "ui/icons/special.png",
				text = rangeText
			});
			return ret;
		}
	});

	::modNamedItemStats.HooksMod.hook("scripts/items/armor/named/lindwurm_armor", function(q) {

		q.getTooltip = @(__original) function()
		{
			local ret = __original();
			local rangeText = "Named Armor Ranges:";

			local condOriginal = this.m.NISConditionOrig;
			if(condOriginal != null)
			{
				rangeText += "\n- Durability: " + this.Math.floor(condOriginal * 1.1) + " to " + this.Math.floor(condOriginal * 1.25);
			}

			local stamOriginal = this.m.NISStaminaModifierOrig;
			if(stamOriginal != null)
			{
				rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.min(-8, stamOriginal + 3) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.min(-8, stamOriginal + 9) + "[/color]";
			}
			ret.push({
				id = 4,
				type = "text",
				icon = "ui/icons/special.png",
				text = rangeText
			});
			return ret;
		}
	});

	::modNamedItemStats.HooksMod.hook("scripts/items/helmets/named/lindwurm_helmet", function(q) {

		q.getTooltip = @(__original) function()
		{
			local ret = __original();
			local rangeText = "Named Helmet Ranges:";

			local condOriginal = this.m.NISConditionOrig;
			if(condOriginal != null)
			{
				rangeText += "\n- Durability: " + this.Math.floor(condOriginal * 1.1) + " to " + this.Math.floor(condOriginal * 1.25);
			}

			local stamOriginal = this.m.NISStaminaModifierOrig;
			if(stamOriginal != null)
			{
				rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.min(-4, stamOriginal + 1) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.min(-4, stamOriginal + 4) + "[/color]";
			}
			ret.push({
				id = 4,
				type = "text",
				icon = "ui/icons/special.png",
				text = rangeText
			});
			return ret;
		}
	});

	if( ::mods_getRegisteredMod("mod_camps_and_artifacts") != null )
	{
		::modNamedItemStats.HooksMod.hook("scripts/items/weapons/artifact/artifact_weapon", function(q) {

			q.m.NISConditionOrig <- null;
			q.m.NISRegularDamageOrig <- null;
			q.m.NISRegularDamageMaxOrig <- null;
			q.m.NISDirectDamageMultOrig <- null;
			q.m.NISDirectDamageAddOrig <- null;
			q.m.NISArmorDamageMultOrig <- null;
			q.m.NISShieldDamageOrig <- null;
			q.m.NISChanceToHitHeadOrig <- null;
			q.m.NISAdditionalAccuracyOrig <- null;
			q.m.NISStaminaModifierOrig <- null;
			q.m.NISFatigueOnSkillUseOrig <- null;
			q.m.NISAmmoOrig <- null;

			q.randomizeValues = @(__original) function()
			{
				this.m.NISConditionOrig = this.m.Condition;
				this.m.NISRegularDamageOrig = this.m.RegularDamage;
				this.m.NISRegularDamageMaxOrig = this.m.RegularDamageMax;
				this.m.NISDirectDamageMultOrig = this.m.DirectDamageMult;
				this.m.NISDirectDamageAddOrig = this.m.DirectDamageAdd;
				this.m.NISArmorDamageMultOrig = this.m.ArmorDamageMult;
				this.m.NISShieldDamageOrig = this.m.ShieldDamage;
				this.m.NISChanceToHitHeadOrig = this.m.ChanceToHitHead;
				this.m.NISAdditionalAccuracyOrig = this.m.AdditionalAccuracy;
				this.m.NISStaminaModifierOrig = this.m.StaminaModifier;
				this.m.NISFatigueOnSkillUseOrig = this.m.FatigueOnSkillUse;
				this.m.NISAmmoOrig = this.m.Ammo;
				local ret = __original();
				return ret;
			}

			q.getTooltip = @(__original) function()
			{
				local ret = __original();
				local rangeText = "Artifact Weapon Ranges:";

				local condOriginal = this.m.NISConditionOrig;
				if(condOriginal != null && condOriginal > 1)
				{
					rangeText += "\n- Durability: " + this.Math.round(condOriginal * 1.4) + " to " + this.Math.round(condOriginal * 1.8);
				}
				local regularDamageOrig = this.m.NISRegularDamageOrig;
				local regularDamageMaxOrig = this.m.NISRegularDamageMaxOrig;
				if(regularDamageOrig != null && regularDamageOrig != this.m.RegularDamage)
				{
					rangeText += "\n- Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.3) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageMaxOrig * 1.3) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.6) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + Math.round(regularDamageMaxOrig * 1.6) + "[/color]";
				}
				local directDamageAddOrig = this.m.NISDirectDamageAddOrig;
				local directDamageMultOrig = this.m.NISDirectDamageMultOrig;
				if(directDamageAddOrig != null && this.Math.round(directDamageAddOrig*1000) != this.Math.round(this.m.DirectDamageAdd*1000))
				{
					rangeText += "\n- Armor Ignore: [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.16) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.3) * 100) + "%[/color]";
				}
				local armorDamageMultOrig = this.m.NISArmorDamageMultOrig;
				if(armorDamageMultOrig != null && this.Math.round(armorDamageMultOrig*1000) != this.Math.round(this.m.ArmorDamageMult*1000))
				{
					rangeText += "\n- Armor Effectiveness: [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.2) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.5) * 100) + "%[/color]";
				}
				local shieldDamageOrig = this.m.NISShieldDamageOrig;
				if (shieldDamageOrig != null && shieldDamageOrig != this.m.ShieldDamage)
				{
					rangeText += "\n- Shield Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 1.5) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 2.0) + "[/color]";
				}
				local chanceToHitHeadOrig = this.m.NISChanceToHitHeadOrig;
				if (chanceToHitHeadOrig != null && chanceToHitHeadOrig != this.m.ChanceToHitHead)
				{
					rangeText += "\n- Head Hit Chance: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 15) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 30) + "%[/color]";
				}
				local additionalAccuracyOrig = this.m.NISAdditionalAccuracyOrig;
				if (additionalAccuracyOrig != null && additionalAccuracyOrig != this.m.AdditionalAccuracy)
				{
					rangeText += "\n- Hit Bonus: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 10) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 20) + "%[/color]";
				}
				local staminaModifierOrig = this.m.NISStaminaModifierOrig;
				if (staminaModifierOrig != null && staminaModifierOrig != this.m.StaminaModifier)
				{
					rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.6) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.4) + "[/color]";
				}
				local fatigueOnSkillUseOrig = this.m.NISFatigueOnSkillUseOrig;
				if (fatigueOnSkillUseOrig != null && fatigueOnSkillUseOrig != this.m.FatigueOnSkillUse)
				{
					rangeText += "\n- Skill Use Fatigue: [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 2) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 4) + "[/color]";
				}
				local ammoOrig = this.m.NISAmmoOrig;
				if (ammoOrig != null && ammoOrig != this.m.Ammo)
				{
					rangeText += "\n- Ammo: [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 6) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 10) + "[/color]";
				}
				ret.push({
					id = 4,
					type = "text",
					icon = "ui/icons/special.png",
					text = rangeText
				});
				return ret;
			}
		});

		::modNamedItemStats.HooksMod.hook("scripts/items/armor/artifact/artifact_armor", function(q) {

			q.m.NISConditionOrig <- null;
			q.m.NISStaminaModifierOrig <- null;

			q.randomizeValues = @(__original) function()
			{
				this.m.NISConditionOrig = this.m.Condition;
				this.m.NISStaminaModifierOrig = this.m.StaminaModifier;
				local ret = __original();
				return ret;
			}

			q.getTooltip = @(__original) function()
			{
				local ret = __original();
				local rangeText = "Artifact Armor Ranges:";

				local condOriginal = this.m.NISConditionOrig;
				if(condOriginal != null)
				{
					rangeText += "\n- Durability: " + this.Math.floor(condOriginal * 1.3) + " to " + this.Math.floor(condOriginal * 1.5);
				}

				local stamOriginal = this.m.NISStaminaModifierOrig;
				if(stamOriginal != null)
				{
					rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + (stamOriginal + 5) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + (stamOriginal + 14) + "[/color]";
				}
				ret.push({
					id = 4,
					type = "text",
					icon = "ui/icons/special.png",
					text = rangeText
				});
				return ret;
			}
		});

		::modNamedItemStats.HooksMod.hook("scripts/items/helmets/artifact/artifact_helmet", function(q) {

			q.m.NISConditionOrig <- null;
			q.m.NISStaminaModifierOrig <- null;
			
			q.randomizeValues = @(__original) function()
			{
				this.m.NISConditionOrig = this.m.Condition;
				this.m.NISStaminaModifierOrig = this.m.StaminaModifier;
				local ret = __original();
				return ret;
			}

			q.getTooltip = @(__original) function()
			{
				local ret = __original();
				local rangeText = "Artifact Helmet Ranges:";

				local condOriginal = this.m.NISConditionOrig;
				if(condOriginal != null)
				{
					rangeText += "\n- Durability: " + this.Math.floor(condOriginal * 1.3) + " to " + this.Math.floor(condOriginal * 1.5);
				}

				local stamOriginal = this.m.NISStaminaModifierOrig;
				if(stamOriginal != null)
				{
					rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + (stamOriginal + 4) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + (stamOriginal + 6) + "[/color]";
				}
				ret.push({
					id = 4,
					type = "text",
					icon = "ui/icons/special.png",
					text = rangeText
				});
				return ret;
			}
		});

		::modNamedItemStats.HooksMod.hook("scripts/items/shields/artifact/artifact_shield", function(q) {

			q.m.NISConditionOrig <- null;
			q.m.NISMeleeDefenseOrig <- null;
			q.m.NISRangedDefenseOrig <- null;
			q.m.NISFatigueOnSkillUseOrig <- null;
			q.m.NISStaminaModifierOrig <- null;
			
			q.randomizeValues = @(__original) function()
			{
				this.m.NISConditionOrig = this.m.Condition;
				this.m.NISMeleeDefenseOrig = this.m.MeleeDefense;
				this.m.NISRangedDefenseOrig = this.m.RangedDefense;
				this.m.NISFatigueOnSkillUseOrig = this.m.FatigueOnSkillUse;
				this.m.NISStaminaModifierOrig = this.m.StaminaModifier;
				local ret = __original();
				return ret;
			}

			q.getTooltip = @(__original) function()
			{
				local ret = __original();
				local rangeText = "Artifact Shield Ranges:";

				local condOriginal = this.m.NISConditionOrig;
				if(condOriginal != null && condOriginal != this.m.ConditionMax)
				{
					rangeText += "\n- Durability: " + this.Math.round(condOriginal * 1.8) + " to " + this.Math.round(condOriginal * 2.0);
				}
				local meleeDefenseOriginal = this.m.NISMeleeDefenseOrig;
				if(meleeDefenseOriginal != null && meleeDefenseOriginal != this.m.MeleeDefense)
				{
					rangeText += "\n- Melee Defense: [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(meleeDefenseOriginal * 1.4) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(meleeDefenseOriginal * 1.6) + "[/color]";
				}
				local rangedDefenseOriginal = this.m.NISRangedDefenseOrig;
				if(rangedDefenseOriginal != null && rangedDefenseOriginal != this.m.RangedDefense)
				{
					rangeText += "\n- Ranged Defense: [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(rangedDefenseOriginal * 1.4) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(rangedDefenseOriginal * 1.6) + "[/color]";
				}
				local fatigueOnSkillUseOrig = this.m.NISFatigueOnSkillUseOrig;
				if (fatigueOnSkillUseOrig != null && fatigueOnSkillUseOrig != this.m.FatigueOnSkillUse)
				{
					rangeText += "\n- Skill Use Fatigue: [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 2) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 4) + "[/color]";
				}
				local stamOriginal = this.m.NISStaminaModifierOrig;
				if(stamOriginal != null && stamOriginal != this.m.StaminaModifier)
				{
					rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(stamOriginal * 0.8) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(stamOriginal * 0.6) + "[/color]";
				}
				ret.push({
					id = 4,
					type = "text",
					icon = "ui/icons/special.png",
					text = rangeText
				});
				return ret;
			}
		});

		::modNamedItemStats.HooksMod.hook("scripts/items/weapons/artifact/artifact_crossbow", function(q) {

			q.getTooltip = @(__original) function()
			{
				local ret = __original();
				local rangeText = "Artifact Weapon Ranges:";

				local condOriginal = this.m.NISConditionOrig;
				if(condOriginal != null && condOriginal > 1)
				{
					rangeText += "\n- Durability: " + this.Math.round(condOriginal * 1.4) + " to " + this.Math.round(condOriginal * 1.8);
				}
				local regularDamageOrig = this.m.NISRegularDamageOrig;
				local regularDamageMaxOrig = this.m.NISRegularDamageMaxOrig;
				if(regularDamageOrig != null && regularDamageOrig != this.m.RegularDamage)
				{
					rangeText += "\n- Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.3) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageMaxOrig * 1.3) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.6) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + Math.round(regularDamageMaxOrig * 1.6) + "[/color]";
				}
				local directDamageAddOrig = this.m.NISDirectDamageAddOrig;
				local directDamageMultOrig = this.m.NISDirectDamageMultOrig;
				if(directDamageAddOrig != null && this.Math.round(directDamageAddOrig*1000) != this.Math.round(this.m.DirectDamageAdd*1000))
				{
					rangeText += "\n- Armor Ignore: [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.16) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.3) * 100) + "%[/color]";
				}
				local armorDamageMultOrig = this.m.NISArmorDamageMultOrig;
				if(armorDamageMultOrig != null && this.Math.round(armorDamageMultOrig*1000) != this.Math.round(this.m.ArmorDamageMult*1000))
				{
					rangeText += "\n- Armor Effectiveness: [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.2) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.5) * 100) + "%[/color]";
				}
				local shieldDamageOrig = this.m.NISShieldDamageOrig;
				if (shieldDamageOrig != null && shieldDamageOrig != this.m.ShieldDamage)
				{
					rangeText += "\n- Shield Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 1.5) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 2.0) + "[/color]";
				}
				local chanceToHitHeadOrig = this.m.NISChanceToHitHeadOrig;
				if (chanceToHitHeadOrig != null && chanceToHitHeadOrig != this.m.ChanceToHitHead)
				{
					rangeText += "\n- Head Hit Chance: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 15) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 30) + "%[/color]";
				}
				local additionalAccuracyOrig = this.m.NISAdditionalAccuracyOrig;
				if (additionalAccuracyOrig != null && additionalAccuracyOrig != this.m.AdditionalAccuracy)
				{
					rangeText += "\n- Hit Bonus: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 10) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 20) + "%[/color]";
				}
				local staminaModifierOrig = this.m.NISStaminaModifierOrig;
				if (staminaModifierOrig != null && staminaModifierOrig != this.m.StaminaModifier)
				{
					rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.6) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.4) + "[/color]";
				}
				local fatigueOnSkillUseOrig = this.m.NISFatigueOnSkillUseOrig;
				if (fatigueOnSkillUseOrig != null && fatigueOnSkillUseOrig != this.m.FatigueOnSkillUse)
				{
					rangeText += "\n- Skill Use Fatigue: [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 2) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 4) + "[/color]";
				}
				local ammoOrig = this.m.NISAmmoOrig;
				if (ammoOrig != null && ammoOrig != this.m.Ammo)
				{
					rangeText += "\n- Ammo: [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 6) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 10) + "[/color]";
				}
				ret.push({
					id = 4,
					type = "text",
					icon = "ui/icons/special.png",
					text = rangeText
				});
				return ret;
			}
		});

		::modNamedItemStats.HooksMod.hook("scripts/items/weapons/artifact/artifact_handgonne", function(q) {

			q.getTooltip = @(__original) function()
			{
				local ret = __original();
				local rangeText = "Artifact Weapon Ranges:";

				local condOriginal = this.m.NISConditionOrig;
				if(condOriginal != null && condOriginal > 1)
				{
					rangeText += "\n- Durability: " + this.Math.round(condOriginal * 1.4) + " to " + this.Math.round(condOriginal * 1.8);
				}
				local regularDamageOrig = this.m.NISRegularDamageOrig;
				local regularDamageMaxOrig = this.m.NISRegularDamageMaxOrig;
				if(regularDamageOrig != null && regularDamageOrig != this.m.RegularDamage)
				{
					rangeText += "\n- Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.3) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageMaxOrig * 1.3) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + this.Math.round(regularDamageOrig * 1.6) + "[/color] - [color=" + this.Const.UI.Color.DamageValue + "]" + Math.round(regularDamageMaxOrig * 1.6) + "[/color]";
				}
				local directDamageAddOrig = this.m.NISDirectDamageAddOrig;
				local directDamageMultOrig = this.m.NISDirectDamageMultOrig;
				if(directDamageAddOrig != null && this.Math.round(directDamageAddOrig*1000) != this.Math.round(this.m.DirectDamageAdd*1000))
				{
					rangeText += "\n- Armor Ignore: [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.16) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((directDamageMultOrig + directDamageAddOrig + 0.3) * 100) + "%[/color]";
				}
				local armorDamageMultOrig = this.m.NISArmorDamageMultOrig;
				if(armorDamageMultOrig != null && this.Math.round(armorDamageMultOrig*1000) != this.Math.round(this.m.ArmorDamageMult*1000))
				{
					rangeText += "\n- Armor Effectiveness: [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.2) * 100) + "%[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + ((armorDamageMultOrig + 0.5) * 100) + "%[/color]";
				}
				local shieldDamageOrig = this.m.NISShieldDamageOrig;
				if (shieldDamageOrig != null && shieldDamageOrig != this.m.ShieldDamage)
				{
					rangeText += "\n- Shield Damage: [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 1.5) + "[/color] to [color=" + this.Const.UI.Color.DamageValue + "]" + (shieldDamageOrig * 2.0) + "[/color]";
				}
				local chanceToHitHeadOrig = this.m.NISChanceToHitHeadOrig;
				if (chanceToHitHeadOrig != null && chanceToHitHeadOrig != this.m.ChanceToHitHead)
				{
					rangeText += "\n- Head Hit Chance: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 15) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (chanceToHitHeadOrig + 30) + "%[/color]";
				}
				local additionalAccuracyOrig = this.m.NISAdditionalAccuracyOrig;
				if (additionalAccuracyOrig != null && additionalAccuracyOrig != this.m.AdditionalAccuracy)
				{
					rangeText += "\n- Hit Bonus: [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 10) + "%[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + (additionalAccuracyOrig + 20) + "%[/color]";
				}
				local staminaModifierOrig = this.m.NISStaminaModifierOrig;
				if (staminaModifierOrig != null && staminaModifierOrig != this.m.StaminaModifier)
				{
					rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.6) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(staminaModifierOrig * 0.4) + "[/color]";
				}
				local fatigueOnSkillUseOrig = this.m.NISFatigueOnSkillUseOrig;
				if (fatigueOnSkillUseOrig != null && fatigueOnSkillUseOrig != this.m.FatigueOnSkillUse)
				{
					rangeText += "\n- Skill Use Fatigue: [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 2) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 4) + "[/color]";
				}
				local ammoOrig = this.m.NISAmmoOrig;
				if (ammoOrig != null && ammoOrig != this.m.Ammo)
				{
					rangeText += "\n- Ammo: [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 6) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (ammoOrig + 10) + "[/color]";
				}
				ret.push({
					id = 4,
					type = "text",
					icon = "ui/icons/special.png",
					text = rangeText
				});
				return ret;
			}
		});

		::modNamedItemStats.HooksMod.hook("scripts/items/shields/artifact/artifact_schract_shield", function(q) {

			q.getTooltip = @(__original) function()
			{
				local ret = __original();
				local rangeText = "Artifact Shield Ranges:";

				local condOriginal = this.m.NISConditionOrig;
				if(condOriginal != null && condOriginal != this.m.ConditionMax)
				{
					rangeText += "\n- Durability: " + this.Math.round(condOriginal * 1.8) + " to " + this.Math.round(condOriginal * 2.0);
				}
				local meleeDefenseOriginal = this.m.NISMeleeDefenseOrig;
				if(meleeDefenseOriginal != null && meleeDefenseOriginal != this.m.MeleeDefense)
				{
					rangeText += "\n- Melee Defense: [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(meleeDefenseOriginal * 1.4) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(meleeDefenseOriginal * 1.6) + "[/color]";
				}
				local rangedDefenseOriginal = this.m.NISRangedDefenseOrig;
				if(rangedDefenseOriginal != null && rangedDefenseOriginal != this.m.RangedDefense)
				{
					rangeText += "\n- Ranged Defense: [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(rangedDefenseOriginal * 1.4) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]+" + this.Math.round(rangedDefenseOriginal * 1.6) + "[/color]";
				}
				local fatigueOnSkillUseOrig = this.m.NISFatigueOnSkillUseOrig;
				if (fatigueOnSkillUseOrig != null && fatigueOnSkillUseOrig != this.m.FatigueOnSkillUse)
				{
					rangeText += "\n- Skill Use Fatigue: [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 2) + "[/color] to [color=" + this.Const.UI.Color.PositiveValue + "]" + (fatigueOnSkillUseOrig - 4) + "[/color]";
				}
				local stamOriginal = this.m.NISStaminaModifierOrig;
				if(stamOriginal != null && stamOriginal != this.m.StaminaModifier)
				{
					rangeText += "\n- Weight: [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(stamOriginal * 0.8) + "[/color] to [color=" + this.Const.UI.Color.NegativeValue + "]" + this.Math.round(stamOriginal * 0.6) + "[/color]";
				}
				ret.push({
					id = 4,
					type = "text",
					icon = "ui/icons/special.png",
					text = rangeText
				});
				return ret;
			}
		});
	}

}, ::Hooks.QueueBucket.Late);

// The reforged hook for this perk is being sniped
::Hardened.HooksMod.hook("scripts/skills/perks/perk_mastery_throwing", function(q) {
	// Public
	q.m.DamageTotalMult <- 1.3;	// Damage Multiplier for first throwing attack each turn
	q.m.HD_FatigueCostMult <- ::Hardened.Global.WeaponSpecFatigueMult;

	// Private
	q.m.GainedQuickSwitchThisRound <- false;
	q.m.HasQuickSwitch <- false;
	q.m.SkillCounter <- null;	// This is used to bind this perk_mastery_throwing effect to the root skill that it will empower and rediscover it even through delays

	q.create = @(__original) function()
	{
		__original();

		this.m.Description = "Master throwing weapons to wound or kill the enemy before they even get close";
		this.m.Icon = "ui/perks/perk_50.png";	// Vanilla: "ui/perks/perk_10.png"; which is the Anticipation Icon
		this.addType(::Const.SkillType.StatusEffect);	// We add StatusEffect so that this perk can produce a status effect icon
	}

	// Overwrite, because Vanilla defines no tooltips for this perk
	q.getTooltip = @() function()
	{
		local ret = this.skill.getTooltip();

		if (this.m.HasQuickSwitch)
		{
			ret.push({
				id = 10,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("Swapping any item is a free action this [round|Concept.Round]"),
			});
		}

		return ret;
	}

	q.isHidden = @() function()
	{
		return !this.m.HasQuickSwitch;
	}

	q.onAfterUpdate = @(__original) function( _properties )
	{
		__original(_properties);
		// Feat: We now implement the fatigue cost discount of masteries within the mastery perk
		if (this.m.HD_FatigueCostMult != 1.0)
		{
			foreach (skill in this.getContainer().m.Skills)
			{
				if (this.isSkillValid(skill))
				{
					skill.m.FatigueCostMult *= this.m.HD_FatigueCostMult;
				}
			}
		}
	}

	// Overwrite, because we replace the proximity-based damage multiplier with our own version
	q.onAnySkillUsed = @() function( _skill, _targetEntity, _properties )
	{
		if (!this.isSkillValidForDamageBonus(_skill)) return;

		// The following condition is a smart way to cover three states
		// 1. both are null. This means perk_mastery_throwing is still available and we are not in the execution of a skill so this skill must provide its effect to adjust tooltips
		// 2. both are the same value: we are in the execution of the empowered skill or a child skill of the empowered one. We apply our effect accordingly
		// 3. SkillCounter is not null: our effect is used up, so we no longer display any tooltip adjustments
		if (this.m.SkillCounter != ::Hardened.Temp.RootSkillCounter) return;

		_properties.DamageTotalMult	*= this.m.DamageTotalMult;
	}

	// Overwrite to turn off Reforged onHit effects
	q.onTargetHit = @() function( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor ) {}

	q.onNewRound = @(__original) function()
	{
		__original();
		this.m.GainedQuickSwitchThisRound = false;
		this.m.HasQuickSwitch = false;
	}

	q.onTurnStart = @(__original) function()
	{
		__original();
		this.m.SkillCounter = null;
	}

	q.onCombatFinished = @(__original) function()
	{
		__original();
		this.m.GainedQuickSwitchThisRound = false;
		this.m.HasQuickSwitch = false;
		this.m.SkillCounter = null;
	}

	q.onPayForItemAction = @(__original) function( _skill, _items )
	{
		__original(_skill, _items);
		if (_skill == this) this.m.HasQuickSwitch = false;
	}

	// You can now swap a throwing weapon with an empty slot or an empty throwing weapon
	q.getItemActionCost = @(__original) function( _items )
	{
		if (!this.m.HasQuickSwitch) return null;

		local involvedItems = 0;
		foreach (item in _items)
		{
			if (item != null) involvedItems++;
		}
		if (involvedItems > 2) return null;

		return 0;
	}

// Hardened Functions
	q.onReallyBeforeSkillExecuted <- function( _skill, _targetTile )
	{
		if (!this.isSkillValidForDamageBonus(_skill)) return;

		if (this.m.SkillCounter == null && ::Const.SkillCounter == ::Hardened.Temp.RootSkillCounter)
		{
			this.m.SkillCounter = ::Hardened.Temp.RootSkillCounter;	// We bind this effect to the root skill so that we affect all child executions of this chain
		}

		if (!this.m.GainedQuickSwitchThisRound)
		{
			this.m.GainedQuickSwitchThisRound = true;
			this.m.HasQuickSwitch = true;
		}
	}

		// Our effect allows quickswitching of any type of item and even grants a discount when swapping 3 t

// New Functions
	q.isSkillValidForDamageBonus <- function( _skill )
	{
		return this.isSkillValid(_skill) && _skill.isAttack();
	}

	q.isSkillValid <- function( _skill )
	{
		if (_skill == null) return false;
		if (!_skill.isActive()) return false;

		local skillItem = _skill.getItem();
		if (::MSU.isNull(skillItem)) return false;
		if (!skillItem.isItemType(::Const.Items.ItemType.Weapon)) return false;
		if (!skillItem.isWeaponType(::Const.Items.WeaponType.Throwing)) return false;

		return true;
	}
});

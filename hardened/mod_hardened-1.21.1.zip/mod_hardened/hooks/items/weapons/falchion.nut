::Hardened.HooksMod.hook("scripts/items/weapons/falchion", function(q) {
	// We overwrite Reforged skill additions, because we dont hand out any discounts
	q.onEquip = @() { function onEquip()
	{
		this.weapon.onEquip();
		this.addSkill(::new("scripts/skills/actives/slash"));
		this.addSkill(::new("scripts/skills/actives/riposte"));
	}}.onEquip;
});


$("head").append('<style id="mod_accessibility" type="text/css"></style>');
var Accessibility = {
	ID : "mod_accessibility",
	Sheet : $("#mod_accessibility").get(0).sheet,
	Connection : new MSUBackendConnection(),
	InsertRule : function (_class, _fontSize, _color)
	{
		if (_fontSize === undefined && _color === undefined)
			return
		var style = _class + " {"
		if (_fontSize !== undefined && _fontSize !== null)
		{
			style += "font-size: " + _fontSize + "rem;";
		}
		if (_color !== undefined && _color !== null)
		{
			style += "color: " + _color + " !important;";
		}

		style += "}";
		this.Sheet.insertRule(style, 0);
	},
	Reset : function()
	{
		while (this.Sheet.cssRules.length > 0)
		{
			this.Sheet.deleteRule(0);
		}
	}
};

Accessibility.Connection.updateValues = function( _data )
{
	Accessibility.Reset();
	var globalFontSize = (MSU.getSettingValue(Accessibility.ID, "global-font-size") / 100) * 1.0;
	$.each(fontsToUpdate, function(_key, _value)
	{
		var settingValue = MSU.getSettingValue(Accessibility.ID, _key);
		if (settingValue.toFixed(1) != 100.0)
		{
			Accessibility.InsertRule(_key, _value * (settingValue / 100))
		}
		else
		{
			Accessibility.InsertRule(_key, _value * globalFontSize)
		}
	})

	$.each(genericFontSizes, function(_key, _value)
	{
		Accessibility.InsertRule(_key, _value * globalFontSize)
	})


	$.each(colorsToUpdate, function(_key, _value)
	{
		var settingValue = MSU.getSettingValue(Accessibility.ID, _key);
		var asRGBA = "rgba(" + settingValue + ")"
		Accessibility.InsertRule(_key, null, asRGBA);
	})
}

registerScreen(Accessibility.ID, Accessibility.Connection);


var fontsToUpdate = {
	".default-font-very-small": 1.2,
	".title-font-very-small": 1.2,
	".text-font-very-small": 1.2,
	".description-font-very-small": 1.2,
	".default-font-small": 1.4,
	".default-font-normal": 1.8,
	".default-font-big": 2.2,
	".default-font-very-big": 2.8,
	".title-font-small": 1.4,
	".title-font-normal": 1.8,
	".title-font-big": 2.2,
	".title-font-very-big": 2.8,
	".text-font-small": 1.4,
	".text-font-medium": 1.6,
	".text-font-normal": 1.8,
	".text-font-big": 2.2,
	".text-font-very-big": 2.8,
	".description-font-small": 1.4,
	".description-font-medium": 1.6,
	".description-font-normal": 1.8,
	".description-font-big": 2.0,
	".description-font-very-big": 2.6,
}

var genericFontSizes = {};
for (var x = 4; x != 41; x++)
{
	genericFontSizes[".font-size-" + x] = (x/10).toFixed(1);
}

var colorsToUpdate = 
{
	'.font-color-white' : "255, 255, 255, 1",
	'.font-color-brother-name' : "221, 162, 31, 1",
	'.font-color-title' : "221, 162, 31, 1",
	'.font-color-subtitle' : "221, 162, 31, 1",
	'.font-color-description' : "189, 157, 113, 1",
	'.font-color-disabled' : "189, 157, 113, 1",
	'.font-color-label' : "215, 177, 116, 1",
	'.font-color-speech' : "188, 173, 140, 1",
	'.font-color-label-warning' : "217, 46, 46, 1",
	'.font-color-value' : "221, 162, 31, 1",
	'.font-color-stack' : "214, 219, 233, 1",
	'.font-color-positive-value' : "221, 162, 31, 1",
	'.font-color-negative-value' : "205, 38, 38, 1",
	'.font-color-assets-positive-value' : "221, 162, 31, 1",
	'.font-color-assets-negative-value' : "205, 38, 38, 1",
	'.font-color-ink' : "1,0,53,200",
	'.font-color-progressbar-label' : "198, 198, 198, 1",
	'.font-color-numeration-label' : "214, 219, 233, 1",
}


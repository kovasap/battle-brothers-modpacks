::TimeStone <- {
	ID = "mod_time_stone",
	Name = "Time Stone",
	Version = "0.2.4",
	GitHubURL = "https://github.com/Darxo/Time-Stone",
	Const = {},
}

::TimeStone.HooksMod <- ::Hooks.register(::TimeStone.ID, ::TimeStone.Version, ::TimeStone.Name);
::TimeStone.HooksMod.require([
	"vanilla >= 1.5.2-2",
	"mod_msu",
]);

::TimeStone.HooksMod.queue([">mod_msu", ">mod_legends"], function() {
	::TimeStone.Mod <- ::MSU.Class.Mod(::TimeStone.ID, ::TimeStone.Version, ::TimeStone.Name);

	::TimeStone.Mod.Registry.addModSource(::MSU.System.Registry.ModSourceDomain.GitHub, ::TimeStone.GitHubURL);
	::TimeStone.Mod.Registry.setUpdateSource(::MSU.System.Registry.ModSourceDomain.GitHub);

	::include("mod_time_stone/load");		// Load mod adjustments and other hooks
	::include("mod_time_stone/ui/load");	// Load JS Adjustments and Hooks
});

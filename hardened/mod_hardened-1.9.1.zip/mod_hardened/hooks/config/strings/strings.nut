::Const.Strings.World.TimeOfDay <- [
	"Morning",
	"Morning",
	"Morning",
	"Midday",
	"Afternoon",
	"Afternoon",
	"Afternoon",
	"Sunset",
	"Dusk",
	"Midnight",
	"Dawn",
	"Sunrise",
];

::Const.Strings.Tactical.EntityName.Brush = "Bush";	// Vanilla: Brush

::Const.Strings.Distance[0] += " (0 - 5 tiles)";
::Const.Strings.Distance[1] += " (6 - 11 tiles)";
::Const.Strings.Distance[2] += " (12 - 17 tiles)";
::Const.Strings.Distance[3] += " (18 - 23 tiles)";
::Const.Strings.Distance[4] += " (24 - 29 tiles)";
::Const.Strings.Distance[5] += " (30+ tiles)";

local newPerks = [
	{
		Key = "HD_Anchor",
		Name = "Anchor",
		Description = ::UPD.getDescription({
			Fluff = "No wave nor warrior can move you from your place!",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"If you end your [turn|Concept.Turn] on the same tile you started it on, become immune to [Displacement|Concept.Displacement] until the start of your next [turn|Concept.Turn]",
						"During your [turn|Concept.Turn], take " + ::MSU.Text.colorPositive("50%") + " less damage",
					],
				},
			],
		}),
	},
	{
		Key = "HD_BraceForImpact",
		Name = "Brace for Impact",
		Description = ::UPD.getDescription({
			Fluff = "This is going to hurt.",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"Whenever you move to a tile, gain " + ::MSU.Text.colorPositive("1") + " stack for each adjacent enemy (up to a maximum of 5 stacks), until the start of your next [turn|Concept.Turn]",
						"Take " + ::MSU.Text.colorPositive("10%") + " less [Hitpoint|Concept.Hitpoints] Damage from Attacks for each stack",
					],
				},
			],
		}),
	},
	{
		Key = "HD_Hybridization",
		Name = "Hybridization",
		Description = ::UPD.getDescription({
			Fluff = "\'Hatchet, throwing axe, spear, javelin... they all kill just the same!\'",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"Once per [round|Concept.Round], swapping two weapons with no shared weapon type becomes a free action",
						"Gain " + ::MSU.Text.colorPositive("+10") + " [Melee Defense|Concept.MeleeDefense], if you have at least " + ::MSU.Text.colorPositive("70") + " [Base|Concept.BaseAttribute] [Ranged Skill|Concept.RangeSkill]",
						"Gain " + ::MSU.Text.colorPositive("+10") + " [Ranged Defense|Concept.RangeDefense], if you have at least " + ::MSU.Text.colorPositive("70") + " [Base|Concept.BaseAttribute] [Melee Skill|Concept.MeleeSkill]",
					],
				},
			],
		}),
	},
	{
		Key = "HD_OneWithTheShield",
		Name = "One with the Shield",
		Description = ::UPD.getDescription({
			Fluff = "Shift your shield to guard vital points.",
			Requirement = "Shield",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"Take " + ::MSU.Text.colorPositive("40%") + " less [Hitpoint|Concept.Hitpoints] damage from Attacks to the Head, while you have the [Shieldwall effect|Skill+shieldwall_effect]",
						"Take " + ::MSU.Text.colorPositive("40%") + " less [Hitpoint|Concept.Hitpoints] damage from Attacks to the Body, while you don\'t have the [Shieldwall effect|Skill+shieldwall_effect]",
					],
				},
			],
		}),
	},
	{
		Key = "HD_Parry",
		Name = "Parry",
		Description = ::UPD.getDescription({
			Fluff = "With your quick reflexes, you deflect weapon strikes with ease.",
			Requirement = "One-Handed Melee Weapon",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"Gain [Melee Defense|Concept.MeleeDefense] equal to your [Base|Concept.BaseAttribute] [Ranged Defense|Concept.RangeDefense] against Weapon Attacks",
						"Have " + ::MSU.Text.colorNegative("70%") + " less [Ranged Defense|Concept.RangeDefense] while adjacent to an enemy wielding a Melee Weapon",
						"Does not work with shields. Does not work while [disarmed|Skill+disarmed_effect], [stunned|Skill+stunned_effect] or [fleeing|Skill+hd_dummy_morale_state_fleeing]",
					],
				},
				{
					Type = ::UPD.EffectType.Clarification,
					Description = [
						"The [Melee Defense|Concept.MeleeDefense] scales off of a [Base Attribute|Concept.BaseAttribute] and is therefore unaffected by any modifiers to that Attribute, including this perk\'s own penalty",
					],
				},
			],
		}),
	},
	{
		Key = "HD_Scout",
		Name = "Scout",
		Description = ::UPD.getDescription({
			Fluff = "High ground and a clear view are your greatest assets.",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"Gain " + ::MSU.Text.colorPositive("+1") + " [Vision|Concept.SightDistance] for every 3 adjacent tiles that are either empty or at least 2 levels below your tile",
						"[Action Point|Concept.ActionPoints] costs for movement on all terrain is reduced by 1 to a minimum of 2 [Action Points|Concept.ActionPoints] per tile. This does not stack with [Pathfinder|Perk+perk_pathfinder] or [Elusive|Perk+perk_elusive]",
					],
				},
			],
		}),
	},
	{
		Key = "HD_Elusive",
		Name = "Elusive",
		Description = ::UPD.getDescription({
			Fluff = "You are impossible to pin down!",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"[Action Point|Concept.ActionPoints] costs for movement on all terrain is reduced by 1 to a minimum of 2 [Action Points|Concept.ActionPoints] per tile. This does not stack with [Pathfinder|Perk+perk_pathfinder] or [Elusive|Perk+perk_elusive]",
						"After moving 2 tiles, become immune to [rooted|Concept.Rooted] effects, until the start of your next [turn|Concept.Turn]",
					],
				},
			],
		}),
	},
	{
		Key = "HD_Forestbond",
		Name = "Forestbond",
		Description = ::UPD.getDescription({
			Fluff = "Draw strength from the living forest, letting its lifeblood mend your wounds.",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"At the start of each [turn|Concept.Turn], recover " + ::MSU.Text.colorPositive("3%") + " [Hitpoints|Concept.Hitpoints] for each adjacent obstacle that is a tree",
					],
				},
			],
		}),
	},
	{
		Key = "HD_Warden",
		Name = "Warden",
		Description = ::UPD.getDescription({
			Fluff = "Under your watch, no one gets harmed.",
			Effects = [
				{
					Type = ::UPD.EffectType.Passive,
					Description = [
						"Adjacent allies take " + ::MSU.Text.colorPositive("30%") + " less damage from Attacks from enemies that are adjacent to you. This does not affect allies who also have [Warden|Perk+perk_hd_warden]",
						"Whenever an adjacent ally takes damage, move to the next position in the [turn|Concept.Turn] sequence",
						"Does not work while [fleeing|Skill+hd_dummy_morale_state_fleeing]"
					],
				},
			],
		}),
	},
];

// Add new Hardened Perks
foreach (newPerk in newPerks)
{
	::Const.Strings.PerkName[newPerk.Key] <- ::Reforged.Mod.Tooltips.parseString(newPerk.Name);
	::Const.Strings.PerkDescription[newPerk.Key] <- ::Reforged.Mod.Tooltips.parseString(newPerk.Description);
}

::Const.Strings.EntityName[::Const.EntityType.UnholdBog] = "Bog Unhold";		// Vanilla: Unhold
::Const.Strings.EntityNamePlural[::Const.EntityType.UnholdBog] = "Bog Unholds";		// Vanilla: Unholds
::Const.Strings.EntityName[::Const.EntityType.UnholdFrost] = "Frost Unhold";	// Vanilla: Unhold
::Const.Strings.EntityNamePlural[::Const.EntityType.UnholdFrost] = "Frost Unholds";		// Vanilla: Unholds
::Const.Strings.EntityName[::Const.EntityType.BarbarianUnholdFrost] = "Armored Frost Unhold";	// Vanilla: Armored Unhold
::Const.Strings.EntityNamePlural[::Const.EntityType.BarbarianUnholdFrost] = "Armored Frost Unholds";		// Vanilla: Armored Unholds

::Const.Strings.EntityName[::Const.EntityType.MilitiaRanged] = "Militia Archer";			// Vanilla: Militia Marksman
::Const.Strings.EntityNamePlural[::Const.EntityType.MilitiaRanged] = "Militia Archers";		// Vanilla: Militia Marksmen

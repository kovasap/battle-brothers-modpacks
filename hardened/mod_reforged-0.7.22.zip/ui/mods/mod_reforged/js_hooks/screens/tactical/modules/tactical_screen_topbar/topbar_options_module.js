// New function to change Icon of Flee-Button when enemies gave up
TacticalScreenTopbarOptionsModule.prototype.changeFleeButtonToWin = function ()
{
	this.mFleeButton.changeButtonImage(Path.GFX + Reforged.Asset.BUTTON_RETREAT_WIN);
};

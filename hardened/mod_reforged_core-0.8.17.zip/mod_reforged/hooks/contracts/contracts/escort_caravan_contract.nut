::Reforged.HooksMod.hook("scripts/contracts/contracts/escort_caravan_contract", function(q) {
	q.onPrepareVariables = @(__original) { function onPrepareVariables( _vars )
	{
		__original(_vars);
		foreach (var in _vars)
		{
			if (var[0] != "days") continue;
			local seconds = this.getSecondsRequiredToTravel(this.m.Flags.get("Distance"), ::Const.World.MovementSettings.Speed * 0.6, true);
			var[1] = "[color=#f6eedb]" + ::Reforged.Text.getDaysAndHalf(seconds) + "[/color]"; // Same color as vanilla OOC var but we can't use a var within a var
			break;
		}
	}}.onPrepareVariables;

	q.RF_getOriginText = @(__original) { function RF_getOriginText()
	{
		return "To " + __original();
	}}.RF_getOriginText;

	q.RF_getDaysRequiredToTravel = @() { function RF_getDaysRequiredToTravel( _start, _end )
	{
		return this.getDaysRequiredToTravel(_start.getDistanceTo(_end), ::Const.World.MovementSettings.Speed * 0.6, true);
	}}.RF_getDaysRequiredToTravel;
});

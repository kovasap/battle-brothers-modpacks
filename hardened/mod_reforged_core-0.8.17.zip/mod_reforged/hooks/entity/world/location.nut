::Reforged.HooksMod.hook("scripts/entity/world/location", function(q) {
	q.setBanner = @(__original) { function setBanner( _banner )
	{
		__original(_banner);
		this.adjustBannerOffset();
	}}.setBanner;

	q.onAfterInit = @(__original) { function onAfterInit()
	{
		__original();
		this.adjustBannerOffset();	// onAfterInit is called before deserialization, so this will only affect newly created locations
	}}.onAfterInit;

	q.onDeserialize = @(__original) { function onDeserialize(_in)
	{
		__original(_in);
		this.adjustBannerOffset();	// onAfterInit is called before deserialization, so we need this adjustment to catch all deserialized locations too
	}}.onDeserialize;

	// Always show defenders when dev spawns info is turned on.
	q.isShowingDefenders = @(__original) { function isShowingDefenders()
	{
		return ::Reforged.Mod.ModSettings.getSetting("Dev_SpawnsInfo").getValue() ? true : __original();
	}}.isShowingDefenders;

// New Functions
	q.adjustBannerOffset <- { function adjustBannerOffset()	// This has to be called everytime that a brush for the banner sprite is set because that will reset the previous offset
	{
		if (this.hasSprite("location_banner"))
		{
			this.getSprite("location_banner").setOffset(::createVec(0, ::Reforged.Config.UI.WorldBannerYOffset));
		}
	}}.adjustBannerOffset;
});

::Reforged.HooksMod.hook("scripts/ai/tactical/behaviors/ai_attack_default", function(q) {
	q.m.PossibleSkills.push("actives.rf_sword_thrust");
	q.m.PossibleSkills.push("actives.rf_flail_pole");
	q.m.PossibleSkills.push("actives.rf_great_cleave");
	q.m.PossibleSkills.push("actives.rf_heavy_cleave");
	q.m.PossibleSkills.push("actives.rf_voulge_cleave");
	q.m.PossibleSkills.push("actives.rf_vampire_bite");
	q.m.PossibleSkills.push("actives.rf_ethereal_bite");
	q.m.PossibleSkills.push("actives.rf_zombie_orc_bite");
});

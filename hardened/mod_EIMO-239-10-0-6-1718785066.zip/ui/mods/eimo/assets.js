var EIMO =
{
	ID: "mod_EIMO",
	InventoryAddonsID: "InventoryAddons",
	VisibilityLevelID: "VisibilityLevel",
	Hooks: {},
	Generic: {},

	BUTTON_REPAIR: 						"ui/icons/EIMO_repair.png",
	BUTTON_REPAIR_ONE_ENABLED: 			"ui/icons/EIMO_repair_one.png",
	BUTTON_REPAIR_ONE_DISABLED: 		"ui/icons/EIMO_repair_one_bw.png",
	BUTTON_REPAIR_ALL_ENABLED: 			"ui/icons/EIMO_repair_all.png",
	BUTTON_REPAIR_ALL_DISABLED: 		"ui/icons/EIMO_repair_all_bw.png",
	BUTTON_SALVAGE: 					"ui/icons/EIMO_salvage.png",

	ICON_FAVORITE: 						"ui/icons/EIMO_star.png",
	ICON_FAVORITE_ID:					"ui/icons/EIMO_three_stars.png",
	ICON_MONEY: 						"ui/icons/EIMO_money.png",
}

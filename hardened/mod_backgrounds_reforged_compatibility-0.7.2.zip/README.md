# Description

This mod is a compatibility patch for Reforged for the More Backgrounds and Events Mod.
https://www.nexusmods.com/battlebrothers/mods/769

# List of all Changes

## Major Changes

https://docs.google.com/spreadsheets/d/1lBG9PbSkDyVcI7pf9oyUDSJL6zbJjQQLcuhb3NCFpfA/edit?gid=457849423#gid=457849423

# Requirements

- Modern Hooks
- Modding Standards and Utilities (MSU)
- Reforged
- More Backgrounds and Events (Updated)

# Known Issues:

# Compatibility



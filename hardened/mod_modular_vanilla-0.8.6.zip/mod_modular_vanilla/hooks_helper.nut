::ModularVanilla.HooksHelper <- {

};

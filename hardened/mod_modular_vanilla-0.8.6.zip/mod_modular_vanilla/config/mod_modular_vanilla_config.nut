::ModularVanilla.Const <- {};

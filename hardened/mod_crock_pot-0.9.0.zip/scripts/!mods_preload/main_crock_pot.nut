::CrockPot <- {
	ID = "mod_crock_pot",
	Name = "Crock Pot",
	Version = "0.9.0",
	GitHubURL = "https://github.com/Darxo/Crock_Pot",
	Const = {
		DayThresholdMinDangerBeasts = 10,	// Higher Tier Beast Caves (Lindwurms and Unholds) only start appearing at this day count
	},
	Global = {
		IsViewingRecipes = false,	// WHen true, then certain items will return different ItemIDs
	},
}

local requiredMods = [
	"vanilla >= 1.5.2-2",
	"mod_reforged >= 0.8.0-alpha",
];

::CrockPot.HooksMod <- ::Hooks.register(::CrockPot.ID, ::CrockPot.Version, ::CrockPot.Name);
::CrockPot.HooksMod.require(requiredMods);

::CrockPot.HooksMod.queue(">mod_reforged", function() {
	::CrockPot.Mod <- ::MSU.Class.Mod(::CrockPot.ID, ::CrockPot.Version, ::CrockPot.Name);

	::CrockPot.Mod.Registry.addModSource(::MSU.System.Registry.ModSourceDomain.GitHub, ::CrockPot.GitHubURL);
	::CrockPot.Mod.Registry.setUpdateSource(::MSU.System.Registry.ModSourceDomain.GitHub);

	::include("mod_crock_pot/load");		// Load mod adjustments and other hooks
	::include("mod_crock_pot/ui/load");		// Load JS Adjustments and Hooks
});

::CrockPot.HooksMod.queue(">mod_reforged", function() {
	// It remains to be decided, if all module stuff should be run late, but or now it only containes weighted gear container, which need to run after Hardeneds container
	::includeFiles(::IO.enumerateFiles("mod_crock_pot/api/modules"));
}, ::Hooks.QueueBucket.Last);

::CrockPot.HooksMod.queue(">mod_reforged", function() {
	::includeFiles(::IO.enumerateFiles("mod_crock_pot/hooks_late"));
}, ::Hooks.QueueBucket.Late);

::CrockPot.HooksMod.queue(">mod_reforged", function() {
	::includeFiles(::IO.enumerateFiles("mod_crock_pot/hooks_last"));
}, ::Hooks.QueueBucket.Last);

::CrockPot.HooksMod.queue(">mod_reforged", function() {
	// ::includeFiles(::IO.enumerateFiles("mod_crock_pot/hooks_afterhooks"));
}, ::Hooks.QueueBucket.AfterHooks);

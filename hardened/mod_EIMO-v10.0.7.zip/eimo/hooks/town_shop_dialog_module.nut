::EIMO.HookMod.hook("scripts/ui/screens/world/modules/world_town_screen/town_shop_dialog_module", function(q) {
	q.eimo_onSellAllButtonClicked <- function()
	{
		local removedItem;
		local shopStash = this.m.Shop.getStash();
		local moneyToAdd = 0;

		for (local i = ::World.Assets.getStash().getCapacity() - 1; i >= 0 ; --i)
		{
			if (this.Stash.getItemAtIndex(i).item != null)
			{
				if (this.Stash.getItemAtIndex(i).item.eimo_shouldBeSold())
				{
					removedItem = this.Stash.removeByIndex(i);

					if (removedItem != null)
					{
						shopStash.add(removedItem);
						moneyToAdd += removedItem.getSellPrice();
						if (removedItem.isBought())
						{
							removedItem.setBought(false);
						}
						else
						{
							removedItem.setSold(true);
						}

						if (removedItem.isItemType(::Const.Items.ItemType.TradeGood))
						{
							::World.Statistics.getFlags().increment("TradeGoodsSold");
						}
					}
				}
			}
		}

		if (moneyToAdd != 0)
		{
			::World.Assets.addMoney(moneyToAdd);
		}

		local result = {
			Result = 0,
			Assets = this.m.Parent.queryAssetsInformation(),
			Shop = [],
			Stash = [],
			StashSpaceUsed = this.Stash.getNumberOfFilledSlots(),
			StashSpaceMax = this.Stash.getCapacity(),
			IsRepairOffered = this.m.Shop.isRepairOffered()
		}

		::UIDataHelper.convertItemsToUIData(this.m.Shop.getStash().getItems(), result.Shop, ::Const.UI.ItemOwner.Shop);
		result.Stash = ::UIDataHelper.convertStashToUIData(false, this.m.InventoryFilter);

		if (::World.Statistics.getFlags().has("TradeGoodsSold") && ::World.Statistics.getFlags().get("TradeGoodsSold") >= 10)
		{
			this.updateAchievement("Trader", 1, 1);
		}

		if (::World.Statistics.getFlags().has("TradeGoodsSold") && ::World.Statistics.getFlags().get("TradeGoodsSold") >= 50)
		{
			this.updateAchievement("MasterTrader", 1, 1);
		}

		return result;
	}
});

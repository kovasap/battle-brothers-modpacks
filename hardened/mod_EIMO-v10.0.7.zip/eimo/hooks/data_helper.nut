::EIMO.HookMod.hook("scripts/ui/global/data_helper", function(q){
	q.convertItemToUIData = @(__original) function( _item, _forceSmallIcon, _owner = null ) {
		if (_item == null) return null;

		local result = __original(_item, _forceSmallIcon, _owner);

		if (::EIMO.isDamaged(_item))
		{
			result.eimo_repairProfit <- ::Math.round(::EIMO.getRepairProfit(_item));
		} else {
			result.eimo_repairProfit <- 0;
		}

		result.eimo_forSale <- _item.eimo_isSetForSale();
		result.eimo_idFavorite <- _item.eimo_isIDFavorite();
		result.eimo_favorite <- _item.eimo_isFavorite()

		return result;
	}
})

// Collection of tests to find errors in the dynamic spawn party definitions early
::DynamicSpawns.Tests <- {
	IsTesting = false,
	/** check all Parties, UnitBlocks and Units for consistency. Print Errors into the log if there are surface level problems
	*
	* @Param _printInfo controls whether general information like summaries should be displayed
	* @Param _printWarnings controls whether warnings should be displayed
	* @Return amount of warnings and errors generated and printed
	*/
	function checkAll( _printInfo = true, _printWarnings = true )
	{
		local logsGenerated = 0;

		 if (_printInfo) ::logInfo("Checking " + ::DynamicSpawns.Parties.LookupMap.len() + " parties, " + ::DynamicSpawns.UnitBlocks.LookupMap.len() + " blocks and " + ::DynamicSpawns.Units.LookupMap.len() + " units for consistency...");

		 // check all currently registered Parties
		 foreach (partyKey, partyDef in ::DynamicSpawns.Parties.LookupMap)
		 {
			logsGenerated += ::DynamicSpawns.Tests.checkPartyDef(partyKey, partyDef, _printInfo, _printWarnings);
		 }

		 // check all currently registered Unit Blocks
		 foreach (unitBlockKey, unitBlockDef in ::DynamicSpawns.UnitBlocks.LookupMap)
		 {
			logsGenerated += ::DynamicSpawns.Tests.checkUnitBlockDef(unitBlockKey, unitBlockDef, _printInfo, _printWarnings);
		 }

		 // check all currently registered Units
		 foreach (unitKey, unitDef in ::DynamicSpawns.Units.LookupMap)
		 {
			logsGenerated += ::DynamicSpawns.Tests.checkUnitDef(unitKey, unitDef, _printInfo, _printWarnings);
		 }

		 // check all vanilla parties
		 foreach(vanillyKey, vanillaParty in ::Const.World.Spawn)
		 {
			logsGenerated += ::DynamicSpawns.Tests.checkVanillaParty(vanillyKey, vanillaParty, _printInfo, _printWarnings);
		 }

		 return logsGenerated;
	}

	function checkPartyDef( _partyKey, _partyDef, _printInfo = true, _printWarnings = true )
	{
		local logsGenerated = 0;
		if (_partyDef instanceof ::MSU.Class.WeightedContainer) return logsGenerated;	// We skip all variants because the parties they contain are separate entries in the LookupMap

		// Static Units
		if ("StaticUnitDefs" in _partyDef)
		{
			foreach(unitDef in _partyDef.StaticUnitDefs)
			{
				if ("BaseID" in unitDef && !(unitDef.BaseID in ::DynamicSpawns.Units.LookupMap))
				{
					::logError("Test Error: The Static Unit \"" + unitDef.BaseID + "\" from the party \"" + _partyKey + "\" does not exist!");
					logsGenerated++;
				}
			}
		}

		// Unit Blocks
		if ("UnitBlockDefs" in _partyDef)
		{
			foreach(unitBlockDef in _partyDef.UnitBlockDefs)
			{
				if ("BaseID" in unitBlockDef && !(unitBlockDef.BaseID in ::DynamicSpawns.UnitBlocks.LookupMap))
				{
					::logError("Test Error: The Unit Block \"" + unitBlockDef.BaseID + "\" from the party \"" + _partyKey + "\" does not exist!");
					logsGenerated++;
				}
			}
		}
		return logsGenerated;
	}

	function checkUnitBlockDef( _unitBlockKey, _unitBlockDef, _printInfo = true, _printWarnings = true )
	{
		local logsGenerated = 0;
		if (!("UnitDefs" in _unitBlockDef))
		{
			::logError("Test Error: The UnitBlock \"" + _unitBlockKey + "\" has no units defined for it. It will never produce any units!");
			logsGenerated++;
			return logsGenerated;
		}

		// Unit Defs
		foreach(unitDef in _unitBlockDef.UnitDefs)
		{
			if ("BaseID" in _unitBlockDef && !(_unitBlockDef.BaseID in ::DynamicSpawns.UnitBlocks.LookupMap))
			{
				::logError("Test Error: The Unit \"" + _unitBlockDef.BaseID + "\" from the block \"" + _unitBlockKey + "\" does not exist!");
				logsGenerated++;
			}
		}
		return logsGenerated;
	}

	function checkUnitDef( _unitKey, _unitDef, _printInfo = true, _printWarnings = true )
	{
		local logsGenerated = 0;
		if (!("Troop" in _unitDef))
		{
			::logError("Test Error: The Unit \"" + _unitKey + "\" has no Troop defined for it. It will never produce any units!");
			logsGenerated++;
		}
		return logsGenerated;
	}

	function checkVanillaParty( _vanillyKey, _vanillaParty, _printInfo = true, _printWarnings = true)
	{
		local logsGenerated = 0;
		if (::DynamicSpawns.Static.retrieveDynamicParty(_vanillaParty) == null)
		{
			if (_vanillyKey == "Unit") return logsGenerated;	// This is a special vanilla subtable that is not an actual party
			if (_vanillyKey == "Troops") return logsGenerated;	// This is a special vanilla subtable that is not an actual party
			if (_printWarnings)
			{
				::logWarning("Test Warning: There exists no dynamic party for the vanilla party \"" + _vanillyKey + "\". Its vanilla spawning behavior will be used.");
				logsGenerated++;
			}
		}
		return logsGenerated;
	}

	function spawnWorldParty( _spawn, _resources, _tile = null, _factionType = ::Const.FactionType.Bandits )
	{
		if (_tile == null)
		{
			local playerTile = ::World.State.getPlayer().getTile();
			_tile = ::World.getTileSquare(playerTile.SquareCoords.X - 2, playerTile.SquareCoords.Y - 2);
		}

		local minibossify = 0;
		::World.FactionManager.getFactionOfType(_factionType).spawnEntity(_tile, "DynamicSpawns Test", false, _spawn, _resources, minibossify);

		::World.setPlayerPos(::World.State.getPlayer().getPos());
		::World.setPlayerVisionRadius(::World.State.getPlayer().getVisionRadius());
	}

	function printSpawn( _partyID, _resources, _fixedResources = false, _detailedLogging = false )
	{
		local wasTesting = ::DynamicSpawns.Tests.IsTesting;
		::DynamicSpawns.Tests.IsTesting = true;
		local wasLogging = ::DynamicSpawns.Const.Logging;
		::DynamicSpawns.Const.Logging = true;
		local wasDetailedLogging = ::DynamicSpawns.Const.DetailedLogging;
		::DynamicSpawns.Const.DetailedLogging = _detailedLogging;
		if (!_fixedResources)
			_resources *= ::MSU.Math.randf(0.7, 1.0);
		local ret = ::DynamicSpawns.Static.getRegisteredPartyVariant(_partyID, _resources).spawn(_resources);
		::DynamicSpawns.Tests.IsTesting = wasTesting;
		::DynamicSpawns.Const.Logging = wasLogging;
		::DynamicSpawns.Const.DetailedLogging = wasDetailedLogging;
		return ret;
	}

	function printSpawnAverage( _partyID, _resources, _fixedResources = false, _iterations = 500 )
	{
		local addValues;
		addValues = function( _parent, _spawnable, _isUnitInstance = false )
		{
			local id = _spawnable.getLogName();
			local t = _spawnable.getTotal();

			if (!_isUnitInstance)
			{
				if (!(id in _parent))
				{
					_parent[id] <- { Total = t,	Min = t, Max = t };

					if (_spawnable instanceof ::DynamicSpawns.Class.Unit)
						_parent[id].Cost <- _spawnable.Cost;
				}
				else
				{
					_parent[id].Total += t;
					_parent[id].Min = ::Math.min(_parent[id].Min, t);
					_parent[id].Max = ::Math.max(_parent[id].Max, t);
				}
			}

			foreach (spawnable in _spawnable.__DynamicSpawnables)
			{
				addValues(_parent[id], spawnable);
			}
			foreach (spawnable in _spawnable.__StaticSpawnables)
			{
				addValues(_parent[id], spawnable);
			}

			if (_spawnable instanceof ::DynamicSpawns.Class.Unit && _spawnable.__Instances.len() > 0 && _spawnable.__Instances[0] != _spawnable)
			{
				foreach (instance in _spawnable.__Instances)
				{
					addValues(_parent, instance, true);
				}
			}
		}
		local printValues;
		printValues = function( _key, _data )
		{
			::DynamicSpawns.Indent++;
			::logInfo(format("%s%s : %.2f (%i - %i)", ::DynamicSpawns.getIndent(), _key, (_data.Total / _iterations), _data.Min, _data.Max));
			local t = delete _data.Total;
			// Only print subspawnables for spawnables that had at least 1 unit spawned
			// otherwise its just spam.
			if (t != 0)
			{
				delete _data.Min;
				delete _data.Max;
				local ordered = [];
				foreach (key, value in _data)
				{
					if (key == "Cost")
						continue;

					if ("Cost" in value)
						ordered.push([key, value]);
					else
						printValues(key, value);
				}
				if (ordered.len() != 0)
				{
					ordered.sort(@(a, b) a[1].Cost <=> b[1].Cost);
					foreach (entry in ordered)
					{
						printValues(entry[0], entry[1]);
					}
				}
			}

			::DynamicSpawns.Indent--;
		}

		local wasTesting = ::DynamicSpawns.Tests.IsTesting;
		::DynamicSpawns.Tests.IsTesting = true;
		local wasLogging = ::DynamicSpawns.Const.Logging;
		::DynamicSpawns.Const.Logging = false;
		local wasDetailedLogging = ::DynamicSpawns.Const.DetailedLogging;
		::DynamicSpawns.Const.DetailedLogging = false;

		local data = {};
		local worth = 0.0;

		local party;
		local resources = _resources;
		for (local i = 0; i < _iterations; i++)
		{
			if (!_fixedResources)
				resources = _resources * ::MSU.Math.randf(0.7, 1.0);
			party = ::DynamicSpawns.Static.getRegisteredPartyVariant(_partyID, resources);
			party.spawn(resources);
			worth += party.getWorth();
			party.ID = _partyID;
			addValues(data, party);
		}

		_iterations = _iterations.tofloat();

		printValues(_partyID, data[_partyID]);
		::logInfo(format("Average Worth: %.2f", worth / _iterations));

		::DynamicSpawns.Tests.IsTesting = wasTesting;
		::DynamicSpawns.Const.Logging = wasLogging;
		::DynamicSpawns.Const.DetailedLogging = wasDetailedLogging;
	}

	function printVanillaSpawnAverage( _vanillaPartyList, _resources, _fixedResources = false, _iterations = 500 )
	{
		if (typeof _vanillaPartyList == "string")
			_vanillaPartyList = ::Const.World.Spawn[_vanillaPartyList];

		if (!_fixedResources)
		{
			if (_vanillaPartyList[_vanillaPartyList.len() - 1].Cost < _resources * 0.7)
			{
				_resources = _vanillaPartyList[_vanillaPartyList.len() - 1].Cost;
			}
		}
		else if (_iterations != 1)
		{
			// For performance because with fixed resources it will always be the same vanilla party that's selected
			// We don't set it to 1 because of the way the log is printed later which checks for _iterations == 1
			_iterations = 2;
		}

		local scriptToTroopNameMap = {};
		foreach (key, troop in ::Const.World.Spawn.Troops)
		{
			scriptToTroopNameMap[troop.Script] <- key;
		}

		local t = {
			Total = 0,
			NumMin = 999,
			NumMax = 0
			Worth = 0
		};

		local potential;
		local total_weight;
		for (local i =0; i < _iterations; i++)
		{
			potential = [];
			total_weight = 0;
			if (!_fixedResources)
			{
				foreach(party in _vanillaPartyList )
				{
					if (party.Cost < _resources * 0.7)
					{
						continue;
					}

					if (party.Cost > _resources)
					{
						break;
					}

					potential.push(party);
					total_weight += party.Cost;
				}
			}

			local p;

			if (potential.len() == 0)
			{
				local best;
				local bestCost = 9000;

				foreach (party in _vanillaPartyList)
				{
					if (::Math.abs(_resources - party.Cost) <= bestCost)
					{
						best = party;
						bestCost = ::Math.abs(_resources - party.Cost);
					}
				}

				p = best;
			}
			else
			{
				local pick = ::Math.rand(1, total_weight);

				foreach (party in potential)
				{
					if (pick <= party.Cost)
					{
						p = party;
						break;
					}

					pick -= party.Cost;
				}
			}

			t.Worth += p.Cost;
			local totalBefore = t.Total;
			foreach (troop in p.Troops)
			{
				t.Total += troop.Num;
				local name = scriptToTroopNameMap[troop.Type.Script];
				local n = troop.Num;
				if (!(name in t))
				{
					t[name] <- {
						NumMin = n,
						NumMax = n,
						Num = n,
						PartyCount = 1
					}
				}
				else
				{
					t[name].Num += n;
					t[name].NumMin = ::Math.min(t[name].NumMin, n);
					t[name].NumMax = ::Math.max(t[name].NumMax, n);
					t[name].PartyCount++;
				}
			}

			local partyTotal = t.Total - totalBefore;
			t.NumMin = ::Math.min(t.NumMin, partyTotal);
			t.NumMax = ::Math.max(t.NumMax, partyTotal);
		}

		_iterations = _iterations.tofloat();

		if (_iterations == 1)
			::logInfo("-- Vanilla Spawn -- ");
		else
			::logInfo("-- Vanilla Spawn Average -- ");

		::logInfo(format("Total: %.2f (%i - %i)", (t.Total / _iterations), delete t.NumMin, delete t.NumMax));
		local worth = t.Worth / _iterations;
		delete t.Total;
		delete t.Worth;

		::DynamicSpawns.Indent += 2;
		foreach (name, info in t)
		{
			::logInfo(format("%s%s : %.2f (%i - %i)", ::DynamicSpawns.getIndent(), name, (info.Num / _iterations), info.PartyCount < _iterations ? 0 : info.NumMin, info.NumMax));
		}
		::DynamicSpawns.Indent -= 2;
		if (_iterations == 1)
			::logInfo(format("Worth: %.2f", worth));
		else
			::logInfo(format("Average Worth: %.2f", worth));

		::logInfo(" ------- ");
	}

	function printVanillaSpawn( _vanillaPartyList, _resources, _fixedResources = false )
	{
		this.printVanillaSpawnAverage(_vanillaPartyList, _resources, _fixedResources, 1);
	}

	function compareSpawn( _partyID, _resources, _fixedResources = false )
	{
		if (!_fixedResources)
		{
			_resources *= ::MSU.Math.randf(0.7, 1.0);
			_fixedResources = true;
		}
		this.printVanillaSpawn(_partyID, _resources, _fixedResources);
		this.printSpawn(_partyID, _resources, _fixedResources);
	}

	function compareSpawnAverage( _partyID, _resources, _fixedResources = false, _iterations = 500 )
	{
		this.printVanillaSpawnAverage(_partyID, _resources, _fixedResources, _iterations);
		this.printSpawnAverage(_partyID, _resources, _fixedResources, _iterations);
	}

    // Returns a copy of a vanilla spawnlist where the given units are merged.
    // E.g. OrcWarrior and OrcWarriorLOW can be merged into one.
    // _mergeUnits is an array which contains arrays of units which are all replaced with the first unit of that array.
    // e.g. [ ["OrcWarrior", "OrcWarriorLOW"], ["OrcYoung", "OrcYoungLOW"] ]
    // will replace OrcWarriorLOW with OrcWarrior and OrcYoungLOW with OrcYoung.
	function getVanillaPartyWithMergedUnits( _party, _mergeUnits )
	{
		local redirect = {};
		foreach (b in _mergeUnits)
		{
			local target = ::Const.World.Spawn.Troops[b[0]];
			for (local i = 1; i < b.len(); i++)
			{
				redirect[::Const.World.Spawn.Troops[b[i]]] <- target;
			}
		}

		local ret = [];
		foreach (p in _party)
		{
			local troops = {};
			foreach (t in p.Troops)
			{
				local type = t.Type;
				if (type in redirect)
				{
					type = redirect[type];
				}
				if (type in troops)
				{
					troops[type] += t.Num;
				}
				else
				{
					troops[type] <- t.Num;
				}
			}
			local troopsArray = [];
			foreach (t, num in troops)
			{
				troopsArray.push({Type = t, Num = num});
			}
			ret.push({
				Cost = p.Cost,
				Troops = troopsArray
			});
		}

		return ret;
	}

	function printVanillaPartyInfo( _party, _mergeUnits = null, _filterFunc = null )
	{
		if (typeof _party == "string")
			_party = ::Const.World.Spawn[_party];

		if (_filterFunc != null)
			_party = _party.filter(@(_, _p) _filterFunc(_p));

		if (_party.len() == 0)
		{
			::logInfo("No parties after filter.");
			return;
		}

		local troopToNameMap = {};
		foreach (key, troop in ::Const.World.Spawn.Troops)
		{
			troopToNameMap[troop] <- key;
		}

		if (_mergeUnits != null)
		{
			_party = this.getVanillaPartyWithMergedUnits(_party, _mergeUnits);
		}

		local troopInfo = {};
		local sizes = array(_party.len());

		foreach (i, party in _party)
		{
			local size = 0.0;
			foreach (troop in party.Troops)
			{
				size += troop.Num;
			}
			sizes[i] = size;
			foreach (troop in party.Troops)
			{
				local name = troopToNameMap[troop.Type];
				if (!(name in troopInfo))
				{
					troopInfo[name] <- {
						StartingResourceMin = party.Cost,
						StartingResourceMax = party.Cost,
						PartySizeMin = size,
						NumMin = troop.Num,
						NumMax = troop.Num,
						RatioMin = troop.Num / size,
						RatioMax = troop.Num / size,
						PartyCount = 1,
						FirstPartyIdx = i,
						LastPartyIdx = i
					}
				}
				else
				{
					local info = troopInfo[name];
					info.StartingResourceMax = party.Cost;
					info.NumMin = ::Math.min(info.NumMin, troop.Num);
					info.NumMax = ::Math.max(info.NumMax, troop.Num);
					info.RatioMin = ::Math.minf(info.RatioMin, troop.Num / size);
					info.RatioMax = ::Math.maxf(info.RatioMax, troop.Num / size);
					info.PartyCount++;
					info.LastPartyIdx = i;
				}
			}
		}

		sizes.sort();
		local sizeMin = sizes.len() == 0 ? 0 : sizes[0];
		local sizeMax = sizes.len() == 0 ? 0 : sizes.top();

		::logInfo("Total variants: " + _party.len());
		::logInfo("SizeMin: " + sizeMin);
		::logInfo("SizeMax: " + sizeMax);
		::logInfo("CostMin: " + _party[0].Cost);
		::logInfo("CostMax: " + _party.top().Cost);
		foreach (name, info in troopInfo)
		{
			local startingResourceMin = info.StartingResourceMin == _party[0].Cost ? "0" : info.StartingResourceMin + "";
			local startingResourceMax = info.StartingResourceMax == _party.top().Cost ? "None" : info.StartingResourceMax + "";
			local partySizeMin = info.PartySizeMin == sizeMin ? "None" : info.PartySizeMin + "";
			local exclusionChance = (1.0 - info.PartyCount.tofloat() / (1 + info.LastPartyIdx - info.FirstPartyIdx)) * 100;
			if (info.PartyCount < _party.len())
			{
				info.NumMin = 0;
				info.RatioMin = 0;
			}
			::logInfo(format("%s: StartingResourceMin: %s, StartingResourceMax: %s, PartySizeMin: %s, NumMin: %i, NumMax: %i, RatioMin: %.2f, RatioMax: %.2f, ExclusionChance: %.1f", name, startingResourceMin, startingResourceMax, partySizeMin, info.NumMin, info.NumMax, info.RatioMin, info.RatioMax, exclusionChance));
		}
	}

	// Prints all the parties in a vanilla spawnlist. _mergeUnits can be used (see documentation of getVanillaPartyWithMergedUnits)
	// _filterFunc can be used to filter down the vanilla spawnlist.
	function printVanillaSpawnlist( _party, _mergeUnits = null, _filterFunc = null )
	{
		if (typeof _party == "string")
			_party = ::Const.World.Spawn[_party];

		if (_filterFunc != null)
			_party = _party.filter(@(_, _p) _filterFunc(_p));

		if (_party.len() == 0)
		{
			::logInfo("No parties after filter.");
			return;
		}

		if (_mergeUnits != null)
		{
			_party = this.getVanillaPartyWithMergedUnits(_party, _mergeUnits);
		}

		local troopToNameMap = {};
		foreach (key, troop in ::Const.World.Spawn.Troops)
		{
			troopToNameMap[troop] <- key;
		}

		local total = 0.0;

		local mapFunc1 = function( _t )
		{
			total += _t.Num;
			return [troopToNameMap[_t.Type], _t.Num];
		}

		local mapFunc2 = @( _entry ) format("%s: %i (%.2f)", _entry[0], _entry[1], _entry[1] / total);

		foreach (p in _party)
		{
			local info = p.Troops.map(mapFunc1).map(mapFunc2).reduce(@(_a, _b) _a + ", " + _b);
			::logInfo(format("%i (%i) -- %s", p.Cost, total.tointeger(), info));
			total = 0.0;
		}

		// Go through each party's troops
		// Check which troops are present. Combine them into a string key
		// Bump number

		local compositions = {};
		foreach (p in _party)
		{
			local troops = [];

			foreach (t in p.Troops)
			{
				troops.push(troopToNameMap[t.Type]);
			}

			local key = ::DynamicSpawns.__stableSort(troops).reduce(@(_a, _b) _a + ", " + _b);

			if (key in compositions)
			{
				compositions[key].Num++;
				compositions[key].CostMin = ::Math.min(compositions[key].CostMin, p.Cost);
				compositions[key].CostMax = ::Math.max(compositions[key].CostMax, p.Cost);
			}
			else
			{
				compositions[key] <- {
					Num = 1,
					CostMin = p.Cost
					CostMax = p.Cost
				};
			}
		}
		::logInfo("Total Variants: " + _party.len() + " of which: Composition (Num, CostMin - CostMax)")
		foreach (c, info in compositions)
		{
			::logInfo(format("- %s (%i, %i - %i)", c, info.Num, info.CostMin, info.CostMax));
		}
	}

	// Similar to printVanillaPartyInfo but allows you to specify `_buckets` of resources values
	// and prints info for each bucket separately. For _mergeUnits see the documentation of getVanillaPartyWithMergedUnits.
	// _filterFunc can be used to filter the spawnlist.
	// _buckets is an array of len 2 arrays which are the start and end of Cost.
	// e.g. [ [100, 200], [200, 300], [300, 600] ]
	// willl print the info for the spawnlist in the Cost Range 100-200, 200-300 and 300-600.
	function printVanillaPartyInfoSegments( _party, _mergeUnits = null, _filterFunc = null, _buckets = null )
	{
		if (typeof _party == "string")
			_party = ::Const.World.Spawn[_party];

		if (_filterFunc != null)
			_party = _party.filter(@(_, _p) _filterFunc(_p));

		if (_party.len() == 0)
		{
			::logInfo("No parties after filter.");
			return;
		}

		local min = _party[0].Cost;
		local max = _party.top().Cost;

		local currMin = -100;
		local currMax = 0;

		_filterFunc = @(_party) _party.Cost > currMin && _party.Cost < currMax;

		local currBucket = 0;
		local stop = false;

		while (currMax <= max)
		{
			if (_buckets != null)
			{
				currMin = _buckets[currBucket][0];
				currMax = _buckets[currBucket++][1];
			}
			else
			{
				currMin += 100;
				currMax += 100;
			}

			printVanillaPartyInfo(_party, _mergeUnits, _filterFunc);
		}
		printVanillaPartyInfo(_party, _mergeUnits);
	}
};

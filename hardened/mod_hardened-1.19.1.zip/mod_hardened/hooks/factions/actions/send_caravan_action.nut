::Hardened.HooksMod.hook("scripts/factions/actions/send_caravan_action", function(q) {
	q.onExecute = @(__original) function( _faction )
	{
		// We switcheroo this.m.Start.m.Resources for southern caravans, to make them spawn with less resources
		// Vanilla spawns southern caravans with 60% of the resources of the town they come from (as opposed to 50% for northern ones)
		// But in Hardened, northern towns have 20% less resources and city states have 40% more resources, so we equalize that vanilla multiplier
		local oldResources = this.m.Start.m.Resources;
		if (_faction.hasTrait(::Const.FactionTrait.OrientalCityState))
		{
			this.m.Start.m.Resources *= 0.8;
		}

		// We switcheroo getProduce, so that vanilla doesnt add its wares items to the caravan. Instead we want to have control over them being added
		local start = (typeof this.m.Start == "instance" && this.m.Start instanceof ::WeakTableRef) ? this.m.Start.get() : this.m.Start;
		local oldGetProduce = start.getProduce;
		start.getProduce = function() { return [] };

		__original(_faction);

		this.m.Start.m.Resources = oldResources;
		start.getProduce = oldGetProduce;

		if (::MSU.isNull(this.m.Faction)) return;

		local lastSpawnedParty = this.m.Faction.m.HD_LastSpawnedParty;
		if (::MSU.isNull(lastSpawnedParty)) return;

		// Feat: Display the banner of the noble house for civilians caravans
		lastSpawnedParty.getSprite("banner").Visible = true;
		lastSpawnedParty.getSprite("banner").setOffset(::Hardened.Const.CaravanBannerOffset);

		// We now allow a customizable amount of trade goods. And we mark those trade goods in a special way, so that they drop in mint condition alter on
		if (start.getProduce().len() != 0)
		{
			for (local i = 0; i < this.HD_getProduceAmount(_faction); ++i)
			{
				lastSpawnedParty.HD_addMintItemToInventory(::MSU.Array.rand(start.getProduce()));
			}
		}
	}

// New Functions
	q.HD_getProduceAmount <- function( _faction )
	{
		local produceAmount = 2;

		if (this.m.Start.getSize() == 3) produceAmount++;
		if (_faction.hasTrait(::Const.FactionTrait.OrientalCityState)) produceAmount++;

		return produceAmount;
	}
});


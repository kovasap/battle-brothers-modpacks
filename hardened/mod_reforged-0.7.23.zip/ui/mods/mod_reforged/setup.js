var Reforged = {
	ID : "mod_reforged",
	JSConnectionID : "ReforgedJSConnection",
	Hooks : {}
}

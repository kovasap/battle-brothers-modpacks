this.cp_beast_cave_location <- this.inherit("scripts/entity/world/location", {
	m = {},
	function getDescription()
	{
		return "Something valuable has been stashed here, easily overlooked by passersby.";
	}

	function create()
	{
		this.location.create();
		this.m.TypeID = "location.hd_hidden_cache";
		this.m.LocationType = ::Const.World.LocationType.Passive;
		this.m.IsDespawningDefenders = false;
		this.m.OnEnter = "event.location.hd_hidden_cache_enter";

		// We don't show the banner or defender of this location so that the player has to guess, whether it is orcs or beasts
		this.m.Resources = 200;
		this.m.VisibilityMult = 0.3;	// Stashes are extremely hard to find
	}

	function onSpawned()
	{
		this.m.Name = ::World.EntityManager.getUniqueLocationName(::Const.World.LocationNames.HD_HiddenCache);
		this.location.onSpawned();
	}

	function onDropLootForPlayer( _lootTable )
	{
		this.location.onDropLootForPlayer(_lootTable);

		// One treasure item is guaranteed
		this.dropTreasure(2, [	// Probably taken off a dead human corpse
			"loot/signet_ring_item",
			"loot/bead_necklace_item",
			"loot/jade_broche_item",
			"loot/bead_necklace_item",
		], _lootTable);

		// Then you either find a second treasure, or some strange meat and armor parts (fresh game?)
		if (::Math.rand(1, 3) == 1)
		{
			this.dropArmorParts(::Math.rand(5, 10), _lootTable);
		}
		else
		{
			this.dropFood(1, [
				"strange_meat_item"
			], _lootTable);
		}
	}

	function onInit()
	{
		this.location.onInit();
		local body = this.addSprite("body");

		if (this.getTile().Type == ::Const.World.TerrainType.Steppe)
		{
			body.setBrush("world_cave_steppe_01");
		}
		else
		{
			body.setBrush("world_cave_01");
		}
	}

// New Functions
	function HD_generateLoot()
	{

	}

});


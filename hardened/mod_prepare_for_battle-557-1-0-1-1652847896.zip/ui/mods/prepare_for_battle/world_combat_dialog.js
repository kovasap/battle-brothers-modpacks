var PrepareForBattle = {
	ID : "mod_prepare_for_battle",
	IsAmbush : null
}

PrepareForBattle.WorldCombatDialog_loadFromData = WorldCombatDialog.prototype.loadFromData;
WorldCombatDialog.prototype.loadFromData = function (_data)
{
	PrepareForBattle.IsAmbush = !_data.AllowFormationPicking;
	PrepareForBattle.WorldCombatDialog_loadFromData.call(this,_data);
}

PrepareForBattle.WorldCombatDialog_createButtons = WorldCombatDialog.prototype.createButtons;
WorldCombatDialog.prototype.createButtons = function (_allowDisengage, _disengageText)
{
	PrepareForBattle.WorldCombatDialog_createButtons.call(this, _allowDisengage, _disengageText);

	if (!PrepareForBattle.IsAmbush || MSU.getSettingValue(PrepareForBattle.ID, "ShowAmbushed"))
	{
		var self = this;
		var layout = $('<div class="l-prepare-button"/>');
		this.mDialogContainer.findDialogFooterContainer().find('.l-button-bar:first').append(layout);
		layout.createTextButton("Prepare!", function()
		{
			self.PrepareForBattle_notifybackendPrepareForBattle();
		}, '', 1);
		if (!_allowDisengage)
		{
			layout.css('top', '-10.5rem')
		}
	}
}

WorldCombatDialog.prototype.PrepareForBattle_notifybackendPrepareForBattle = function ()
{
	SQ.call(this.mSQHandle, "PrepareForBattle_show", null, null)
}

::Hardened.HooksMod.hook("scripts/items/weapons/pitchfork", function(q) {
	// We overwrite Reforged skill additions, because we dont hand out any discounts
	q.onEquip = @() { function onEquip()
	{
		this.weapon.onEquip();

		this.addSkill(::Reforged.new("scripts/skills/actives/impale", function(o) {
			o.m.Icon = "skills/active_57.png";
			o.m.IconDisabled = "skills/active_57_sw.png";
			o.m.Overlay = "active_57";
		}));

		this.addSkill(::Reforged.new("scripts/skills/actives/repel", function(o) {
			o.m.Icon = "skills/active_58.png";
			o.m.IconDisabled = "skills/active_58_sw.png";
			o.m.Overlay = "active_58";
		}));
	}}.onEquip;
});

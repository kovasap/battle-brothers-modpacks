::Hardened.HooksMod.hook("scripts/items/weapons/greenskins/goblin_falchion", function(q) {
	q.create = @(__original) function()
	{
		__original();
		this.addWeaponType(::Const.Items.WeaponType.Dagger, true);
	}

	// We overwrite Reforged skill additions, because we dont hand out any discounts
	q.onEquip = @(__original) function()
	{
		this.weapon.onEquip();

		this.addSkill(::Reforged.new("scripts/skills/actives/stab", function(o) {
			o.m.IsIgnoredAsAOO = true;	// We ignore this skill because Slash should always be used for AOO or Riposte attacks
		}));

		this.addSkill(::Reforged.new("scripts/skills/actives/slash", function(o) {
			o.m.Icon = "skills/active_78.png";
			o.m.IconDisabled = "skills/active_78_sw.png";
			o.m.Overlay = "active_78";
		}));

		this.addSkill(::new("scripts/skills/actives/riposte"));
	}
});

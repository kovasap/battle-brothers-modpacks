::Hardened.HooksMod.hook("scripts/skills/actives/throw_balls", function(q) {
	q.create = @(__original) function()
	{
		__original();
		this.m.FatigueCost = 15;	// In Vanilla this is 15; In Reforged this is 12
		this.m.MinRange = 1;	// In Vanilla this is 2
		this.m.AdditionalAccuracy -= this.m.AdditionalHitChance;	// As a result of reducing the minimum range the "this.m.AdditionalHitChance" kicks in one tile earlier. We fix that issue with this line

		// We change the injuries to be purely blunt, mainly to make the damage inflicted by this item to be consistently blunt, instead of only blunt half the time
		this.m.InjuriesOnBody = ::Const.Injury.BluntBody;	// Vanilla: BluntAndPiercingBody
		this.m.InjuriesOnHead = ::Const.Injury.BluntHead;	// Vanilla: BluntAndPiercingBody
	}
});

var Hardened = {
	ID : "mod_hardened",
	// JSConnectionID : "HardenedJSConnection",
	Hooks : {}
}

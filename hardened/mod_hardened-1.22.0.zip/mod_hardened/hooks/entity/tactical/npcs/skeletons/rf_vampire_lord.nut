// Hardened completely redesign most NPCs
// For that we overwrite the core generation functions onInit, makeMiniboss, assignRandomEquipment and onSpawned because we completely disregard Reforged or Vanillas design

::Hardened.HooksMod.hook("scripts/entity/tactical/enemies/rf_vampire_lord", function(q) {
	// Overwrite, because we completely replace Reforged stats/skill adjustments with our own
	q.onInit = @() { function onInit()
	{
		this.vampire.onInit();
	}}.onInit;

	// Overwrite, because we want to replace the vampire base function which generates a random vampire dust
	// Feat: vampire lords now guarantee a vampire dust and also drop a jeweled crown
	q.getLootForTile = @() { function getLootForTile(_killer, _loot)
	{
		local ret = this.actor.getLootForTile(_killer, _loot);

		if (this.RF_canDropLootForPlayer(_killer))
		{
			ret.push(::new("scripts/items/misc/vampire_dust_item"));
			ret.push(::new("scripts/items/loot/jeweled_crown_item"));
		}

		return ret;
	}}.getLootForTile;

// Reforged Functions
	// Overwrite, because we completely replace Reforged Perks/Skills that are depending on assigned Loadout
	q.onSpawned = @() function()
	{
	}

// Hardened Functions
	// Assign Socket and adjust Sprites
	q.HD_onInitSprites = @(__original) function()
	{
		__original();
		this.getSprite("body_detail").Visible = false;
	}

	// Assign Stats and Unconditional Immunities, Perks and Actives
	q.HD_onInitStatsAndSkills = @(__original) function()
	{
		__original();
		// Tweak Base Properties
		local b = this.getBaseProperties();
		b.setValues(::Const.Tactical.Actor.RF_VampireLord);

		// Generic Perks
		this.getSkills().add(::new("scripts/skills/perks/perk_rf_sanguinary"));
		this.getSkills().add(::new("scripts/skills/perks/perk_hold_out"));
		this.getSkills().add(::new("scripts/skills/perks/perk_rf_terrifying_visage"));
		this.getSkills().add(::new("scripts/skills/perks/perk_rf_unstoppable"));
		this.getSkills().add(::new("scripts/skills/perks/perk_hd_elusive"));
		this.getSkills().add(::new("scripts/skills/perks/perk_rf_formidable_approach"));
		this.getSkills().add(::new("scripts/skills/perks/perk_rf_mauler"));

		// Generic Actives
		this.getSkills().getSkillByID("actives.darkflight").setBaseValue("ActionPointCost", 3);
		this.getSkills().add(::new("scripts/skills/actives/rf_sanguine_curse_skill"));
	}
});

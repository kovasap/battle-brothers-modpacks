::Hardened.HooksMod.hook("scripts/ui/screens/tactical/modules/turn_sequence_bar/turn_sequence_bar", function(q) {
	q.convertEntityToUIData = @(__original) function( _entity, isLastEntity = false )
	{
		local ret = __original(_entity, isLastEntity);

		ret.moraleLabel = ret.morale;	// We remove any mention of offensive and defensive reach ignore

		return ret;
	}

	q.initNextRound = @(__original) function()
	{
		__original();

		if (!this.m.IsBattleEnded)
		{
			// Feat: Display in the combat log, whenever a new round starts
			::Tactical.EventLog.logEx("\n=== Round " + this.getCurrentRound() + " ===");
		}
	}

	q.resetActiveEntityCostsPreview = @(__original) { function resetActiveEntityCostsPreview()
	{
		__original();

		if (::Hardened.Camera.PreviousCameraLevel != null)
		{
			::Tactical.getCamera().Level = ::Hardened.Camera.PreviousCameraLevel;
			::Hardened.Camera.PreviousCameraLevel = null;
		}
	}}.resetActiveEntityCostsPreview;

	if (::Hooks.hasMod("mod_extra_keybinds"))
	{
		// Extra Keybinds Fix: script error, when findEntityByID returns null
		// Extra Keybinds never checks, whether the return value is null
		q.ExtraKeybinds_onQueryEntityItemSwaps = @() function( _entityId )
		{
			local entityEntry = this.findEntityByID(this.m.CurrentEntities, _entityId);
			if (entityEntry == null) return null;

			local entity = entityEntry.entity;
			// The code below is a 1:1 copy of Extry Keybinds Code
			if (entity != null && entity.isPlayerControlled())
			{
				local items = entity.getItems().m.Items[::Const.ItemSlot.Bag]
				local ret = array(items.len());
				foreach (i, item in items) // can be null
				{
					if (item == null || item.getSlotType() == ::Const.ItemSlot.Bag) continue;
					local currentItem = entity.getItems().getItemAtSlot(item.getSlotType()) // can be null
					local blockedItem = entity.getItems().getItemAtSlot(item.getBlockedSlotType()) // can be null
					ret[i] = {
						id = item.getID(),
						idx = i,
						instanceId = item.getInstanceID(),
						imagePath = "ui/items/" + item.getIcon(),
						isUsable = item.isChangeableInBattle() && (currentItem == null || currentItem.isChangeableInBattle() && (blockedItem == null || blockedItem.isChangeableInBattle()))
						isAffordable = entity.getItems().isActionAffordable([currentItem, item, blockedItem])
					};
				}
				return ret;
			}
			return null;
		}
	}
});

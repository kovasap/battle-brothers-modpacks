::Hardened.HooksMod.hook("scripts/items/weapons/lute", function(q) {
	q.create = @(__original) function()
	{
		__original();
		this.m.Value = 200;				// Vanilla: 120
		this.m.ConditionMax = 6.0;		// Vanilla: 2.0
		this.m.ArmorDamageMult = 0.5;	// Vanilla: 0.1

		this.addWeaponType(::Const.Items.WeaponType.Mace);
	}

	// Overwrite, because that makes adjusting the stunchance a bit simpler
	q.onEquip = @() function()
	{
		this.weapon.onEquip();

		this.addSkill(::Reforged.new("scripts/skills/actives/strike_down_skill", function(o) {
			o.m.Icon = "skills/active_88.png";
			o.m.IconDisabled = "skills/active_88_sw.png";
			o.m.Overlay = "active_88";
			o.m.IsIgnoredAsAOO = false;		// So that the lute exerts zone of control and provides its reach correctly
		}));

		this.addSkill(::new("scripts/skills/actives/hd_battle_song_skill"));
	}
});

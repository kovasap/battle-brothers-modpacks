::Hardened.HooksMod.hook("scripts/skills/perks/perk_inspiring_presence", function(q) {
	q.m.BonusActionPoints <- 3;		// This many Action Points are given to adjacent allies
	q.m.HD_BraveryMult <- 0.9;

	// Overwrite, because we no longer show a status effect or mini icon for this perk, as it is practically always enabled
	q.isHidden = @() function()
	{
		return true;	// There is no more additional conditional info to be presented, that's not already on the perk
	}

	q.onUpdate = @(__original) function( _properties )
	{
		__original(_properties);
		_properties.BraveryMult *= this.m.HD_BraveryMult;
	}

	q.onNewRound = @(__original) function()
	{
		__original();

		local actor = this.getContainer().getActor();
		local adjacentFactionAllies = ::Tactical.Entities.getFactionActors(actor.getFaction(), actor.getTile(), 1, true);
		foreach (ally in adjacentFactionAllies)
		{
			if (ally.getCurrentProperties().getBravery() >= actor.getCurrentProperties().getBravery()) continue;
			if (ally.getMoraleState() == ::Const.MoraleState.Fleeing) continue;
			if (ally.getCurrentProperties().IsStunned) continue;

			local adjacentEnemies = ::Tactical.Entities.getHostileActors(ally.getFaction(), ally.getTile(), 1, true);
			if (adjacentEnemies.len() != 0)	// We found adjacent enemies
			{
				local skill = ::new("scripts/skills/effects/hd_inspiring_presence_buff_effect");
				skill.m.BonusActionPoints = this.m.BonusActionPoints;
				ally.getSkills().add(skill);
				continue;
			}
		}
	}
});

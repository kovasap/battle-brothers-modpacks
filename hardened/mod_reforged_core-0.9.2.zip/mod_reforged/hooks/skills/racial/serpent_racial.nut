::Reforged.HooksMod.hook("scripts/skills/racial/serpent_racial", function(q) {
	q.create = @(__original) { function create()
	{
		__original();
		this.m.Name = "Serpent";
		this.m.Icon = "ui/orientation/serpent_orientation.png";
		this.m.Description = "This character is a serpent";
		this.m.IsHidden = false;
		if (this.isType(::Const.SkillType.Perk))
			this.removeType(::Const.SkillType.Perk);	// This effect having the type 'Perk' serves no purpose and only causes issues in modding
	}}.create;

	q.getTooltip = @() { function getTooltip()
	{
		local ret = this.skill.getTooltip();
		ret.extend([
			{
				id = 12,
				type = "text",
				icon = "ui/icons/campfire.png",
				text = ::MSU.Text.colorNegative("33%") + " less burning damage received"
			},
			/*{
				id = 13,
				type = "text",
				icon = "ui/icons/initiative.png",
				text = "Initiative is treated as 15 higher for the purpose of turn order if there is a potential target to be hooked nearby"
			}*/
			{
				id = 20,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("Not affected by [$ $|Skill+night_effect]")
			},
			{
				id = 23,
				type = "text",
				icon = "ui/icons/special.png",
				text = ::Reforged.Mod.Tooltips.parseString("Immune to being [$ $|Skill+disarmed_effect]")
			}
		]);
		return ret;
	}}.getTooltip;

	q.onAdded = @() { function onAdded()
	{
		local baseProperties = this.getContainer().getActor().getBaseProperties();

		baseProperties.IsAffectedByNight = false;
		baseProperties.IsImmuneToDisarm = true;
	}}.onAdded;

	q.onUpdate = @(__original) { function onUpdate( _properties )
	{
		// We revert the vanilla changes to DamageReceivedFireMult, as we implement burning ground resistance in onBeforeDamageReceived now
		local old_DamageReceivedFireMult = _properties.DamageReceivedFireMult;
		__original(_properties);
		_properties.DamageReceivedFireMult = old_DamageReceivedFireMult;
	}}.onUpdate;

	q.onBeforeDamageReceived = @() { function onBeforeDamageReceived( _attacker, _skill, _hitInfo, _properties )
	{
		switch (_hitInfo.DamageType)
		{
			case null:
				break;

			case ::Const.Damage.DamageType.Burning:
				_properties.DamageReceivedRegularMult *= 0.66;
				break;

			// In Vanilla they also take reduced damage from firearms and mortars. But those are currently not covered here
		}
	}}.onBeforeDamageReceived;
});

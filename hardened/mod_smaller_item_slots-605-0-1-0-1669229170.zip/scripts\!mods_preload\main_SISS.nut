::modSISS <- {
	ID = "mod_SISS",
	Name = "Smaller Item Slots",
	Version = "0.1.0"
}

::mods_registerMod(::modSISS.ID, ::modSISS.Version, ::modSISS.Name);

::mods_queue(::modSISS.ID, ">mod_legends", function()
{
    ::mods_registerCSS("mod_SISS/item.css");
});

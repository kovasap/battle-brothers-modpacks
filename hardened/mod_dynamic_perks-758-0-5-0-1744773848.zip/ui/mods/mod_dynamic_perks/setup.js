var DynamicPerks = {
	ID : "mod_dynamic_perks",
	Hooks : {},
	PerkGroupColors : ["rgba(255,234,125,1)", "blue", "red", "green", "purple", "orange", "teal", "cyan"],
}

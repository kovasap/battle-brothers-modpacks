
"use strict";

var LocationBrowser = {
	ID : "mod_location_browser",
}

LocationBrowser.Const = {
	LocationType: {
		None: 0,
		Settlement: 1,
		AttachedLocation: 2,
		Lair: 4,
		Mobile: 8,
		Passive: 16,
		Inactive: 32,
		Unique: 64,
		Exploration: 128
	}
};

LocationBrowser.Config = {
	Filter:	// Each of these tables also gain an 'button' and an 'isActive' entry during initialisation
	{
		Buildings:
		{
			Alchemist : {
				img: "icons/buildings/alchemist.png",
				ids: ["building.alchemist"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			Arena : {
				img: "icons/buildings/arena.png",
				ids: ["building.arena"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			Armorsmith : {
				img: "icons/buildings/armorsmith.png",
				ids: ["building.armorsmith", "building.armorsmith_oriental"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			Barber : {
				img: "icons/buildings/barber.png",
				ids: ["building.barber"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			Fletcher : {
				img: "icons/buildings/fletcher.png",
				ids: ["building.fletcher"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			Harbor : {
				img: "icons/buildings/harbor.png",
				ids: ["building.port", "building.port_building"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			Kennels : {
				img: "icons/buildings/kennels.png",
				ids: ["building.kennel"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			Tavern : {
				img: "icons/buildings/tavern.png",
				ids: ["building.tavern"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			Taxidermist : {
				img: "icons/buildings/taxidermist.png",
				ids: ["building.taxidermist", "building.taxidermist_oriental"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			Temple : {
				img: "icons/buildings/temple.png",
				ids: ["building.temple"],	// For some reason the oriental temple doesn't have a unique id. It uses the same as normal temple
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			VetHall : {
				img: "icons/buildings/vet_hall.png",
				ids: ["building.training_hall"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			},
			Weaponsmith : {
				img: "icons/buildings/weaponsmith.png",
				ids: ["building.weaponsmith", "building.weaponsmith_oriental"],
				matchesFilter: function(_locationEntry)
				{
					return LocationBrowser.Config.Filter.matchesBuildingFilter(_locationEntry, this.ids);
				}
			}
		},
		Others:
		{
			Allied : {
				img: "icons/relations.png",
				matchesFilter: function(_locationEntry)
				{
					return _locationEntry.isAlliedWithPlayer;
				}
			},
			Hostile : {
				img: "icons/icon_contract_swords.png",
				matchesFilter: function(_locationEntry)
				{
					return _locationEntry.isHostileWithPlayer;
				}
			},
			Town : {
				img: "icons/morale.png",
				matchesFilter: function(_locationEntry)
				{
					return (_locationEntry.locationType & LocationBrowser.Const.LocationType.Settlement) != 0;
				}
			},
			Camp : {
				img: "icons/difficulty_easy_sw.png",
				matchesFilter: function(_locationEntry)
				{
					return ((_locationEntry.locationType & LocationBrowser.Const.LocationType.Lair) != 0) && _locationEntry.isAttackable;
				}
			},
			Unique : {
				img: "icons/special.png",
				matchesFilter: function(_locationEntry)
				{
					return (_locationEntry.locationType & LocationBrowser.Const.LocationType.Unique) != 0;
				}
			}
		},
		matchesBuildingFilter: function(_locationEntry, _ids)
		{
			var filterSelectionValid = false;
			MSU.iterateObject(_ids, $.proxy(function (_, _filterBuildingID)		// Iterate of every building ID in this filter
			{
				MSU.iterateObject(_locationEntry.buildings, $.proxy(function (_, _locationBuildingID)		// Interate over every building in the _location we were looking at
				{
					if (_filterBuildingID === _locationBuildingID) filterSelectionValid = true;
				}, this));
			}, this));
			return filterSelectionValid;
		},
		reset: function()
		{
			MSU.iterateObject(LocationBrowser.Config.Filter.Buildings, $.proxy(function (_, _fitlerEntry)
			{
				_fitlerEntry.isActive = false;
				_fitlerEntry.button.removeClass("is-active");
			}, this));
			MSU.iterateObject(LocationBrowser.Config.Filter.Others, $.proxy(function (_, _fitlerEntry)
			{
				_fitlerEntry.isActive = false;
				_fitlerEntry.button.removeClass("is-active");
			}, this));
		}
	}
};


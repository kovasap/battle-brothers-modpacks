/*
Formats and Displays all details to a highlighted Location in the details area
*/
var LocationBrowserDetails = function ()
{
	this.mID = "LocationBrowserDetails";

	// DOM Elements:
	this.mLocationDetailsText = null;
}

LocationBrowserDetails.prototype.init = function( _parent )
{
	this.mLocationDetailsText = $('<div class="title-font-normal font-color-subtitle location-browser-details-text"/>');
	_parent.append(this.mLocationDetailsText);
}

LocationBrowserDetails.prototype.display = function( _locationDataEntry )
{
    this.mLocationDetailsText.empty();

	if (_locationDataEntry === null) return;	// In this case the currently displayed information is just deleted

	// console.error("displayLocationDetails: " + _locationDataEntry.name);
	var text = "";
	text += "\n[b]Name:[/b] " + _locationDataEntry.name;
	text += "\n[b]Description:[/b] " + _locationDataEntry.description;
	text += "\n[b]Direction:[/b] " + _locationDataEntry.directionToLocation;
	text += "\n[b]Distance in Tiles:[/b] " + _locationDataEntry.distanceInTiles;
	text += "\n[b]Travel Duration:[/b] " + _locationDataEntry.distanceInDaysHours;
	if (_locationDataEntry.isDebug)
	{
		text += "\n";
		text += "\n[b]Owner:[/b] " + _locationDataEntry.owner;
		text += "\n[b]Faction:[/b] " + _locationDataEntry.faction;
		text += "\n[b]Banner:[/b] " + _locationDataEntry.banner;
		text += "\n[b]Location Type:[/b] " + _locationDataEntry.locationType;
		text += "\n[b]TypeID:[/b] " + _locationDataEntry.typeID;
	}

	var description = $('<div class="description text-font-medium font-bottom-shadow font-color-description"/>');
	this.mLocationDetailsText.append(description);

	var parsedDescriptionText = XBBCODE.process({
		text: text,
		removeMisalignedTags: false,
		addInLineBreaks: true
	});

	description.html(parsedDescriptionText.html);
}

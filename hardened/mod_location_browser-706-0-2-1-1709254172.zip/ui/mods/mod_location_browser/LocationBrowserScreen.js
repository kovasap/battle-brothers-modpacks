"use strict";

var LocationBrowserScreen = function (_parent) {
	MSUUIScreen.call(this);
	this.mID = "LocationBrowserScreen";	// Overwrite variable of base class

	// Variables
	this.mData = null;	// All the data from squirrel side is written in here
	this.mLocationElementPointer = null;	// Tuple of a LocationData packet and a reference to the html element string representing that location
	this.mSelectedLocation = -1;	// Index of the selected Location. -1 = nothing selected
	this.mCurrentFilterTerm = "";

	// Instantiated Classes
	this.mDetails = new LocationBrowserDetails();

	// DOM Elements:
	this.mContainer = null;

		this.mContentLeftContainer = null;
			this.mFilterHeader = null;	// Bar for the Filter
				this.mFilterInput = null;			// Text Input

			this.mFilterContent = null;
				this.mFilterContentScrollContainer = null;

		this.mContentRightContainer = null;
			this.mLocationDetailsText = null;
}

// For some reason this is needed for this mod to not throw errors on game start
LocationBrowserScreen.prototype = Object.create(MSUUIScreen.prototype);
Object.defineProperty(LocationBrowserScreen.prototype, 'constructor', {
	value: LocationBrowserScreen,
	enumerable: false,
	writable: true
});

LocationBrowserScreen.prototype.createDIV = function (_parentDiv) {
	var self = this;

	// Semi-Transparent background plane
	this.mContainer = $('<div class="location-browser-background-plane display-none opacity-none"/>');
	_parentDiv.append(this.mContainer);

	// Main Window - similar to city building window
	var dialogWindow = $('<div class="location-browser-main-layout"/>');
	this.mContainer.append(dialogWindow);

		// Header
		var header = $('<div class="location-browser-header"/>');
		dialogWindow.append(header);

			var titleTextContainer = $('<div class="text-container"/>');
			header.append(titleTextContainer);
			var title = $('<div class="title has-no-sub-title title-font-very-big font-bold font-bottom-shadow font-color-title">' + "Location Browser" + '</div>');
			titleTextContainer.append(title);

	// Header Assets - Even though we don't use it atm
	var assetContainer = $('<div class="location-browser-header-assets"/>');
	dialogWindow.append(assetContainer);

	// Content
	var contentContainer = $('<div class="location-browser-content"/>');
	dialogWindow.append(contentContainer);

		// Content Left (Filtering)
		this.mContentLeftContainer = $('<div class="location-browser-content-left"/>');
		contentContainer.append(this.mContentLeftContainer);
		this.initContentLeft(this.mContentLeftContainer);

		// Content Right (Details)
		this.mContentRightContainer = $('<div class="location-browser-content-right"/>');
		contentContainer.append(this.mContentRightContainer);
		this.mDetails.init(this.mContentRightContainer);

	// Footer
	var footerContainer = $('<div class="location-browser-footer"/>');
	dialogWindow.append(footerContainer);

		var footerContainerButtonBar = $('<div class="location-browser-footer-button-bar"/>');
		footerContainer.append(footerContainerButtonBar);

		MSU.iterateObject(LocationBrowser.Config.Filter.Buildings, $.proxy(function (_id, _entry)
		{
			_entry.button = this.createImageButton(footerContainerButtonBar, _entry.img, function() {
				self.onFilterButtonPressed(_entry);
			});
			_entry.button.bindTooltip({ contentType: 'msu-generic', modId: "mod_location_browser", elementId: "LocationBrowser.Buildings." + _id });
			_entry.isActive = false;
		}, this));

		MSU.iterateObject(LocationBrowser.Config.Filter.Others, $.proxy(function (_id, _entry)
		{
			_entry.button = this.createImageButton(footerContainerButtonBar, _entry.img, function() {
				self.onFilterButtonPressed(_entry);
			});
			_entry.button.bindTooltip({ contentType: 'msu-generic', modId: "mod_location_browser", elementId: "LocationBrowser.Others." + _id });
			_entry.isActive = false;
		}, this));

	this.mIsVisible = false;
};

// Hook into base function from MSUUIScreen
var LocationBrowserScreen_show = LocationBrowserScreen.prototype.show;
LocationBrowserScreen.prototype.show = function( _moveLeftRight, _considerParent )
{
	LocationBrowserScreen_show.call(this, _moveLeftRight, _considerParent);

	LocationBrowser.Config.Filter.reset();
	this.filterRows();	// So that when we open this menue again the items will also still be filtered with the settings from before

	this.mFilterInput.focus();
}

LocationBrowserScreen.prototype.onFilterButtonPressed = function( _pressedEntry )
{
	_pressedEntry.isActive = !_pressedEntry.isActive;
	if (_pressedEntry.isActive === true)
	{
		_pressedEntry.button.addClass("is-active");
	}
	else
	{
		_pressedEntry.button.removeClass("is-active");
	}

	this.mFilterInput.focus();
	this.filterRows();
}

LocationBrowserScreen.prototype.initContentLeft = function( _content ) {
	this.mFilterHeader = $('<div class="location-browser-filter-header ui-control"/>');		// 'ui-control' is needed here for some reason. Otherwise the input text field will stay inactive
	_content.append(this.mFilterHeader);

		var self = this;

		var filterLayout = $('<div class="location-browser-filter-input-container"/>');
		this.mFilterHeader.append(filterLayout);

		this.mFilterInput = $('<input type="text" class="title-font-normal font-color-brother-name"/>');
		filterLayout.append(this.mFilterInput);
		this.mFilterInput.on("keyup", function (_event)
		{
			var currentInput = $(this).val();
			self.mCurrentFilterTerm = currentInput;
			self.filterRows();
		});

	// this.mFilterContent = $('<div class="location-browser-filter-content"/>');
	// _content.append(this.mFilterContent);

    this.mFilterContent = $('<div class="ui-control list location-browser-filter-body"/>');
	_content.append(this.mFilterContent);

    this.mFilterContentScrollContainer = $('<div class="scroll-container"/>');
    this.mFilterContent.append(this.mFilterContentScrollContainer);

     // NOTE: create scrollbar (must be after the list was appended to the DOM!)
     this.mFilterContent.aciScrollBar({
         delta: 2 || 8,
         lineDelay: 0,
         lineTimer: 0,
         pageDelay: 0,
         pageTimer: 0,
         bindKeyboard: false,
         resizable: false,
         smoothScroll: false
     });


}

LocationBrowserScreen.prototype.destroyDIV = function() {
	this.mContainer.empty();
	this.mContainer.remove();
	this.mContainer = null;
};

LocationBrowserScreen.prototype.filterRows = function() {

	var displayedLocationID = -1;
	MSU.iterateObject(this.mData.Locations, $.proxy(function (_, _location)		// Iterate over every location
	{
		var displayRow = true;

		if (_location.name.toLowerCase().search(this.mCurrentFilterTerm.toLowerCase()) == -1)
		{
			displayRow = false;
		}
		else if (this.matchAgainstFilter(_location) === false)
		{
			displayRow = false;
		}

		if (displayRow === true)
		{
			this.mLocationElementPointer[_location.rowID].css("display", "flex");
			if (displayedLocationID == -1) displayedLocationID = _location.rowID;	// First displayed location is automatically marked
		}
		else
		{
			this.mLocationElementPointer[_location.rowID].css("display", "none");
		}
	}, this));
	this.selectLocationEntry(displayedLocationID);
}

LocationBrowserScreen.prototype.matchAgainstFilter = function( _location ) {

	var matchesAllFilter = true;

	// Buildings
	MSU.iterateObject(LocationBrowser.Config.Filter.Buildings, $.proxy(function (_, _buildingFilter)		// Iterate of every filter selection
	{
		if (_buildingFilter.isActive)
		{
			if (_buildingFilter.matchesFilter(_location) === false) matchesAllFilter = false;
		}
	}, this));

	// Others
	MSU.iterateObject(LocationBrowser.Config.Filter.Others, $.proxy(function (_, _otherFilter)		// Iterate of every filter selection
	{
		if (_otherFilter.isActive)
		{
			if (_otherFilter.matchesFilter(_location) === false) matchesAllFilter = false;
		}
	}, this));

	return matchesAllFilter;
}

// Allied, Hostile, Unique, Town, Camp
LocationBrowserScreen.prototype.matchesTypeFilter = function( _location ) {

	var matchesBuildingFilter = true;

	MSU.iterateObject(LocationBrowser.Config.Filter.Buildings, $.proxy(function (_, _andFilterEntry)		// Iterate of every filter selection
	{
		if (_andFilterEntry.isActive)
		{
			var filterSelectionValid = false;
			MSU.iterateObject(_andFilterEntry.ids, $.proxy(function (_, _filterBuldingID)		// Iterate of every building ID in this filter
			{
				MSU.iterateObject(_location.buildings, $.proxy(function (_, _building)		// Interate over every building in the _location we were looking at
				{
					if (_building === _filterBuldingID) filterSelectionValid = true;
				}, this));
			}, this));
			if (filterSelectionValid === false) matchesBuildingFilter = false;
		}
	}, this));

	return matchesBuildingFilter;
}

LocationBrowserScreen.prototype.selectLocationEntry = function( _rowID )
{
	if (_rowID == this.mSelectedLocation) return;		// Don't select the same location again

	// console.error("selectLocationEntry: " + _rowID);

	if (this.mSelectedLocation != -1) this.mLocationElementPointer[this.mSelectedLocation].removeClass("is-selected");
	this.mSelectedLocation = _rowID;
	if (this.mSelectedLocation == -1) return this.mDetails.display(null);

	this.mLocationElementPointer[this.mSelectedLocation].addClass("is-selected");

	MSU.iterateObject(this.mData.Locations, $.proxy(function (_, _location)
	{
		if (_location.rowID == _rowID)		// triple === doesn't work in all cases because the variable passed from .click is something slightly different
		{
			this.mDetails.display(_location);
			return;
		}
	}, this));

}

LocationBrowserScreen.prototype.focusLocation = function( _locationEntityID )
{
	this.notifyBackendFocusLocation(_locationEntityID);
}

// Should only be called once whenever the window is opened (pressing ctrl + f)
LocationBrowserScreen.prototype.setData = function( _data )
{
	this.mData = _data;
	this.mLocationElementPointer = [];
	this.mFilterContentScrollContainer.empty();

	var rowCount = 0;

	MSU.iterateObject(this.mData.Locations, $.proxy(function ( _key, _location ) {
		var row = $('<div class="location-browser-row location-browser-bottom-gold-line is-clickable"/>');
		this.mFilterContentScrollContainer.append(row);
		this.mLocationElementPointer[rowCount] = row;
		_location.rowID = rowCount;		// New variable entry for 'this.mData'
		row.data("rowID", rowCount);

		var self = this;
		row.click(function ()
		{
			if ($(this).hasClass('is-clickable') === false) return false;

			self.selectLocationEntry( $(this).data("rowID") );
		});

		row.mousedown(function (event)
		{
			if (event.which === 3)	// right click
			{
				return self.focusLocation(_location.id);
			}
		});

		var name = $('<div class="title-font-normal font-color-subtitle location-browser-label is-clickable">' + _location.name + '</div>');
		row.append(name);

		rowCount++;
	}, this));

	this.mFilterInput.get()[0].focus();
};

LocationBrowserScreen.prototype.notifyBackendFocusLocation = function ( _locationEntityID )
{
	console.error("notifyBackendFocusLocation" + _locationEntityID);
    if (this.mSQHandle !== null)
    {
        SQ.call(this.mSQHandle, 'onFocusLocation', _locationEntityID);
    }
};

LocationBrowserScreen.prototype.createImageButton = function (_parentDiv, _imagePath, _callback)
{
	var imageButton = $('<div class="location-browser-footer-button"/>');
	_parentDiv.append(imageButton);

	var image = $('<img/>');
	image.attr('src', Path.GFX + 'ui/' + _imagePath);
	image.addClass("location-browser-footer-button-img");
	imageButton.append(image);
/*
	var image = $('<img/>');
	image.attr('src', Path.GFX + 'ui/icons/buildings/building_x.png');
	image.addClass("location-browser-footer-button-x");
	imageButton.append(image);*/

	imageButton.click(function (_event)
	{
		var disabled = $(this).attr('disabled');
		if (disabled !== null && disabled !== 'disabled')
		{
			_callback($(this));
		}
	});


    imageButton.on("mousedown", function ()
    {
        var disabled = $(this).attr('disabled');
        if (disabled !== null && disabled !== 'disabled')
        {
            $(this).addClass('is-selected');
        }
        else
        {
            $(this).removeClass('is-selected');
        }
    });

    imageButton.on("mouseenter", function ()
    {
        var disabled = $(this).attr('disabled');
        if (disabled !== null && disabled !== 'disabled')
        {
            $(this).addClass('is-selected');
        }
        else
        {
            $(this).removeClass('is-selected');
        }
    });

    imageButton.on("mouseleave", function ()
    {
        $(this).removeClass('is-selected');
    });

    imageButton.on("mouseup", function ()
    {
        $(this).removeClass('is-selected');
    });


	return imageButton;
};

registerScreen("LocationBrowserScreen", new LocationBrowserScreen());

this.engineer_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.engineer";
		this.m.Name = "Leader - The Engineer";
		this.m.Description = "[p=c][img]gfx/ui/events/event_30.png[/img][/p][p]You like to create handgonnes and test them yourself. You just finished a real beauty. It's time to show her to the world and blow up stuff. It should not take you long to find a few targets. It's your dream to create an army of gunners. You are the Engineer.\n\n[color=#bcad8c]Leader:[/color] Start with the Engineer, a named handgonne, and two bodyguards.\n[color=#bcad8c]Avatar:[/color] If the Engineer dies, the campaign ends.[/p]";
		this.m.Difficulty = 2;
		this.m.Order = 300;
	}

	function isValid()
	{
		return this.Const.DLC.Desert;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local names = [];

		for( local i = 0; i < 3; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.m.HireTime = this.Time.getVirtualTimeF();
		}

		local bros = roster.getAll();
		bros[0].setStartValuesEx([
			"nomad_ranged_background"
		]);
		bros[0].getBackground().m.RawDescription = "You had a complicated childhood. You dreamed of fire and metal, now you create it.";
		bros[0].setTitle("The Engineer");
		bros[0].improveMood(1.0, "Happy to test your newly engineered weapon");
		bros[0].getSkills().removeByID("trait.ailing");
		bros[0].getSkills().removeByID("trait.asthmatic");
		bros[0].getSkills().removeByID("trait.athletic");
		bros[0].getSkills().removeByID("trait.bleeder");
		bros[0].getSkills().removeByID("trait.bloodthirsty");
		bros[0].getSkills().removeByID("trait.brave");
		bros[0].getSkills().removeByID("trait.bright");
		bros[0].getSkills().removeByID("trait.brute");
		bros[0].getSkills().removeByID("trait.clubfooted");
		bros[0].getSkills().removeByID("trait.clumsy");
		bros[0].getSkills().removeByID("trait.cocky");
		bros[0].getSkills().removeByID("trait.craven");
		bros[0].getSkills().removeByID("trait.dastard");
		bros[0].getSkills().removeByID("trait.deathwish");
		bros[0].getSkills().removeByID("trait.determined");
		bros[0].getSkills().removeByID("trait.dexterous");
		bros[0].getSkills().removeByID("trait.disloyal");
		bros[0].getSkills().removeByID("trait.drunkard");
		bros[0].getSkills().removeByID("trait.dumb");
		bros[0].getSkills().removeByID("trait.eagle_eyes");
		bros[0].getSkills().removeByID("trait.fainthearted");
		bros[0].getSkills().removeByID("trait.fat");
		bros[0].getSkills().removeByID("trait.fear_beasts");
		bros[0].getSkills().removeByID("trait.fear_greenskins");
		bros[0].getSkills().removeByID("trait.fear_undead");
		bros[0].getSkills().removeByID("trait.fearless");
		bros[0].getSkills().removeByID("trait.fragile");
		bros[0].getSkills().removeByID("trait.gluttonous");
		bros[0].getSkills().removeByID("trait.greedy");
		bros[0].getSkills().removeByID("trait.hate_beasts");
		bros[0].getSkills().removeByID("trait.hate_greenskins");
		bros[0].getSkills().removeByID("trait.hate_undead");
		bros[0].getSkills().removeByID("trait.hesitant");
		bros[0].getSkills().removeByID("trait.huge");
		bros[0].getSkills().removeByID("trait.impatient");
		bros[0].getSkills().removeByID("trait.insecure");
		bros[0].getSkills().removeByID("trait.iron_jaw");
		bros[0].getSkills().removeByID("trait.iron_lungs");
		bros[0].getSkills().removeByID("trait.irrational");
		bros[0].getSkills().removeByID("trait.loyal");
		bros[0].getSkills().removeByID("trait.lucky");
		bros[0].getSkills().removeByID("trait.night_blind");
		bros[0].getSkills().removeByID("trait.night_owl");
		bros[0].getSkills().removeByID("trait.optimist");
		bros[0].getSkills().removeByID("trait.paranoid");
		bros[0].getSkills().removeByID("trait.pessimist");
		bros[0].getSkills().removeByID("trait.quick");
		bros[0].getSkills().removeByID("trait.short_sighted");
		bros[0].getSkills().removeByID("trait.spartan");
		bros[0].getSkills().removeByID("trait.strong");
		bros[0].getSkills().removeByID("trait.superstitious");
		bros[0].getSkills().removeByID("trait.sure_footing");
		bros[0].getSkills().removeByID("trait.survivor");
		bros[0].getSkills().removeByID("trait.swift");
		bros[0].getSkills().removeByID("trait.teamplayer");
		bros[0].getSkills().removeByID("trait.tiny");
		bros[0].getSkills().removeByID("trait.tough");
		bros[0].getSkills().removeByID("trait.weasel");
		bros[0].getSkills().add(this.new("scripts/skills/traits/player_character_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/bright_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/eagle_eyes_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/determined_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_crippling_strikes"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_mastery_crossbow"));
		bros[0].setPlaceInFormation(4);
	  bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].m.PerkPoints = 3;
		bros[0].m.LevelUps = 3;
		bros[0].m.Level = 4;
		bros[0].getBaseProperties().MeleeDefense -= 2;
		bros[0].m.Talents = [];
		local talents = bros[0].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 2;
		talents[this.Const.Attributes.MeleeSkill] = 0;
		talents[this.Const.Attributes.MeleeDefense] = 0;
		talents[this.Const.Attributes.RangedSkill] = 3;
		talents[this.Const.Attributes.RangedDefense] = 2;
		bros[0].m.Attributes = [];
		bros[0].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[0].m.BaseProperties.Bravery = 50;
		local items = bros[0].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		local handgonne = this.new("scripts/items/weapons/named/named_handgonne");
		handgonne.m.Name = "Beauty\'s fury";
		items.equip(handgonne);
		items.equip(this.new("scripts/items/helmets/oriental/engineer_hat"));
		items.equip(this.new("scripts/items/armor/oriental/padded_vest"));
		items.equip(this.new("scripts/items/ammo/powder_bag"));
		bros[1].setStartValuesEx([
			"nomad_background"
		]);
		bros[1].getBackground().m.RawDescription = "Just a desert warrior. Accompanies and protects his boss.";
		bros[1].setPlaceInFormation(3);
		bros[1].getSkills().removeByID("trait.loyal");
		bros[1].getSkills().removeByID("trait.disloyal");
		bros[1].getSkills().removeByID("trait.drunkard");
		bros[1].getSkills().removeByID("trait.clubfooted");
		bros[1].getSkills().removeByID("trait.clumsy");
		bros[1].getSkills().removeByID("trait.insecure");
		bros[1].getSkills().removeByID("trait.paranoid");
		bros[1].getSkills().removeByID("trait.weasel");
		bros[1].getSkills().removeByID("trait.craven");
		bros[1].getSkills().removeByID("trait.dastard");
		bros[1].getSkills().add(this.new("scripts/skills/traits/loyal_trait"));
		bros[1].m.PerkPoints = 2;
		bros[1].m.LevelUps = 2;
		bros[1].m.Level = 3;
		local items = bros[1].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/helmets/oriental/spiked_skull_cap_with_mail"));
		items.equip(this.new("scripts/items/armor/oriental/southern_mail_shirt"));
		items.equip(this.new("scripts/items/weapons/oriental/firelance"));
		items.equip(this.new("scripts/items/shields/oriental/southern_light_shield"));
		bros[2].setStartValuesEx([
			"nomad_background"
		]);
		bros[2].getBackground().m.RawDescription = "Just a desert warrior. Accompanies and protects his boss.";
		bros[2].setPlaceInFormation(5);
		bros[2].getSkills().removeByID("trait.loyal");
		bros[2].getSkills().removeByID("trait.disloyal");
		bros[2].getSkills().removeByID("trait.drunkard");
		bros[2].getSkills().removeByID("trait.clubfooted");
		bros[2].getSkills().removeByID("trait.clumsy");
		bros[2].getSkills().removeByID("trait.insecure");
		bros[2].getSkills().removeByID("trait.paranoid");
		bros[2].getSkills().removeByID("trait.weasel");
		bros[2].getSkills().removeByID("trait.craven");
		bros[2].getSkills().removeByID("trait.dastard");
		bros[2].getSkills().add(this.new("scripts/skills/traits/loyal_trait"));
		bros[2].m.PerkPoints = 2;
		bros[2].m.LevelUps = 2;
		bros[2].m.Level = 3;
		local items = bros[2].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/helmets/oriental/spiked_skull_cap_with_mail"));
		items.equip(this.new("scripts/items/armor/oriental/southern_mail_shirt"));
		items.equip(this.new("scripts/items/weapons/oriental/firelance"));
		items.equip(this.new("scripts/items/shields/oriental/southern_light_shield"));
		this.World.Assets.m.BusinessReputation = 100;
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/rice_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/dates_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/dried_lamb_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/sulfurous_rocks_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/sulfurous_rocks_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/fire_bomb_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/fire_bomb_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/ammo/powder_bag"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/oriental/light_southern_mace"));

	}

	function onSpawnPlayer()
	{
		local randomVillage;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
		{
			randomVillage = this.World.EntityManager.getSettlements()[i];

			if (!randomVillage.isIsolatedFromRoads() && randomVillage.isSouthern() && randomVillage.hasBuilding("building.arena"))
			{
				break;
			}
		}

		local randomVillageTile = randomVillage.getTile();

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 1), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 1));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 1), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 1));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) == 0)
				{
				}
				else if (!tile.HasRoad)
				{
				}
				else
				{
					randomVillageTile = tile;
					break;
				}
			}
		}
		while (1);

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(14);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/worldmap_11.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.engineer_scenario_intro");
		}, null);
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

});

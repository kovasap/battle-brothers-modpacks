this.stalker_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.stalker";
		this.m.Name = "Leader - The Stalker";
		this.m.Description = "[p=c][img]gfx/ui/events/event_76.png[/img][/p][p]You know your way around the forest. Snaring rabbits and shooting deer at first, now you hunt more dangerous prey. Keeping the forest villages safe made you a local legend. Ironic for someone who prefers to stay in the shadows, moving unseen. You are the Stalker.\n\n[color=#bcad8c]Leader:[/color] Start with the Stalker, a named bow and armor, five brothers and low funds.\n[color=#bcad8c]Leader serves as Lookout:[/color] Increased sight radius by 25%. Extended information about footprints.\n[color=#bcad8c]Avatar:[/color] If the Stalker dies, the campaign ends.[/p]";
		this.m.Difficulty = 2;
		this.m.Order = 320;
	}

	function isValid()
	{
		return this.Const.DLC.Wildmen;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local names = [];

		for( local i = 0; i < 6; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.improveMood(1.0, "Spent time hunting");
			bro.m.HireTime = this.Time.getVirtualTimeF();
		}

		local bros = roster.getAll();
		bros[0].setStartValuesEx([
			"hunter_background"
		]);
		bros[0].getBackground().m.RawDescription = "Child of the forest became a fierce warrior. Hunter of men and beast and worse. Dislikes people who talk to much.";
		bros[0].setTitle("The Stalker");
		bros[0].setPlaceInFormation(13);
		bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].getSkills().removeByID("trait.ailing");
		bros[0].getSkills().removeByID("trait.asthmatic");
		bros[0].getSkills().removeByID("trait.athletic");
		bros[0].getSkills().removeByID("trait.bleeder");
		bros[0].getSkills().removeByID("trait.bloodthirsty");
		bros[0].getSkills().removeByID("trait.brave");
		bros[0].getSkills().removeByID("trait.bright");
		bros[0].getSkills().removeByID("trait.brute");
		bros[0].getSkills().removeByID("trait.clubfooted");
		bros[0].getSkills().removeByID("trait.clumsy");
		bros[0].getSkills().removeByID("trait.cocky");
		bros[0].getSkills().removeByID("trait.craven");
		bros[0].getSkills().removeByID("trait.dastard");
		bros[0].getSkills().removeByID("trait.deathwish");
		bros[0].getSkills().removeByID("trait.determined");
		bros[0].getSkills().removeByID("trait.dexterous");
		bros[0].getSkills().removeByID("trait.disloyal");
		bros[0].getSkills().removeByID("trait.drunkard");
		bros[0].getSkills().removeByID("trait.dumb");
		bros[0].getSkills().removeByID("trait.eagle_eyes");
		bros[0].getSkills().removeByID("trait.fainthearted");
		bros[0].getSkills().removeByID("trait.fat");
		bros[0].getSkills().removeByID("trait.fear_beasts");
		bros[0].getSkills().removeByID("trait.fear_greenskins");
		bros[0].getSkills().removeByID("trait.fear_undead");
		bros[0].getSkills().removeByID("trait.fearless");
		bros[0].getSkills().removeByID("trait.fragile");
		bros[0].getSkills().removeByID("trait.gluttonous");
		bros[0].getSkills().removeByID("trait.greedy");
		bros[0].getSkills().removeByID("trait.hate_beasts");
		bros[0].getSkills().removeByID("trait.hate_greenskins");
		bros[0].getSkills().removeByID("trait.hate_undead");
		bros[0].getSkills().removeByID("trait.hesitant");
		bros[0].getSkills().removeByID("trait.huge");
		bros[0].getSkills().removeByID("trait.impatient");
		bros[0].getSkills().removeByID("trait.insecure");
		bros[0].getSkills().removeByID("trait.iron_jaw");
		bros[0].getSkills().removeByID("trait.iron_lungs");
		bros[0].getSkills().removeByID("trait.irrational");
		bros[0].getSkills().removeByID("trait.loyal");
		bros[0].getSkills().removeByID("trait.lucky");
		bros[0].getSkills().removeByID("trait.night_blind");
		bros[0].getSkills().removeByID("trait.night_owl");
		bros[0].getSkills().removeByID("trait.optimist");
		bros[0].getSkills().removeByID("trait.paranoid");
		bros[0].getSkills().removeByID("trait.pessimist");
		bros[0].getSkills().removeByID("trait.quick");
		bros[0].getSkills().removeByID("trait.short_sighted");
		bros[0].getSkills().removeByID("trait.spartan");
		bros[0].getSkills().removeByID("trait.strong");
		bros[0].getSkills().removeByID("trait.superstitious");
		bros[0].getSkills().removeByID("trait.sure_footing");
		bros[0].getSkills().removeByID("trait.survivor");
		bros[0].getSkills().removeByID("trait.swift");
		bros[0].getSkills().removeByID("trait.teamplayer");
		bros[0].getSkills().removeByID("trait.tiny");
		bros[0].getSkills().removeByID("trait.tough");
		bros[0].getSkills().removeByID("trait.weasel");
		bros[0].getSkills().add(this.new("scripts/skills/traits/player_character_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/quick_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/eagle_eyes_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/determined_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_pathfinder"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_mastery_bow"));
		bros[0].m.PerkPoints = 3;
		bros[0].m.LevelUps = 3;
		bros[0].m.Level = 4;
		bros[0].getBaseProperties().MeleeDefense -= 2;
		bros[0].m.Talents = [];
		local talents = bros[0].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 2;
		talents[this.Const.Attributes.MeleeSkill] = 0;
		talents[this.Const.Attributes.MeleeDefense] = 0;
		talents[this.Const.Attributes.RangedSkill] = 3;
		talents[this.Const.Attributes.RangedDefense] = 2;
		bros[0].m.Attributes = [];
		bros[0].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[0].m.BaseProperties.Hitpoints = 60;
		bros[0].m.BaseProperties.Stamina = 110;
		bros[0].m.BaseProperties.RangedSkill = 60;
		bros[0].m.BaseProperties.Bravery = 50;
		bros[0].m.BaseProperties.RangedDefense = 10;
		bros[0].m.BaseProperties.MeleeDefense = 10;
		bros[0].m.BaseProperties.Initiative = 120;
		local items = bros[0].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/helmets/hood"));
		local warbow = this.new("scripts/items/weapons/named/named_warbow");
		warbow.m.Name = "The Silencer";
		items.equip(warbow);
		items.equip(this.new("scripts/items/ammo/large_quiver_of_arrows"));
		local stalkerarmor = this.new("scripts/items/armor/named/black_leather_armor");
		stalkerarmor.m.Name = "Stalker's leather armor";
		items.equip(stalkerarmor);
		bros[1].setStartValuesEx([
			"lumberjack_background"
		]);
		bros[1].getBackground().m.RawDescription = "{%name%}";
		bros[1].setPlaceInFormation(3);
		bros[1].getSkills().removeByID("trait.ailing");
		bros[1].getSkills().removeByID("trait.asthmatic");
		bros[1].getSkills().removeByID("trait.clubfooted");
		bros[1].getSkills().removeByID("trait.clumsy");
		bros[1].getSkills().removeByID("trait.craven");
		bros[1].getSkills().removeByID("trait.dastard");
		bros[1].getSkills().removeByID("trait.disloyal");
		bros[1].getSkills().removeByID("trait.drunkard");
		bros[1].getSkills().removeByID("trait.fainthearted");
		bros[1].getSkills().removeByID("trait.fear_beasts");
		bros[1].getSkills().removeByID("trait.insecure");
		bros[1].getSkills().removeByID("trait.short_sighted");
		local items = bros[1].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.equip(this.new("scripts/items/armor/padded_surcoat"));
		items.equip(this.new("scripts/items/helmets/hood"));
		items.equip(this.new("scripts/items/weapons/hand_axe"));
		items.equip(this.new("scripts/items/shields/buckler_shield"));
		bros[2].setStartValuesEx([
			"beast_hunter_background"
		]);
		bros[2].getBackground().m.RawDescription = "{}";
		bros[2].setPlaceInFormation(4);
		bros[2].getSkills().removeByID("trait.ailing");
		bros[2].getSkills().removeByID("trait.asthmatic");
		bros[2].getSkills().removeByID("trait.clubfooted");
		bros[2].getSkills().removeByID("trait.clumsy");
		bros[2].getSkills().removeByID("trait.craven");
		bros[2].getSkills().removeByID("trait.dastard");
		bros[2].getSkills().removeByID("trait.disloyal");
		bros[2].getSkills().removeByID("trait.drunkard");
		bros[2].getSkills().removeByID("trait.fainthearted");
		bros[2].getSkills().removeByID("trait.fear_beasts");
		bros[2].getSkills().removeByID("trait.insecure");
		bros[2].getSkills().removeByID("trait.short_sighted");
		local items = bros[2].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/armor/ragged_surcoat"));
		items.equip(this.new("scripts/items/helmets/hood"));
		items.equip(this.new("scripts/items/weapons/spetum"));
		bros[3].setStartValuesEx([
			"lumberjack_background"
		]);
		bros[3].getBackground().m.RawDescription = "{%name%}";
		bros[3].setPlaceInFormation(5);
		bros[3].getSkills().removeByID("trait.ailing");
		bros[3].getSkills().removeByID("trait.asthmatic");
		bros[3].getSkills().removeByID("trait.clubfooted");
		bros[3].getSkills().removeByID("trait.clumsy");
		bros[3].getSkills().removeByID("trait.craven");
		bros[3].getSkills().removeByID("trait.dastard");
		bros[3].getSkills().removeByID("trait.disloyal");
		bros[3].getSkills().removeByID("trait.drunkard");
		bros[3].getSkills().removeByID("trait.fainthearted");
		bros[3].getSkills().removeByID("trait.fear_beasts");
		bros[3].getSkills().removeByID("trait.insecure");
		bros[3].getSkills().removeByID("trait.short_sighted");
		local items = bros[3].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.equip(this.new("scripts/items/armor/ragged_surcoat"));
		items.equip(this.new("scripts/items/helmets/hood"));
		items.equip(this.new("scripts/items/weapons/woodcutters_axe"));
		bros[4].setStartValuesEx([
			"poacher_background"
		]);
		bros[4].getBackground().m.RawDescription = "{%name% fell into poaching after a drought ravaged his farmstead. Like most poachers, he is not truly of the criminal mind. Long grouped together in the hunting gangs, %name% was quick to nominate you as captain of the new sellsword outfit.}";
		bros[4].setPlaceInFormation(12);
		bros[4].getSkills().removeByID("trait.ailing");
		bros[4].getSkills().removeByID("trait.asthmatic");
		bros[4].getSkills().removeByID("trait.bloodthirsty");
		bros[4].getSkills().removeByID("trait.brute");
		bros[4].getSkills().removeByID("trait.clubfooted");
		bros[4].getSkills().removeByID("trait.clumsy");
		bros[4].getSkills().removeByID("trait.craven");
		bros[4].getSkills().removeByID("trait.dastard");
		bros[4].getSkills().removeByID("trait.disloyal");
		bros[4].getSkills().removeByID("trait.drunkard");
		bros[4].getSkills().removeByID("trait.fainthearted");
		bros[4].getSkills().removeByID("trait.fear_beasts");
		bros[4].getSkills().removeByID("trait.insecure");
		bros[4].getSkills().removeByID("trait.short_sighted");
		local items = bros[4].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/armor/ragged_surcoat"));
		items.equip(this.new("scripts/items/helmets/hood"));
		items.equip(this.new("scripts/items/weapons/short_bow"));
		items.equip(this.new("scripts/items/ammo/quiver_of_arrows"));
		bros[5].setStartValuesEx([
			"hunter_background"
		]);
		bros[5].getBackground().m.RawDescription = "{A bit of a devious runt, though a good man at heart. %name% used to hunt for his local liege, but when the nobleman died falling into an unseen ravine the hunter was blamed and kicked out of court. With some guile, he turned his hunting talents into poaching and fur trade. He is of a merchant\'s mind and was quick to engender the idea of mercenary work because of it.}";
		bros[5].setPlaceInFormation(14);
		bros[5].getSkills().removeByID("trait.ailing");
		bros[5].getSkills().removeByID("trait.asthmatic");
		bros[5].getSkills().removeByID("trait.bloodthirsty");
		bros[5].getSkills().removeByID("trait.brute");
		bros[5].getSkills().removeByID("trait.clubfooted");
		bros[5].getSkills().removeByID("trait.clumsy");
		bros[5].getSkills().removeByID("trait.craven");
		bros[5].getSkills().removeByID("trait.dastard");
		bros[5].getSkills().removeByID("trait.disloyal");
		bros[5].getSkills().removeByID("trait.drunkard");
		bros[5].getSkills().removeByID("trait.fainthearted");
		bros[5].getSkills().removeByID("trait.fear_beasts");
		bros[5].getSkills().removeByID("trait.insecure");
		bros[5].getSkills().removeByID("trait.short_sighted");
		bros[5].m.Skills.add(this.new("scripts/skills/perks/perk_student"));
		local items = bros[5].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.equip(this.new("scripts/items/armor/thick_tunic"));
		items.equip(this.new("scripts/items/helmets/hood"));
		items.equip(this.new("scripts/items/weapons/hunting_bow"));
		this.World.Assets.m.BusinessReputation = 100;
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/cured_venison_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/roots_and_berries_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/trade/furs_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/trade/furs_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/werewolf_pelt_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/ammo/quiver_of_arrows"));
		this.World.Assets.getStash().add(this.new("scripts/items/ammo/quiver_of_arrows"));
		this.World.Assets.getStash().add(this.new("scripts/items/ammo/quiver_of_arrows"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/knife"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/hatchet"));
		this.World.Assets.m.Money = this.World.Assets.m.Money / 2;
		this.World.Assets.m.ArmorParts = this.World.Assets.m.ArmorParts / 2;
		this.World.Assets.m.Ammo = this.World.Assets.m.Ammo * 2;
	}

	function onSpawnPlayer()
	{
		local spawnTile;
		local settlements = this.World.EntityManager.getSettlements();
		local nearestVillage;
		local navSettings = this.World.getNavigator().createSettings();
		navSettings.ActionPointCosts = this.Const.World.TerrainTypeNavCost_Flat;

		do
		{
			local x = this.Math.rand(5, this.Const.World.Settings.SizeX - 5);
			local y = this.Math.rand(5, this.Const.World.Settings.SizeY - 5);

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.IsOccupied)
				{
				}
				else if (tile.Type != this.Const.World.TerrainType.Forest && tile.Type != this.Const.World.TerrainType.SnowyForest && tile.Type != this.Const.World.TerrainType.LeaveForest && tile.Type != this.Const.World.TerrainType.AutumnForest)
				{
				}
				else
				{
					local next = true;

					foreach( s in settlements )
					{
						local d = s.getTile().getDistanceTo(tile);

						if (d > 6 && d < 15)
						{
							local path = this.World.getNavigator().findPath(tile, s.getTile(), navSettings, 0);

							if (!path.isEmpty())
							{
								next = false;
								nearestVillage = s;
								break;
							}
						}
					}

					if (next)
					{
					}
					else
					{
						spawnTile = tile;
						break;
					}
				}
			}
		}
		while (1);

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", spawnTile.Coords.X, spawnTile.Coords.Y);
		this.World.Assets.updateLook(10);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
		this.Music.setTrackList([
			"music/worldmap_07.ogg"
		], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.stalker_scenario_intro");
		}, null);
	}

	function onInit()
	{
		this.World.Assets.m.VisionRadiusMult = 1.25;
		this.World.Assets.m.IsShowingExtendedFootprints = true;
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}



});

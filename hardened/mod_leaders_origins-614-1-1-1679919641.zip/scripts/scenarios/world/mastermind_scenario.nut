this.mastermind_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.mastermind";
		this.m.Name = "Leader - The Mastermind";
		this.m.Description = "[p=c][img]gfx/ui/events/event_62.png[/img][/p][p]You do whatever it takes to get what you want, with great success. You guide, confuse and eliminate, leaving the killing to others. Getting bored directing everything from the shadows, you decide to show yourself to the world. You like it when the stakes are high and crave a real challenge. You are the Mastermind.\n\n[color=#bcad8c]Leader:[/color] Start with the Mastermind and two powerful \'puppets\'.\n[color=#bcad8c]Only The Best:[/color] Can only hire combat backgrounds.\n[color=#bcad8c]A Real Challenge:[/color] Max. 11 men in your roster.\n[color=#bcad8c]Avatar:[/color] If the Mastermind dies, the campaign ends.[/p]";
		this.m.Difficulty = 3;
		this.m.Order = 310;
	}

	function isValid()
	{
		return this.Const.DLC.Desert;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local names = [];

		for( local i = 0; i < 3; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.m.HireTime = this.Time.getVirtualTimeF();
			bro.improveMood(1.0, "Up to no good, but in a good way");
		}

		local bros = roster.getAll();
		bros[0].setStartValuesEx([
			"gambler_background"
		]);
		bros[0].setName("Luminos");
		bros[0].setTitle("The Mastermind");
		bros[0].getBackground().m.RawDescription = "Your history consists of a vast web of manipulation, malice and murder. Your dad clearly did not love you.";
		bros[0].setPlaceInFormation(4);
		bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].getSkills().removeByID("trait.ailing");
		bros[0].getSkills().removeByID("trait.asthmatic");
		bros[0].getSkills().removeByID("trait.athletic");
		bros[0].getSkills().removeByID("trait.bleeder");
		bros[0].getSkills().removeByID("trait.bloodthirsty");
		bros[0].getSkills().removeByID("trait.brave");
		bros[0].getSkills().removeByID("trait.bright");
		bros[0].getSkills().removeByID("trait.brute");
		bros[0].getSkills().removeByID("trait.clubfooted");
		bros[0].getSkills().removeByID("trait.clumsy");
		bros[0].getSkills().removeByID("trait.cocky");
		bros[0].getSkills().removeByID("trait.craven");
		bros[0].getSkills().removeByID("trait.dastard");
		bros[0].getSkills().removeByID("trait.deathwish");
		bros[0].getSkills().removeByID("trait.determined");
		bros[0].getSkills().removeByID("trait.dexterous");
		bros[0].getSkills().removeByID("trait.disloyal");
		bros[0].getSkills().removeByID("trait.drunkard");
		bros[0].getSkills().removeByID("trait.dumb");
		bros[0].getSkills().removeByID("trait.eagle_eyes");
		bros[0].getSkills().removeByID("trait.fainthearted");
		bros[0].getSkills().removeByID("trait.fat");
		bros[0].getSkills().removeByID("trait.fear_beasts");
		bros[0].getSkills().removeByID("trait.fear_greenskins");
		bros[0].getSkills().removeByID("trait.fear_undead");
		bros[0].getSkills().removeByID("trait.fearless");
		bros[0].getSkills().removeByID("trait.fragile");
		bros[0].getSkills().removeByID("trait.gluttonous");
		bros[0].getSkills().removeByID("trait.greedy");
		bros[0].getSkills().removeByID("trait.hate_beasts");
		bros[0].getSkills().removeByID("trait.hate_greenskins");
		bros[0].getSkills().removeByID("trait.hate_undead");
		bros[0].getSkills().removeByID("trait.hesitant");
		bros[0].getSkills().removeByID("trait.huge");
		bros[0].getSkills().removeByID("trait.impatient");
		bros[0].getSkills().removeByID("trait.insecure");
		bros[0].getSkills().removeByID("trait.iron_jaw");
		bros[0].getSkills().removeByID("trait.iron_lungs");
		bros[0].getSkills().removeByID("trait.irrational");
		bros[0].getSkills().removeByID("trait.loyal");
		bros[0].getSkills().removeByID("trait.lucky");
		bros[0].getSkills().removeByID("trait.night_blind");
		bros[0].getSkills().removeByID("trait.night_owl");
		bros[0].getSkills().removeByID("trait.optimist");
		bros[0].getSkills().removeByID("trait.paranoid");
		bros[0].getSkills().removeByID("trait.pessimist");
		bros[0].getSkills().removeByID("trait.quick");
		bros[0].getSkills().removeByID("trait.short_sighted");
		bros[0].getSkills().removeByID("trait.spartan");
		bros[0].getSkills().removeByID("trait.strong");
		bros[0].getSkills().removeByID("trait.superstitious");
		bros[0].getSkills().removeByID("trait.sure_footing");
		bros[0].getSkills().removeByID("trait.survivor");
		bros[0].getSkills().removeByID("trait.swift");
		bros[0].getSkills().removeByID("trait.teamplayer");
		bros[0].getSkills().removeByID("trait.tiny");
		bros[0].getSkills().removeByID("trait.tough");
		bros[0].getSkills().removeByID("trait.weasel");
		bros[0].getSkills().add(this.new("scripts/skills/traits/player_character_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/bright_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/lucky_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/weasel_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_quick_hands"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_bags_and_belts"));
		bros[0].m.PerkPoints = 3;
		bros[0].m.LevelUps = 3;
		bros[0].m.Level = 4;
		bros[0].getBaseProperties().MeleeDefense -= 2;
		bros[0].m.Talents = [];
		local talents = bros[0].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 3;
		talents[this.Const.Attributes.MeleeSkill] = 0;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 2;
		bros[0].m.Attributes = [];
		bros[0].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[0].m.BaseProperties.Hitpoints = 60;
		bros[0].m.BaseProperties.Stamina = 105;
		bros[0].m.BaseProperties.Bravery = 56;
		bros[0].m.BaseProperties.MeleeSkill = 60;
		bros[0].m.BaseProperties.MeleeDefense = 6;
		bros[0].m.BaseProperties.RangedSkill = 6;
		bros[0].m.BaseProperties.RangedDefense = 6;
		local items = bros[0].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/helmets/feathered_hat"));
		items.equip(this.new("scripts/items/armor/noble_tunic"));
		items.equip(this.new("scripts/items/tools/smoke_bomb_item"));
		items.equip(this.new("scripts/items/accessory/falcon_item"));
		bros[1].setStartValuesEx([
			"hedge_knight_background"
		]);
		bros[1].setTitle("The Left Hand");
		bros[1].getBackground().m.RawDescription = "A long history of eating, drinking, sleeping and terrorizing.";
		bros[1].setPlaceInFormation(3);
		bros[1].getSkills().removeByID("trait.ailing");
		bros[1].getSkills().removeByID("trait.asthmatic");
		bros[1].getSkills().removeByID("trait.athletic");
		bros[1].getSkills().removeByID("trait.bleeder");
		bros[1].getSkills().removeByID("trait.bloodthirsty");
		bros[1].getSkills().removeByID("trait.brave");
		bros[1].getSkills().removeByID("trait.bright");
		bros[1].getSkills().removeByID("trait.brute");
		bros[1].getSkills().removeByID("trait.clubfooted");
		bros[1].getSkills().removeByID("trait.clumsy");
		bros[1].getSkills().removeByID("trait.cocky");
		bros[1].getSkills().removeByID("trait.craven");
		bros[1].getSkills().removeByID("trait.dastard");
		bros[1].getSkills().removeByID("trait.deathwish");
		bros[1].getSkills().removeByID("trait.determined");
		bros[1].getSkills().removeByID("trait.dexterous");
		bros[1].getSkills().removeByID("trait.disloyal");
		bros[1].getSkills().removeByID("trait.drunkard");
		bros[1].getSkills().removeByID("trait.dumb");
		bros[1].getSkills().removeByID("trait.eagle_eyes");
		bros[1].getSkills().removeByID("trait.fainthearted");
		bros[1].getSkills().removeByID("trait.fat");
		bros[1].getSkills().removeByID("trait.fear_beasts");
		bros[1].getSkills().removeByID("trait.fear_greenskins");
		bros[1].getSkills().removeByID("trait.fear_undead");
		bros[1].getSkills().removeByID("trait.fearless");
		bros[1].getSkills().removeByID("trait.fragile");
		bros[1].getSkills().removeByID("trait.gluttonous");
		bros[1].getSkills().removeByID("trait.greedy");
		bros[1].getSkills().removeByID("trait.hate_beasts");
		bros[1].getSkills().removeByID("trait.hate_greenskins");
		bros[1].getSkills().removeByID("trait.hate_undead");
		bros[1].getSkills().removeByID("trait.hesitant");
		bros[1].getSkills().removeByID("trait.huge");
		bros[1].getSkills().removeByID("trait.impatient");
		bros[1].getSkills().removeByID("trait.insecure");
		bros[1].getSkills().removeByID("trait.iron_jaw");
		bros[1].getSkills().removeByID("trait.iron_lungs");
		bros[1].getSkills().removeByID("trait.irrational");
		bros[1].getSkills().removeByID("trait.loyal");
		bros[1].getSkills().removeByID("trait.lucky");
		bros[1].getSkills().removeByID("trait.night_blind");
		bros[1].getSkills().removeByID("trait.night_owl");
		bros[1].getSkills().removeByID("trait.optimist");
		bros[1].getSkills().removeByID("trait.paranoid");
		bros[1].getSkills().removeByID("trait.pessimist");
		bros[1].getSkills().removeByID("trait.quick");
		bros[1].getSkills().removeByID("trait.short_sighted");
		bros[1].getSkills().removeByID("trait.spartan");
		bros[1].getSkills().removeByID("trait.strong");
		bros[1].getSkills().removeByID("trait.superstitious");
		bros[1].getSkills().removeByID("trait.sure_footing");
		bros[1].getSkills().removeByID("trait.survivor");
		bros[1].getSkills().removeByID("trait.swift");
		bros[1].getSkills().removeByID("trait.teamplayer");
		bros[1].getSkills().removeByID("trait.tiny");
		bros[1].getSkills().removeByID("trait.tough");
		bros[1].getSkills().removeByID("trait.weasel");
		bros[1].getSkills().add(this.new("scripts/skills/traits/dumb_trait"));
		bros[1].getSkills().add(this.new("scripts/skills/traits/huge_trait"));
		bros[1].getSkills().add(this.new("scripts/skills/traits/loyal_trait"));
		bros[1].getSkills().add(this.new("scripts/skills/traits/iron_jaw_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/perks/perk_rotation"));
		bros[1].m.PerkPoints = 3;
		bros[1].m.LevelUps = 3;
		bros[1].m.Level = 4;
		bros[1].getBaseProperties().MeleeDefense -= 2;
		bros[1].m.Talents = [];
		local talents = bros[1].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 2;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 0;
		talents[this.Const.Attributes.Initiative] = 0;
		talents[this.Const.Attributes.MeleeSkill] = 3;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		bros[1].m.Attributes = [];
		bros[1].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[1].m.BaseProperties.MeleeDefense = 13;
		local items = bros[1].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/armor/decayed_reinforced_mail_hauberk"));
		items.equip(this.new("scripts/items/helmets/decayed_closed_flat_top_with_sack"));
		items.equip(this.new("scripts/items/weapons/two_handed_flanged_mace"));
		bros[2].setStartValuesEx([
			"hedge_knight_background"
		]);
		bros[2].setTitle("The Right Hand");
		bros[2].getBackground().m.RawDescription = "A long history of eating, drinking, sleeping and terrorizing.";
		bros[2].setPlaceInFormation(5);
		bros[2].getSkills().removeByID("trait.ailing");
		bros[2].getSkills().removeByID("trait.asthmatic");
		bros[2].getSkills().removeByID("trait.athletic");
		bros[2].getSkills().removeByID("trait.bleeder");
		bros[2].getSkills().removeByID("trait.bloodthirsty");
		bros[2].getSkills().removeByID("trait.brave");
		bros[2].getSkills().removeByID("trait.bright");
		bros[2].getSkills().removeByID("trait.brute");
		bros[2].getSkills().removeByID("trait.clubfooted");
		bros[2].getSkills().removeByID("trait.clumsy");
		bros[2].getSkills().removeByID("trait.cocky");
		bros[2].getSkills().removeByID("trait.craven");
		bros[2].getSkills().removeByID("trait.dastard");
		bros[2].getSkills().removeByID("trait.deathwish");
		bros[2].getSkills().removeByID("trait.determined");
		bros[2].getSkills().removeByID("trait.dexterous");
		bros[2].getSkills().removeByID("trait.disloyal");
		bros[2].getSkills().removeByID("trait.drunkard");
		bros[2].getSkills().removeByID("trait.dumb");
		bros[2].getSkills().removeByID("trait.eagle_eyes");
		bros[2].getSkills().removeByID("trait.fainthearted");
		bros[2].getSkills().removeByID("trait.fat");
		bros[2].getSkills().removeByID("trait.fear_beasts");
		bros[2].getSkills().removeByID("trait.fear_greenskins");
		bros[2].getSkills().removeByID("trait.fear_undead");
		bros[2].getSkills().removeByID("trait.fearless");
		bros[2].getSkills().removeByID("trait.fragile");
		bros[2].getSkills().removeByID("trait.gluttonous");
		bros[2].getSkills().removeByID("trait.greedy");
		bros[2].getSkills().removeByID("trait.hate_beasts");
		bros[2].getSkills().removeByID("trait.hate_greenskins");
		bros[2].getSkills().removeByID("trait.hate_undead");
		bros[2].getSkills().removeByID("trait.hesitant");
		bros[2].getSkills().removeByID("trait.huge");
		bros[2].getSkills().removeByID("trait.impatient");
		bros[2].getSkills().removeByID("trait.insecure");
		bros[2].getSkills().removeByID("trait.iron_jaw");
		bros[2].getSkills().removeByID("trait.iron_lungs");
		bros[2].getSkills().removeByID("trait.irrational");
		bros[2].getSkills().removeByID("trait.loyal");
		bros[2].getSkills().removeByID("trait.lucky");
		bros[2].getSkills().removeByID("trait.night_blind");
		bros[2].getSkills().removeByID("trait.night_owl");
		bros[2].getSkills().removeByID("trait.optimist");
		bros[2].getSkills().removeByID("trait.paranoid");
		bros[2].getSkills().removeByID("trait.pessimist");
		bros[2].getSkills().removeByID("trait.quick");
		bros[2].getSkills().removeByID("trait.short_sighted");
		bros[2].getSkills().removeByID("trait.spartan");
		bros[2].getSkills().removeByID("trait.strong");
		bros[2].getSkills().removeByID("trait.superstitious");
		bros[2].getSkills().removeByID("trait.sure_footing");
		bros[2].getSkills().removeByID("trait.survivor");
		bros[2].getSkills().removeByID("trait.swift");
		bros[2].getSkills().removeByID("trait.teamplayer");
		bros[2].getSkills().removeByID("trait.tiny");
		bros[2].getSkills().removeByID("trait.tough");
		bros[2].getSkills().removeByID("trait.weasel");
		bros[2].getSkills().add(this.new("scripts/skills/traits/dumb_trait"));
		bros[2].getSkills().add(this.new("scripts/skills/traits/huge_trait"));
		bros[2].getSkills().add(this.new("scripts/skills/traits/loyal_trait"));
		bros[2].getSkills().add(this.new("scripts/skills/traits/iron_jaw_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/perks/perk_rotation"));
		bros[2].m.PerkPoints = 3;
		bros[2].m.LevelUps = 3;
		bros[2].m.Level = 4;
		bros[2].m.Talents = [];
		local talents = bros[2].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 1;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 0;
		talents[this.Const.Attributes.Initiative] = 0;
		talents[this.Const.Attributes.MeleeSkill] = 2;
		talents[this.Const.Attributes.MeleeDefense] = 3;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		bros[2].m.Attributes = [];
		bros[2].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[2].m.BaseProperties.MeleeDefense = 13;
		local items = bros[2].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/armor/decayed_reinforced_mail_hauberk"));
		items.equip(this.new("scripts/items/helmets/decayed_closed_flat_top_with_sack"));
		items.equip(this.new("scripts/items/weapons/two_handed_flail"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/wine_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/smoked_ham_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/dried_lamb_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/snake_oil_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/snake_oil_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/snake_oil_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/throwing_net"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/throwing_net"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/throwing_net"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/daze_bomb_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/poison_item"));
    this.World.Assets.getStash().add(this.new("scripts/items/helmets/dark_cowl"));
		this.World.Assets.getStash().add(this.new("scripts/items/armor/thick_dark_tunic"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/dagger"));

	}

	function onSpawnPlayer()
	{
		local randomVillage;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
		{
			randomVillage = this.World.EntityManager.getSettlements()[i];

			if (!randomVillage.isMilitary() && !randomVillage.isIsolatedFromRoads() && randomVillage.getSize() >= 3)
			{
				break;
			}
		}

		local randomVillageTile = randomVillage.getTile();
		local navSettings = this.World.getNavigator().createSettings();
		navSettings.ActionPointCosts = this.Const.World.TerrainTypeNavCost_Flat;

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 8), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 8));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 8), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 8));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.IsOccupied)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) <= 5)
				{
				}
				else if (!tile.HasRoad)
				{
				}
				else
				{
					local path = this.World.getNavigator().findPath(tile, randomVillageTile, navSettings, 0);

					if (!path.isEmpty())
					{
						randomVillageTile = tile;
						break;
					}
				}
			}
		}
		while (1);

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(9);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/worldmap_06.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.mastermind_scenario_intro");
		}, null);
	}

	function onInit()
	{
		this.World.Assets.m.BrothersMax = 11;
	}

	function onUpdateHiringRoster( _roster )
	{
		local garbage = [];
		local bros = _roster.getAll();

		foreach( i, bro in bros )
		{
			if (!bro.getBackground().isCombatBackground())
			{
				garbage.push(bro);
			}
		}

		foreach( g in garbage )
		{
			_roster.remove(g);
		}
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

});

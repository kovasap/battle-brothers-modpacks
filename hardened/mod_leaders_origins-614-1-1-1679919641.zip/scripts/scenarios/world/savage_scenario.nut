this.savage_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.savage";
		this.m.Name = "Leader - The Savage";
		this.m.Description = "[p=c][img]gfx/ui/events/event_139.png[/img][/p][p]You are the strongest of them all, the most ambitious. The north made you what you are, but it does not offer you much. It\'s time to carve your path southward and claim your share of the world. You wear the Face of Death. You are the Savage.\n\n[color=#bcad8c]Leader:[/color] Start with the Savage, a named helmet, and five companions.\n[color=#bcad8c]Pillagers:[/color] You have a higher chance to get any items from slain enemies as loot.\n[color=#bcad8c]Outlaws:[/color] Bad relations to some noble factions at start.\n[color=#bcad8c]Avatar:[/color] If the Savage dies, the campaign ends.[/p]";
		this.m.Difficulty = 2;
		this.m.Order = 314;
	}

	function isValid()
	{
		return this.Const.DLC.Wildmen;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();

		for( local i = 0; i < 6; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.m.HireTime = this.Time.getVirtualTimeF();
		}

		local bros = roster.getAll();
		bros[0].setStartValuesEx([
			"barbarian_background"
		]);
		bros[0].setTitle("The Savage");
		bros[0].getBackground().m.RawDescription = "Pure ambition. Death Incarnate to those who oppose him.";
		bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].improveMood(1.0, "Drawn blood");
		bros[0].setPlaceInFormation(4);
		bros[0].getSkills().removeByID("trait.ailing");
		bros[0].getSkills().removeByID("trait.asthmatic");
		bros[0].getSkills().removeByID("trait.athletic");
		bros[0].getSkills().removeByID("trait.bleeder");
		bros[0].getSkills().removeByID("trait.bloodthirsty");
		bros[0].getSkills().removeByID("trait.brave");
		bros[0].getSkills().removeByID("trait.bright");
		bros[0].getSkills().removeByID("trait.brute");
		bros[0].getSkills().removeByID("trait.clubfooted");
		bros[0].getSkills().removeByID("trait.clumsy");
		bros[0].getSkills().removeByID("trait.cocky");
		bros[0].getSkills().removeByID("trait.craven");
		bros[0].getSkills().removeByID("trait.dastard");
		bros[0].getSkills().removeByID("trait.deathwish");
		bros[0].getSkills().removeByID("trait.determined");
		bros[0].getSkills().removeByID("trait.dexterous");
		bros[0].getSkills().removeByID("trait.disloyal");
		bros[0].getSkills().removeByID("trait.drunkard");
		bros[0].getSkills().removeByID("trait.dumb");
		bros[0].getSkills().removeByID("trait.eagle_eyes");
		bros[0].getSkills().removeByID("trait.fainthearted");
		bros[0].getSkills().removeByID("trait.fat");
		bros[0].getSkills().removeByID("trait.fear_beasts");
		bros[0].getSkills().removeByID("trait.fear_greenskins");
		bros[0].getSkills().removeByID("trait.fear_undead");
		bros[0].getSkills().removeByID("trait.fearless");
		bros[0].getSkills().removeByID("trait.fragile");
		bros[0].getSkills().removeByID("trait.gluttonous");
		bros[0].getSkills().removeByID("trait.greedy");
		bros[0].getSkills().removeByID("trait.hate_beasts");
		bros[0].getSkills().removeByID("trait.hate_greenskins");
		bros[0].getSkills().removeByID("trait.hate_undead");
		bros[0].getSkills().removeByID("trait.hesitant");
		bros[0].getSkills().removeByID("trait.huge");
		bros[0].getSkills().removeByID("trait.impatient");
		bros[0].getSkills().removeByID("trait.insecure");
		bros[0].getSkills().removeByID("trait.iron_jaw");
		bros[0].getSkills().removeByID("trait.iron_lungs");
		bros[0].getSkills().removeByID("trait.irrational");
		bros[0].getSkills().removeByID("trait.loyal");
		bros[0].getSkills().removeByID("trait.lucky");
		bros[0].getSkills().removeByID("trait.night_blind");
		bros[0].getSkills().removeByID("trait.night_owl");
		bros[0].getSkills().removeByID("trait.optimist");
		bros[0].getSkills().removeByID("trait.paranoid");
		bros[0].getSkills().removeByID("trait.pessimist");
		bros[0].getSkills().removeByID("trait.quick");
		bros[0].getSkills().removeByID("trait.short_sighted");
		bros[0].getSkills().removeByID("trait.spartan");
		bros[0].getSkills().removeByID("trait.strong");
		bros[0].getSkills().removeByID("trait.superstitious");
		bros[0].getSkills().removeByID("trait.sure_footing");
		bros[0].getSkills().removeByID("trait.survivor");
		bros[0].getSkills().removeByID("trait.swift");
		bros[0].getSkills().removeByID("trait.teamplayer");
		bros[0].getSkills().removeByID("trait.tiny");
		bros[0].getSkills().removeByID("trait.tough");
		bros[0].getSkills().removeByID("trait.weasel");
		bros[0].m.Skills.add(this.new("scripts/skills/traits/player_character_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/brute_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/strong_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/determined_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/iron_jaw_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_crippling_strikes"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_coup_de_grace"));
		bros[0].m.PerkPoints = 3;
		bros[0].m.LevelUps = 3;
		bros[0].m.Level = 4;
		bros[0].getBaseProperties().MeleeDefense -= 2;
		bros[0].m.Talents = [];
		local talents = bros[0].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 2;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 0;
		talents[this.Const.Attributes.MeleeSkill] = 3;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		bros[0].m.Attributes = [];
		bros[0].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[0].m.BaseProperties.Hitpoints = 75;
		bros[0].m.BaseProperties.Bravery = 60;
		bros[0].m.BaseProperties.Stamina = 110;
		bros[0].m.BaseProperties.MeleeSkill = 68;
		bros[0].m.BaseProperties.MeleeDefense = 10;
		bros[0].m.BaseProperties.RangedDefense = 6;
		local items = bros[0].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		local helmet = this.new("scripts/items/helmets/named/named_metal_skull_helmet");
		helmet.m.Name = "The Face of Death";
		items.equip(helmet);
		items.equip(this.new("scripts/items/armor/barbarians/thick_plated_barbarian_armor"));
		items.equip(this.new("scripts/items/weapons/barbarians/heavy_rusty_axe"));
		bros[1].setStartValuesEx([
			"barbarian_background"
		]);
		bros[1].setTitle("The Old");
		bros[1].getBackground().m.RawDescription = "Old and tired. %name% wants to die honoroubly in battle and be done with it all.";
		bros[1].improveMood(1.0, "Had a successful raid");
		bros[1].setPlaceInFormation(5);
		bros[1].getSkills().removeByID("trait.ailing");
		bros[1].getSkills().removeByID("trait.asthmatic");
		bros[1].getSkills().removeByID("trait.athletic");
		bros[1].getSkills().removeByID("trait.bleeder");
		bros[1].getSkills().removeByID("trait.bloodthirsty");
		bros[1].getSkills().removeByID("trait.brave");
		bros[1].getSkills().removeByID("trait.bright");
		bros[1].getSkills().removeByID("trait.brute");
		bros[1].getSkills().removeByID("trait.clubfooted");
		bros[1].getSkills().removeByID("trait.clumsy");
		bros[1].getSkills().removeByID("trait.cocky");
		bros[1].getSkills().removeByID("trait.craven");
		bros[1].getSkills().removeByID("trait.dastard");
		bros[1].getSkills().removeByID("trait.deathwish");
		bros[1].getSkills().removeByID("trait.determined");
		bros[1].getSkills().removeByID("trait.dexterous");
		bros[1].getSkills().removeByID("trait.disloyal");
		bros[1].getSkills().removeByID("trait.drunkard");
		bros[1].getSkills().removeByID("trait.dumb");
		bros[1].getSkills().removeByID("trait.eagle_eyes");
		bros[1].getSkills().removeByID("trait.fainthearted");
		bros[1].getSkills().removeByID("trait.fat");
		bros[1].getSkills().removeByID("trait.fear_beasts");
		bros[1].getSkills().removeByID("trait.fear_greenskins");
		bros[1].getSkills().removeByID("trait.fear_undead");
		bros[1].getSkills().removeByID("trait.fearless");
		bros[1].getSkills().removeByID("trait.fragile");
		bros[1].getSkills().removeByID("trait.gluttonous");
		bros[1].getSkills().removeByID("trait.greedy");
		bros[1].getSkills().removeByID("trait.hate_beasts");
		bros[1].getSkills().removeByID("trait.hate_greenskins");
		bros[1].getSkills().removeByID("trait.hate_undead");
		bros[1].getSkills().removeByID("trait.hesitant");
		bros[1].getSkills().removeByID("trait.huge");
		bros[1].getSkills().removeByID("trait.impatient");
		bros[1].getSkills().removeByID("trait.insecure");
		bros[1].getSkills().removeByID("trait.iron_jaw");
		bros[1].getSkills().removeByID("trait.iron_lungs");
		bros[1].getSkills().removeByID("trait.irrational");
		bros[1].getSkills().removeByID("trait.loyal");
		bros[1].getSkills().removeByID("trait.lucky");
		bros[1].getSkills().removeByID("trait.night_blind");
		bros[1].getSkills().removeByID("trait.night_owl");
		bros[1].getSkills().removeByID("trait.optimist");
		bros[1].getSkills().removeByID("trait.paranoid");
		bros[1].getSkills().removeByID("trait.pessimist");
		bros[1].getSkills().removeByID("trait.quick");
		bros[1].getSkills().removeByID("trait.short_sighted");
		bros[1].getSkills().removeByID("trait.spartan");
		bros[1].getSkills().removeByID("trait.strong");
		bros[1].getSkills().removeByID("trait.superstitious");
		bros[1].getSkills().removeByID("trait.sure_footing");
		bros[1].getSkills().removeByID("trait.survivor");
		bros[1].getSkills().removeByID("trait.swift");
		bros[1].getSkills().removeByID("trait.teamplayer");
		bros[1].getSkills().removeByID("trait.tiny");
		bros[1].getSkills().removeByID("trait.tough");
		bros[1].getSkills().removeByID("trait.weasel");
		bros[1].m.Skills.add(this.new("scripts/skills/traits/old_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/traits/deathwish_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/traits/tough_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/traits/fearless_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/perks/perk_steel_brow"));
		bros[1].m.PerkPoints = 3;
		bros[1].m.LevelUps = 3;
		bros[1].m.Level = 4;
		bros[1].m.Talents = [];
		local talents = bros[1].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.MeleeSkill] = 2;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.Hitpoints] = 1;
		talents[this.Const.Attributes.Fatigue] = 2;
		bros[1].m.Attributes = [];
		bros[1].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[1].m.BaseProperties.Hitpoints = 70;
		bros[1].m.BaseProperties.Bravery = 50;
		local items = bros[1].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/helmets/barbarians/leather_headband"));
		items.equip(this.new("scripts/items/armor/barbarians/thick_plated_barbarian_armor"));
		items.equip(this.new("scripts/items/weapons/barbarians/rusty_warblade"));
		bros[2].setStartValuesEx([
			"barbarian_background"
		]);
		bros[2].setTitle("The Bear");
		bros[2].getBackground().m.RawDescription = "The one they call The Savage is his friend for a long time. He will accompany him until the end of the world and back. The south is a good start, though.";
		bros[2].improveMood(1.0, "Had a successful raid");
		bros[2].setPlaceInFormation(3);
		bros[2].getSkills().removeByID("trait.ailing");
		bros[2].getSkills().removeByID("trait.asthmatic");
		bros[2].getSkills().removeByID("trait.athletic");
		bros[2].getSkills().removeByID("trait.bleeder");
		bros[2].getSkills().removeByID("trait.bloodthirsty");
		bros[2].getSkills().removeByID("trait.brave");
		bros[2].getSkills().removeByID("trait.bright");
		bros[2].getSkills().removeByID("trait.brute");
		bros[2].getSkills().removeByID("trait.clubfooted");
		bros[2].getSkills().removeByID("trait.clumsy");
		bros[2].getSkills().removeByID("trait.cocky");
		bros[2].getSkills().removeByID("trait.craven");
		bros[2].getSkills().removeByID("trait.dastard");
		bros[2].getSkills().removeByID("trait.deathwish");
		bros[2].getSkills().removeByID("trait.determined");
		bros[2].getSkills().removeByID("trait.dexterous");
		bros[2].getSkills().removeByID("trait.disloyal");
		bros[2].getSkills().removeByID("trait.drunkard");
		bros[2].getSkills().removeByID("trait.dumb");
		bros[2].getSkills().removeByID("trait.eagle_eyes");
		bros[2].getSkills().removeByID("trait.fainthearted");
		bros[2].getSkills().removeByID("trait.fat");
		bros[2].getSkills().removeByID("trait.fear_beasts");
		bros[2].getSkills().removeByID("trait.fear_greenskins");
		bros[2].getSkills().removeByID("trait.fear_undead");
		bros[2].getSkills().removeByID("trait.fearless");
		bros[2].getSkills().removeByID("trait.fragile");
		bros[2].getSkills().removeByID("trait.gluttonous");
		bros[2].getSkills().removeByID("trait.greedy");
		bros[2].getSkills().removeByID("trait.hate_beasts");
		bros[2].getSkills().removeByID("trait.hate_greenskins");
		bros[2].getSkills().removeByID("trait.hate_undead");
		bros[2].getSkills().removeByID("trait.hesitant");
		bros[2].getSkills().removeByID("trait.huge");
		bros[2].getSkills().removeByID("trait.impatient");
		bros[2].getSkills().removeByID("trait.insecure");
		bros[2].getSkills().removeByID("trait.iron_jaw");
		bros[2].getSkills().removeByID("trait.iron_lungs");
		bros[2].getSkills().removeByID("trait.irrational");
		bros[2].getSkills().removeByID("trait.loyal");
		bros[2].getSkills().removeByID("trait.lucky");
		bros[2].getSkills().removeByID("trait.night_blind");
		bros[2].getSkills().removeByID("trait.night_owl");
		bros[2].getSkills().removeByID("trait.optimist");
		bros[2].getSkills().removeByID("trait.paranoid");
		bros[2].getSkills().removeByID("trait.pessimist");
		bros[2].getSkills().removeByID("trait.quick");
		bros[2].getSkills().removeByID("trait.short_sighted");
		bros[2].getSkills().removeByID("trait.spartan");
		bros[2].getSkills().removeByID("trait.strong");
		bros[2].getSkills().removeByID("trait.superstitious");
		bros[2].getSkills().removeByID("trait.sure_footing");
		bros[2].getSkills().removeByID("trait.survivor");
		bros[2].getSkills().removeByID("trait.swift");
		bros[2].getSkills().removeByID("trait.teamplayer");
		bros[2].getSkills().removeByID("trait.tiny");
		bros[2].getSkills().removeByID("trait.tough");
		bros[2].getSkills().removeByID("trait.weasel");
		bros[2].m.Skills.add(this.new("scripts/skills/traits/iron_lungs_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/traits/huge_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/traits/loyal_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/perks/perk_adrenalin"));
		bros[2].m.PerkPoints = 2;
		bros[2].m.LevelUps = 2;
		bros[2].m.Level = 3;
		bros[2].m.Talents = [];
		local talents = bros[2].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 2;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 0;
		talents[this.Const.Attributes.MeleeSkill] = 1;
		talents[this.Const.Attributes.MeleeDefense] = 3;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		bros[2].m.Attributes = [];
		bros[2].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[2].m.BaseProperties.Hitpoints = 80;
		bros[2].m.BaseProperties.MeleeDefense = 10;
		local items = bros[2].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/helmets/barbarians/bear_headpiece"));
		items.equip(this.new("scripts/items/armor/barbarians/rugged_scale_armor"));
		items.equip(this.new("scripts/items/weapons/barbarians/skull_hammer"));
		bros[3].setStartValuesEx([
			"barbarian_background"
		]);
		bros[3].setTitle("The Unholy");
		bros[3].getBackground().m.RawDescription = "They think %name% wants to tame men instead of beasts but %name% wants to tame the world.";
		bros[3].improveMood(1.0, "Had a successful raid");
		bros[3].setPlaceInFormation(13);
		bros[3].getSkills().removeByID("trait.ailing");
		bros[3].getSkills().removeByID("trait.asthmatic");
		bros[3].getSkills().removeByID("trait.clubfooted");
		bros[3].getSkills().removeByID("trait.clumsy");
		bros[3].getSkills().removeByID("trait.craven");
		bros[3].getSkills().removeByID("trait.dastard");
		bros[3].getSkills().removeByID("trait.deathwish");
		bros[3].getSkills().removeByID("trait.drunkard");
		bros[3].getSkills().removeByID("trait.dumb");
		bros[3].getSkills().removeByID("trait.fainthearted");
		bros[3].getSkills().removeByID("trait.fragile");
		bros[3].getSkills().removeByID("trait.tiny");
		bros[3].getSkills().removeByID("trait.weasel");
		bros[3].m.Skills.add(this.new("scripts/skills/traits/dexterous_trait"));
		bros[3].m.Skills.add(this.new("scripts/skills/perks/perk_mastery_cleaver"));
		bros[3].m.PerkPoints = 2;
		bros[3].m.LevelUps = 2;
		bros[3].m.Level = 3;
		bros[3].m.Talents = [];
		local talents = bros[3].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 0;
		talents[this.Const.Attributes.Bravery] = 2;
		talents[this.Const.Attributes.Initiative] = 1;
		talents[this.Const.Attributes.MeleeSkill] = 2;
		talents[this.Const.Attributes.MeleeDefense] = 1;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 2;
		local items = bros[3].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		local wolf = this.new("scripts/items/accessory/wolf_item");
		wolf.m.Name = "Rawarr the Wolf";
		items.equip(wolf);
		local armor = this.new("scripts/items/armor/barbarians/hide_and_bone_armor");
		armor.setUpgrade(this.new("scripts/items/armor_upgrades/protective_runes_upgrade"));
		bros[3].getItems().equip(armor);
		items.equip(this.new("scripts/items/helmets/barbarians/beastmasters_headpiece"));
		items.equip(this.new("scripts/items/weapons/barbarians/thorned_whip"));
		bros[4].setStartValuesEx([
			"barbarian_background"
		]);
		bros[4].setTitle("The Idiot");
		bros[4].getBackground().m.RawDescription = "%name% likes to hunt and fight. Savage likes to hunt and fight. %name% likes the Savage.";
		bros[4].setPlaceInFormation(2);
		bros[4].improveMood(1.0, "Had a successful raid");
		bros[4].getSkills().removeByID("trait.ailing");
		bros[4].getSkills().removeByID("trait.asthmatic");
		bros[4].getSkills().removeByID("trait.clubfooted");
		bros[4].getSkills().removeByID("trait.clumsy");
		bros[4].getSkills().removeByID("trait.craven");
		bros[4].getSkills().removeByID("trait.dastard");
		bros[4].getSkills().removeByID("trait.deathwish");
		bros[4].getSkills().removeByID("trait.drunkard");
		bros[4].getSkills().removeByID("trait.dumb");
		bros[4].getSkills().removeByID("trait.fainthearted");
		bros[4].getSkills().removeByID("trait.fat");
		bros[4].getSkills().removeByID("trait.fragile");
		bros[4].getSkills().removeByID("trait.tiny");
		bros[4].getSkills().removeByID("trait.weasel");
		bros[4].m.Skills.add(this.new("scripts/skills/traits/survivor_trait"));
		bros[4].m.Skills.add(this.new("scripts/skills/traits/eagle_eyes_trait"));
		bros[4].m.Skills.add(this.new("scripts/skills/injury_permanent/brain_damage_injury"));
		bros[4].m.Skills.add(this.new("scripts/skills/perks/perk_mastery_throwing"));
		bros[4].m.PerkPoints = 2;
		bros[4].m.LevelUps = 2;
		bros[4].m.Level = 3;
		bros[4].m.Talents = [];
		local talents = bros[4].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 0;
		talents[this.Const.Attributes.Initiative] = 1;
		talents[this.Const.Attributes.MeleeSkill] = 1;
		talents[this.Const.Attributes.MeleeDefense] = 1;
		talents[this.Const.Attributes.RangedSkill] = 3;
		talents[this.Const.Attributes.RangedDefense] = 1;
		bros[4].m.Attributes = [];
		bros[4].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[4].m.BaseProperties.RangedSkill = 50;
		local items = bros[4].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/helmets/barbarians/leather_helmet"));
		items.equip(this.new("scripts/items/armor/barbarians/scrap_metal_armor"));
		items.equip(this.new("scripts/items/weapons/barbarians/heavy_throwing_axe"));
		items.equip(this.new("scripts/items/shields/wooden_shield_old"));
		bros[5].setStartValuesEx([
			"barbarian_background"
		]);
		bros[5].setTitle("The Young");
		bros[5].getBackground().m.RawDescription = "%name% has simple needs: the glory of battle. Gold. Women. Not necessarily in that order.";
		bros[5].setPlaceInFormation(6);
		bros[5].improveMood(1.0, "Had a successful raid");
		bros[5].getSkills().removeByID("trait.ailing");
		bros[5].getSkills().removeByID("trait.asthmatic");
		bros[5].getSkills().removeByID("trait.clubfooted");
		bros[5].getSkills().removeByID("trait.clumsy");
		bros[5].getSkills().removeByID("trait.craven");
		bros[5].getSkills().removeByID("trait.dastard");
		bros[5].getSkills().removeByID("trait.deathwish");
		bros[5].getSkills().removeByID("trait.drunkard");
		bros[5].getSkills().removeByID("trait.dumb");
		bros[5].getSkills().removeByID("trait.fainthearted");
		bros[5].getSkills().removeByID("trait.fat");
		bros[5].getSkills().removeByID("trait.fearless");
		bros[5].getSkills().removeByID("trait.fragile");
		bros[5].getSkills().removeByID("trait.tiny");
		bros[5].getSkills().removeByID("trait.weasel");
		bros[5].m.Skills.add(this.new("scripts/skills/traits/quick_trait"));
		bros[5].m.Skills.add(this.new("scripts/skills/traits/bloodthirsty_trait"));
		bros[5].m.Skills.add(this.new("scripts/skills/perks/perk_adrenalin"));
		bros[5].m.PerkPoints = 0;
		bros[5].m.LevelUps = 0;
		bros[5].m.Level = 1;
		bros[5].m.Talents = [];
		local talents = bros[5].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 2;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 0;
		talents[this.Const.Attributes.Initiative] = 1;
		talents[this.Const.Attributes.MeleeSkill] = 2;
		talents[this.Const.Attributes.MeleeDefense] = 1;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		local items = bros[5].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/helmets/barbarians/leather_headband"));
		items.equip(this.new("scripts/items/weapons/barbarians/antler_cleaver"));
		items.equip(this.new("scripts/items/armor/barbarians/animal_hide_armor"));
		items.equip(this.new("scripts/items/shields/wooden_shield_old"));
		this.World.Assets.m.BusinessReputation = -50;
		this.World.Assets.m.MoralReputation = -30;
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/goat_cheese_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/smoked_ham_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/cured_venison_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/pickled_mushrooms_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/trade/furs_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/armor_upgrades/barbarian_horn_upgrade"));
		this.World.Assets.getStash().add(this.new("scripts/items/loot/silverware_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/loot/silver_bowl_item"));
    this.World.Assets.getStash().add(this.new("scripts/items/weapons/barbarians/heavy_throwing_axe"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/barbarians/blunt_cleaver"));

	}

	function onSpawnPlayer()
	{
		local randomVillage;
		local northernmostY = 0;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
		{
			local v = this.World.EntityManager.getSettlements()[i];

			if (v.getTile().SquareCoords.Y > northernmostY && !v.isMilitary() && !v.isIsolatedFromRoads() && v.getSize() <= 2)
			{
				northernmostY = v.getTile().SquareCoords.Y;
				randomVillage = v;
			}
		}

		randomVillage.setLastSpawnTimeToNow();
		local randomVillageTile = randomVillage.getTile();
		local navSettings = this.World.getNavigator().createSettings();
		navSettings.ActionPointCosts = this.Const.World.TerrainTypeNavCost_Flat;

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 2), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 2));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 2), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 2));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore || tile.IsOccupied)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) <= 1)
				{
				}
				else
				{
					local path = this.World.getNavigator().findPath(tile, randomVillageTile, navSettings, 0);

					if (!path.isEmpty())
					{
						randomVillageTile = tile;
						break;
					}
				}
			}
		}
		while (1);

		local attachedLocations = randomVillage.getAttachedLocations();
		local closest;
		local dist = 99999;

		foreach( a in attachedLocations )
		{
			if (a.getTile().getDistanceTo(randomVillageTile) < dist)
			{
				dist = a.getTile().getDistanceTo(randomVillageTile);
				closest = a;
			}
		}

		if (closest != null)
		{
			closest.setActive(false);
			closest.spawnFireAndSmoke();
		}

		local s = this.new("scripts/entity/world/settlements/situations/raided_situation");
		s.setValidForDays(5);
		randomVillage.addSituation(s);
		local nobles = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.NobleHouse);
		local houses = [];

		foreach( n in nobles )
		{
			local closest;
			local dist = 9999;

			foreach( s in n.getSettlements() )
			{
				local d = s.getTile().getDistanceTo(randomVillageTile);

				if (d < dist)
				{
					dist = d;
					closest = s;
				}
			}

			houses.push({
				Faction = n,
				Dist = dist
			});
		}

		houses.sort(function ( _a, _b )
		{
			if (_a.Dist > _b.Dist)
			{
				return 1;
			}
			else if (_a.Dist < _b.Dist)
			{
				return -1;
			}

			return 0;
		});

		for( local i = 0; i < 2; i = ++i )
		{
			houses[i].Faction.addPlayerRelation(-100.0, "You are considered outlaws");
		}

		houses[1].Faction.addPlayerRelation(18.0);
		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(5);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/barbarians_02.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.savage_scenario_intro");
		}, null);
	}

	function isDroppedAsLoot( _item )
	{
		return this.Math.rand(1, 100) <= 15;
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

});

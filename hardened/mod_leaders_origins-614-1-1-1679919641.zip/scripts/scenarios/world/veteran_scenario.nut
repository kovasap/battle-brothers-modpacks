this.veteran_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.veteran";
		this.m.Name = "Leader - The Veteran";
		this.m.Description = "[p=c][img]gfx/ui/events/event_24.png[/img][/p][p]The war is over. You are discharged, honorably even. \'Proven valor\' got you rewarded with a special mace, but who are you going to hit with it? Too young to retire, too old to learn a trade. You visit the tavern with your comrades, who suffered the same fate. A few drinks later and you decide to begin your own mercenary company. More drinks are ordered. You can handle it. You are the Veteran.\n\n[color=#bcad8c]Leader:[/color] Start with the Veteran, a named mace, and three companions.\n[color=#bcad8c]Warriors Only:[/color] Can only hire combat backgrounds.\n[color=#bcad8c]Avatar:[/color] If the Veteran dies, the campaign ends.[/p]";
		this.m.Difficulty = 2;
		this.m.Order = 322;
	}

	function isValid()
	{
		return this.Const.DLC.Wildmen;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local names = [];

		for( local i = 0; i < 4; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.worsenMood(0.5, "Has a hangover");
			bro.improveMood(1.0, "Got a new occupation");
			bro.m.HireTime = this.Time.getVirtualTimeF();
		}

		local bros = roster.getAll();
		bros[0].setStartValuesEx([
			"sellsword_background"
		]);
		bros[0].getBackground().m.RawDescription = "An \'Old-hand\', has seen many battles, a few more will not hurt. Experience is everything.";
		bros[0].setTitle("The Veteran");
		bros[0].setPlaceInFormation(4);
		bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].getSkills().removeByID("trait.ailing");
		bros[0].getSkills().removeByID("trait.asthmatic");
		bros[0].getSkills().removeByID("trait.athletic");
		bros[0].getSkills().removeByID("trait.bleeder");
		bros[0].getSkills().removeByID("trait.bloodthirsty");
		bros[0].getSkills().removeByID("trait.brave");
		bros[0].getSkills().removeByID("trait.bright");
		bros[0].getSkills().removeByID("trait.brute");
		bros[0].getSkills().removeByID("trait.clubfooted");
		bros[0].getSkills().removeByID("trait.clumsy");
		bros[0].getSkills().removeByID("trait.cocky");
		bros[0].getSkills().removeByID("trait.craven");
		bros[0].getSkills().removeByID("trait.dastard");
		bros[0].getSkills().removeByID("trait.deathwish");
		bros[0].getSkills().removeByID("trait.determined");
		bros[0].getSkills().removeByID("trait.dexterous");
		bros[0].getSkills().removeByID("trait.disloyal");
		bros[0].getSkills().removeByID("trait.drunkard");
		bros[0].getSkills().removeByID("trait.dumb");
		bros[0].getSkills().removeByID("trait.eagle_eyes");
		bros[0].getSkills().removeByID("trait.fainthearted");
		bros[0].getSkills().removeByID("trait.fat");
		bros[0].getSkills().removeByID("trait.fear_beasts");
		bros[0].getSkills().removeByID("trait.fear_greenskins");
		bros[0].getSkills().removeByID("trait.fear_undead");
		bros[0].getSkills().removeByID("trait.fearless");
		bros[0].getSkills().removeByID("trait.fragile");
		bros[0].getSkills().removeByID("trait.gluttonous");
		bros[0].getSkills().removeByID("trait.greedy");
		bros[0].getSkills().removeByID("trait.hate_beasts");
		bros[0].getSkills().removeByID("trait.hate_greenskins");
		bros[0].getSkills().removeByID("trait.hate_undead");
		bros[0].getSkills().removeByID("trait.hesitant");
		bros[0].getSkills().removeByID("trait.huge");
		bros[0].getSkills().removeByID("trait.impatient");
		bros[0].getSkills().removeByID("trait.insecure");
		bros[0].getSkills().removeByID("trait.iron_jaw");
		bros[0].getSkills().removeByID("trait.iron_lungs");
		bros[0].getSkills().removeByID("trait.irrational");
		bros[0].getSkills().removeByID("trait.loyal");
		bros[0].getSkills().removeByID("trait.lucky");
		bros[0].getSkills().removeByID("trait.night_blind");
		bros[0].getSkills().removeByID("trait.night_owl");
		bros[0].getSkills().removeByID("trait.optimist");
		bros[0].getSkills().removeByID("trait.paranoid");
		bros[0].getSkills().removeByID("trait.pessimist");
		bros[0].getSkills().removeByID("trait.quick");
		bros[0].getSkills().removeByID("trait.short_sighted");
		bros[0].getSkills().removeByID("trait.spartan");
		bros[0].getSkills().removeByID("trait.strong");
		bros[0].getSkills().removeByID("trait.superstitious");
		bros[0].getSkills().removeByID("trait.sure_footing");
		bros[0].getSkills().removeByID("trait.survivor");
		bros[0].getSkills().removeByID("trait.swift");
		bros[0].getSkills().removeByID("trait.teamplayer");
		bros[0].getSkills().removeByID("trait.tiny");
		bros[0].getSkills().removeByID("trait.tough");
		bros[0].getSkills().removeByID("trait.weasel");
  	bros[0].getSkills().add(this.new("scripts/skills/traits/player_character_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/tough_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/swift_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/determined_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_steel_brow"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_fortified_mind"));
		bros[0].m.Skills.add(this.new("scripts/skills/injury_permanent/missing_ear_injury"));
		bros[0].m.Skills.add(this.new("scripts/skills/effects_world/hangover_effect"));
		bros[0].m.PerkPoints = 3;
		bros[0].m.LevelUps = 3;
		bros[0].m.Level = 4;
		bros[0].getBaseProperties().MeleeDefense -= 2;
		bros[0].m.Talents = [];
		local talents = bros[0].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 2;
		talents[this.Const.Attributes.Initiative] = 1;
		talents[this.Const.Attributes.MeleeSkill] = 3;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
   	local items = bros[0].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		local mace = this.new("scripts/items/weapons/named/named_mace");
		mace.m.Name = "The Sergeant's Will";
		items.equip(mace);
		items.equip(this.new("scripts/items/armor/reinforced_mail_hauberk"));
		bros[1].setStartValuesEx([
			"sellsword_background"
		]);
		bros[1].getBackground().m.RawDescription = "%name% has seen a few battles, was part of a few campaigns. Knows how to handle a weapon or two.";
		bros[1].setPlaceInFormation(13);
		bros[1].getSkills().removeByID("trait.ailing");
		bros[1].getSkills().removeByID("trait.asthmatic");
		bros[1].getSkills().removeByID("trait.clubfooted");
		bros[1].getSkills().removeByID("trait.clumsy");
		bros[1].getSkills().removeByID("trait.craven");
		bros[1].getSkills().removeByID("trait.dastard");
		bros[1].getSkills().removeByID("trait.deathwish");
		bros[1].getSkills().removeByID("trait.disloyal");
		bros[1].getSkills().removeByID("trait.drunkard");
		bros[1].getSkills().removeByID("trait.dumb");
		bros[1].getSkills().removeByID("trait.fragile");
		bros[1].getSkills().removeByID("trait.gluttonous");
		bros[1].getSkills().removeByID("trait.insecure");
		bros[1].getSkills().removeByID("trait.loyal");
		bros[1].getSkills().removeByID("trait.tiny");
		bros[1].getSkills().removeByID("trait.weasel");
		bros[1].getSkills().add(this.new("scripts/skills/traits/loyal_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/effects_world/hangover_effect"));
		bros[1].m.PerkPoints = 2;
		bros[1].m.LevelUps = 2;
		bros[1].m.Level = 3;
		bros[1].m.Talents = [];
		local talents = bros[1].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 2;
		talents[this.Const.Attributes.MeleeSkill] = 0;
		talents[this.Const.Attributes.MeleeDefense] = 0;
		talents[this.Const.Attributes.RangedSkill] = 2;
		talents[this.Const.Attributes.RangedDefense] = 2;
		local items = bros[1].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/helmets/full_aketon_cap"));
		local armor = this.new("scripts/items/armor/mail_shirt");
		armor.setUpgrade(this.new("scripts/items/armor_upgrades/leather_shoulderguards_upgrade"));
		bros[1].getItems().equip(armor);
		items.equip(this.new("scripts/items/weapons/heavy_crossbow"));
		items.equip(this.new("scripts/items/ammo/quiver_of_bolts"));
		bros[2].setStartValuesEx([
			"sellsword_background"
		]);
		bros[2].getBackground().m.RawDescription = "%name% has seen a few battles, was part of a few campaigns. Knows how to handle a weapon or two.";
		bros[2].setPlaceInFormation(3);
		bros[2].getSkills().removeByID("trait.ailing");
		bros[2].getSkills().removeByID("trait.asthmatic");
		bros[2].getSkills().removeByID("trait.clubfooted");
		bros[2].getSkills().removeByID("trait.clumsy");
		bros[2].getSkills().removeByID("trait.craven");
		bros[2].getSkills().removeByID("trait.dastard");
		bros[2].getSkills().removeByID("trait.deathwish");
		bros[2].getSkills().removeByID("trait.disloyal");
		bros[2].getSkills().removeByID("trait.drunkard");
		bros[2].getSkills().removeByID("trait.dumb");
		bros[2].getSkills().removeByID("trait.fragile");
		bros[2].getSkills().removeByID("trait.gluttonous");
		bros[2].getSkills().removeByID("trait.insecure");
		bros[2].getSkills().removeByID("trait.loyal");
		bros[2].getSkills().removeByID("trait.tiny");
		bros[2].getSkills().removeByID("trait.weasel");
		bros[2].getSkills().add(this.new("scripts/skills/traits/loyal_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/effects_world/hangover_effect"));
		bros[2].m.PerkPoints = 2;
		bros[2].m.LevelUps = 2;
		bros[2].m.Level = 3;
		bros[2].m.Talents = [];
		local talents = bros[2].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 3;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 0;
		talents[this.Const.Attributes.Initiative] = 0;
		talents[this.Const.Attributes.MeleeSkill] = 1;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 1;
		local items = bros[2].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/helmets/padded_nasal_helmet"));
		local armor = this.new("scripts/items/armor/mail_shirt");
		armor.setUpgrade(this.new("scripts/items/armor_upgrades/leather_shoulderguards_upgrade"));
		bros[2].getItems().equip(armor);
		items.equip(this.new("scripts/items/weapons/arming_sword"));
		items.equip(this.new("scripts/items/shields/kite_shield"));
		bros[3].setStartValuesEx([
			"sellsword_background"
		]);
		bros[3].getBackground().m.RawDescription = "%name% has seen a few battles, was part of a few campaigns. Knows how to handle a weapon or two.";
		bros[3].setPlaceInFormation(5);
		bros[3].getSkills().removeByID("trait.ailing");
		bros[3].getSkills().removeByID("trait.asthmatic");
		bros[3].getSkills().removeByID("trait.clubfooted");
		bros[3].getSkills().removeByID("trait.clumsy");
		bros[3].getSkills().removeByID("trait.craven");
		bros[3].getSkills().removeByID("trait.dastard");
		bros[3].getSkills().removeByID("trait.deathwish");
		bros[3].getSkills().removeByID("trait.disloyal");
		bros[3].getSkills().removeByID("trait.drunkard");
		bros[3].getSkills().removeByID("trait.dumb");
		bros[3].getSkills().removeByID("trait.fragile");
		bros[3].getSkills().removeByID("trait.gluttonous");
		bros[3].getSkills().removeByID("trait.insecure");
		bros[3].getSkills().removeByID("trait.loyal");
		bros[3].getSkills().removeByID("trait.tiny");
		bros[3].getSkills().removeByID("trait.weasel");
		bros[3].getSkills().add(this.new("scripts/skills/traits/loyal_trait"));
		bros[3].m.Skills.add(this.new("scripts/skills/effects_world/hangover_effect"));
		bros[3].m.PerkPoints = 2;
		bros[3].m.LevelUps = 2;
		bros[3].m.Level = 3;
		bros[3].m.Talents = [];
		local talents = bros[3].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 0;
		talents[this.Const.Attributes.Initiative] = 1;
		talents[this.Const.Attributes.MeleeSkill] = 2;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 1;
		local items = bros[3].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/helmets/padded_nasal_helmet"));
		local armor = this.new("scripts/items/armor/mail_shirt");
		armor.setUpgrade(this.new("scripts/items/armor_upgrades/leather_shoulderguards_upgrade"));
		bros[3].getItems().equip(armor);
		items.equip(this.new("scripts/items/weapons/billhook"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/cured_rations_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/cured_rations_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/cured_rations_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/bandage_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/bandage_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/armor_upgrades/metal_pauldrons_upgrade"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_set_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/armored_wardog_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/rondel_dagger"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/bludgeon"));
		this.World.Assets.getStash().add(this.new("scripts/items/ammo/quiver_of_bolts"));

	}

	function onSpawnPlayer()
	{
		local randomVillage;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
		{
			randomVillage = this.World.EntityManager.getSettlements()[i];

			if (randomVillage.isMilitary() && !randomVillage.isIsolatedFromRoads() && randomVillage.getSize() >= 3 && !randomVillage.isSouthern())
			{
				break;
			}
		}

		local randomVillageTile = randomVillage.getTile();

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 1), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 1));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 1), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 1));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) == 0)
				{
				}
				else if (!tile.HasRoad)
				{
				}
				else
				{
					randomVillageTile = tile;
					break;
				}
			}
		}
		while (1);

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(3);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/noble_02.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.veteran_scenario_intro");
		}, null);
	}

	function onUpdateHiringRoster( _roster )
	{
		local garbage = [];
		local bros = _roster.getAll();

		foreach( i, bro in bros )
		{
			if (!bro.getBackground().isCombatBackground())
			{
				garbage.push(bro);
			}
		}

		foreach( g in garbage )
		{
			_roster.remove(g);
		}
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

});

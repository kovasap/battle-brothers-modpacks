this.maniac_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.maniac";
		this.m.Name = "Leader - The Maniac";
		this.m.Description = "[p=c][img]gfx/ui/events/event_122.png[/img][/p][p]They think you\'re crazy, mad. You should be. You\'re the sole survivor of your company. They all perished on that fateful day. They gave their lives and the ruins gave you a weapon in return. Now you wield it and cut away all that is false and evil as part of your unending revenge. You are the Maniac.\n\n[color=#bcad8c]Leader:[/color] Start with the Maniac, a named greatsword, low funds and some unexpected allies.\n[color=#bcad8c]Avatar:[/color] If the Maniac dies, the campaign ends.[/p]";
		this.m.Difficulty = 2;
		this.m.Order = 308;
	}

	function isValid()
	{
		return this.Const.DLC.Wildmen;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local names = [];

		for( local i = 0; i < 7; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.m.HireTime = this.Time.getVirtualTimeF();

			while (names.find(bro.getNameOnly()) != null)
			{
				bro.setName(this.Const.Strings.CharacterNames[this.Math.rand(0, this.Const.Strings.CharacterNames.len() - 1)]);
			}

			names.push(bro.getNameOnly());
		}

		local bros = roster.getAll();
		bros[0].setStartValuesEx([
			"beast_hunter_background"
		]);

		bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].setTitle("The Maniac");
		bros[0].getBackground().m.RawDescription = "Born with an actual brain, probably too smart for his own good. Traumatized by losing his mercenary brothers";
		bros[0].worsenMood(1.0, "Quite alone, still");
		bros[0].improveMood(0.5, "Not alone in his, so-called, craziness");
		bros[0].setPlaceInFormation(4);
		bros[0].getSkills().removeByID("trait.ailing");
		bros[0].getSkills().removeByID("trait.asthmatic");
		bros[0].getSkills().removeByID("trait.athletic");
		bros[0].getSkills().removeByID("trait.bleeder");
		bros[0].getSkills().removeByID("trait.bloodthirsty");
		bros[0].getSkills().removeByID("trait.brave");
		bros[0].getSkills().removeByID("trait.bright");
		bros[0].getSkills().removeByID("trait.brute");
		bros[0].getSkills().removeByID("trait.clubfooted");
		bros[0].getSkills().removeByID("trait.clumsy");
		bros[0].getSkills().removeByID("trait.cocky");
		bros[0].getSkills().removeByID("trait.craven");
		bros[0].getSkills().removeByID("trait.dastard");
		bros[0].getSkills().removeByID("trait.deathwish");
		bros[0].getSkills().removeByID("trait.determined");
		bros[0].getSkills().removeByID("trait.dexterous");
		bros[0].getSkills().removeByID("trait.disloyal");
		bros[0].getSkills().removeByID("trait.drunkard");
		bros[0].getSkills().removeByID("trait.dumb");
		bros[0].getSkills().removeByID("trait.eagle_eyes");
		bros[0].getSkills().removeByID("trait.fainthearted");
		bros[0].getSkills().removeByID("trait.fat");
		bros[0].getSkills().removeByID("trait.fear_beasts");
		bros[0].getSkills().removeByID("trait.fear_greenskins");
		bros[0].getSkills().removeByID("trait.fear_undead");
		bros[0].getSkills().removeByID("trait.fearless");
		bros[0].getSkills().removeByID("trait.fragile");
		bros[0].getSkills().removeByID("trait.gluttonous");
		bros[0].getSkills().removeByID("trait.greedy");
		bros[0].getSkills().removeByID("trait.hate_beasts");
		bros[0].getSkills().removeByID("trait.hate_greenskins");
		bros[0].getSkills().removeByID("trait.hate_undead");
		bros[0].getSkills().removeByID("trait.hesitant");
		bros[0].getSkills().removeByID("trait.huge");
		bros[0].getSkills().removeByID("trait.impatient");
		bros[0].getSkills().removeByID("trait.insecure");
		bros[0].getSkills().removeByID("trait.iron_jaw");
		bros[0].getSkills().removeByID("trait.iron_lungs");
		bros[0].getSkills().removeByID("trait.irrational");
		bros[0].getSkills().removeByID("trait.loyal");
		bros[0].getSkills().removeByID("trait.lucky");
		bros[0].getSkills().removeByID("trait.night_blind");
		bros[0].getSkills().removeByID("trait.night_owl");
		bros[0].getSkills().removeByID("trait.optimist");
		bros[0].getSkills().removeByID("trait.paranoid");
		bros[0].getSkills().removeByID("trait.pessimist");
		bros[0].getSkills().removeByID("trait.quick");
		bros[0].getSkills().removeByID("trait.short_sighted");
		bros[0].getSkills().removeByID("trait.spartan");
		bros[0].getSkills().removeByID("trait.strong");
		bros[0].getSkills().removeByID("trait.superstitious");
		bros[0].getSkills().removeByID("trait.sure_footing");
		bros[0].getSkills().removeByID("trait.survivor");
		bros[0].getSkills().removeByID("trait.swift");
		bros[0].getSkills().removeByID("trait.teamplayer");
		bros[0].getSkills().removeByID("trait.tiny");
		bros[0].getSkills().removeByID("trait.tough");
		bros[0].getSkills().removeByID("trait.weasel");
		bros[0].m.Skills.add(this.new("scripts/skills/traits/player_character_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/mad_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/iron_jaw_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/eagle_eyes_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/tough_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_mastery_sword"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_fortified_mind"));
		bros[0].m.Skills.add(this.new("scripts/skills/injury_permanent/missing_eye_injury"));
		bros[0].m.PerkPoints = 3;
		bros[0].m.LevelUps = 3;
		bros[0].m.Level = 4;
		bros[0].getBaseProperties().MeleeDefense -= 2;
		bros[0].m.Talents = [];
		local talents = bros[0].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 0;
		talents[this.Const.Attributes.MeleeSkill] = 3;
		talents[this.Const.Attributes.MeleeDefense] = 3;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 1;
   	local items = bros[0].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		local sword = this.new("scripts/items/weapons/named/named_greatsword");
		sword.m.Name = "Vengeance";
		items.equip(sword);
		items.equip(this.new("scripts/items/armor/werewolf_hide_armor"));
		items.equip(this.new("scripts/items/helmets/greatsword_hat"));
		bros[1].setStartValuesEx([
			"barbarian_background"
		]);
		bros[1].setPlaceInFormation(1);
		bros[1].getSkills().removeByID("trait.ailing");
		bros[1].getSkills().removeByID("trait.asthmatic");
		bros[1].getSkills().removeByID("trait.clubfooted");
		bros[1].getSkills().removeByID("trait.clumsy");
		bros[1].getSkills().removeByID("trait.craven");
		bros[1].getSkills().removeByID("trait.dastard");
		bros[1].getSkills().removeByID("trait.fat");
		bros[1].getSkills().removeByID("trait.fragile");
		bros[1].getSkills().removeByID("trait.gluttonous");
		bros[1].getSkills().removeByID("trait.hesitant");
		bros[1].getSkills().removeByID("trait.insecure");
		bros[1].m.PerkPoints = 2;
		bros[1].m.LevelUps = 2;
		bros[1].m.Level = 3;
		local items = bros[1].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/helmets/barbarians/leather_headband"));
		items.equip(this.new("scripts/items/armor/barbarians/animal_hide_armor"));
		items.equip(this.new("scripts/items/weapons/barbarians/antler_cleaver"));
		bros[2].setStartValuesEx([
			"barbarian_background"
		]);
		bros[2].setPlaceInFormation(2);
		bros[2].getSkills().removeByID("trait.ailing");
		bros[2].getSkills().removeByID("trait.asthmatic");
		bros[2].getSkills().removeByID("trait.clubfooted");
		bros[2].getSkills().removeByID("trait.clumsy");
		bros[2].getSkills().removeByID("trait.craven");
		bros[2].getSkills().removeByID("trait.dastard");
		bros[2].getSkills().removeByID("trait.fat");
		bros[2].getSkills().removeByID("trait.fragile");
		bros[2].getSkills().removeByID("trait.gluttonous");
		bros[2].getSkills().removeByID("trait.hesitant");
		bros[2].getSkills().removeByID("trait.insecure");
		bros[2].m.PerkPoints = 2;
		bros[2].m.LevelUps = 2;
		bros[2].m.Level = 3;
		local items = bros[2].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		local warhoundone = this.new("scripts/items/accessory/warhound_item");
		items.equip(warhoundone);
		items.equip(this.new("scripts/items/helmets/barbarians/bear_headpiece"));
		items.equip(this.new("scripts/items/armor/barbarians/animal_hide_armor"));
		items.equip(this.new("scripts/items/weapons/barbarians/antler_cleaver"));
		items.equip(this.new("scripts/items/shields/wooden_shield_old"));
		bros[3].setStartValuesEx([
			"barbarian_background"
		]);
		bros[3].setPlaceInFormation(6);
		bros[3].getSkills().removeByID("trait.ailing");
		bros[3].getSkills().removeByID("trait.asthmatic");
		bros[3].getSkills().removeByID("trait.clubfooted");
		bros[3].getSkills().removeByID("trait.clumsy");
		bros[3].getSkills().removeByID("trait.craven");
		bros[3].getSkills().removeByID("trait.dastard");
		bros[3].getSkills().removeByID("trait.fat");
		bros[3].getSkills().removeByID("trait.fragile");
		bros[3].getSkills().removeByID("trait.gluttonous");
		bros[3].getSkills().removeByID("trait.hesitant");
		bros[3].getSkills().removeByID("trait.insecure");
		bros[3].m.PerkPoints = 2;
		bros[3].m.LevelUps = 2;
		bros[3].m.Level = 3;
		local items = bros[3].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		local warhoundtwo = this.new("scripts/items/accessory/warhound_item");
		items.equip(warhoundtwo);
		items.equip(this.new("scripts/items/helmets/barbarians/leather_headband"));
		items.equip(this.new("scripts/items/armor/barbarians/animal_hide_armor"));
		items.equip(this.new("scripts/items/weapons/barbarians/claw_club"));
		bros[4].setStartValuesEx([
			"barbarian_background"
		]);
		bros[4].setPlaceInFormation(7);
		bros[4].getSkills().removeByID("trait.ailing");
		bros[4].getSkills().removeByID("trait.asthmatic");
		bros[4].getSkills().removeByID("trait.clubfooted");
		bros[4].getSkills().removeByID("trait.clumsy");
		bros[4].getSkills().removeByID("trait.craven");
		bros[4].getSkills().removeByID("trait.dastard");
		bros[4].getSkills().removeByID("trait.fat");
		bros[4].getSkills().removeByID("trait.fragile");
		bros[4].getSkills().removeByID("trait.gluttonous");
		bros[4].getSkills().removeByID("trait.hesitant");
		bros[4].getSkills().removeByID("trait.insecure");
		bros[4].m.PerkPoints = 2;
		bros[4].m.LevelUps = 2;
		bros[4].m.Level = 3;
		local items = bros[4].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/helmets/barbarians/leather_headband"));
		items.equip(this.new("scripts/items/armor/barbarians/animal_hide_armor"));
		items.equip(this.new("scripts/items/weapons/barbarians/antler_cleaver"));
		items.equip(this.new("scripts/items/shields/wooden_shield_old"));
		bros[5].setStartValuesEx([
			"barbarian_background"
		]);
		bros[5].setPlaceInFormation(8);
		bros[5].getSkills().removeByID("trait.ailing");
		bros[5].getSkills().removeByID("trait.asthmatic");
		bros[5].getSkills().removeByID("trait.clubfooted");
		bros[5].getSkills().removeByID("trait.clumsy");
		bros[5].getSkills().removeByID("trait.craven");
		bros[5].getSkills().removeByID("trait.dastard");
		bros[5].getSkills().removeByID("trait.fat");
		bros[5].getSkills().removeByID("trait.fragile");
		bros[5].getSkills().removeByID("trait.gluttonous");
		bros[5].getSkills().removeByID("trait.hesitant");
		bros[5].getSkills().removeByID("trait.insecure");
		bros[5].m.PerkPoints = 2;
		bros[5].m.LevelUps = 2;
		bros[5].m.Level = 3;
		local items = bros[5].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/weapons/barbarians/claw_club"));
		items.equip(this.new("scripts/items/shields/wooden_shield_old"));
		bros[6].setStartValuesEx([
			"barbarian_background"
		]);
		bros[6].setPlaceInFormation(0);
		bros[6].getSkills().removeByID("trait.ailing");
		bros[6].getSkills().removeByID("trait.asthmatic");
		bros[6].getSkills().removeByID("trait.clubfooted");
		bros[6].getSkills().removeByID("trait.clumsy");
		bros[6].getSkills().removeByID("trait.craven");
		bros[6].getSkills().removeByID("trait.dastard");
		bros[6].getSkills().removeByID("trait.fat");
		bros[6].getSkills().removeByID("trait.fragile");
		bros[6].getSkills().removeByID("trait.gluttonous");
		bros[6].getSkills().removeByID("trait.hesitant");
		bros[6].getSkills().removeByID("trait.insecure");
		bros[6].m.PerkPoints = 2;
		bros[6].m.LevelUps = 2;
		bros[6].m.Level = 3;
		local items = bros[6].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/helmets/barbarians/bear_headpiece"));
		items.equip(this.new("scripts/items/armor/barbarians/animal_hide_armor"));
		items.equip(this.new("scripts/items/weapons/barbarians/claw_club"));
		this.World.Assets.m.BusinessReputation = 50;
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/goat_cheese_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/bread_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/cured_venison_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/trade/furs_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/trade/furs_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/potion_of_knowledge_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/witch_hair_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/third_eye_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/petrified_scream_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/petrified_scream_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/petrified_scream_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/throwing_axe"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/throwing_axe"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/throwing_axe"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/throwing_spear"));
		this.World.Assets.m.Money = this.World.Assets.m.Money / 2 - (this.World.Assets.getEconomicDifficulty() == 0 ? 0 : 100);
		this.World.Assets.m.ArmorParts = 20;
		this.World.Assets.m.Medicine = 10;
		this.World.Assets.m.Ammo = 50;

	}

	function onSpawnPlayer()
	{
		local spawnTile;
		local settlements = this.World.EntityManager.getSettlements();
		local nearestVillage;
		local navSettings = this.World.getNavigator().createSettings();
		navSettings.ActionPointCosts = this.Const.World.TerrainTypeNavCost_Flat;

		do
		{
			local x = this.Math.rand(5, this.Const.World.Settings.SizeX - 5);
			local y = this.Math.rand(5, this.Const.World.Settings.SizeY - 5);

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.IsOccupied)
				{
				}
				else if (tile.Type != this.Const.World.TerrainType.Forest && tile.Type != this.Const.World.TerrainType.SnowyForest && tile.Type != this.Const.World.TerrainType.LeaveForest && tile.Type != this.Const.World.TerrainType.AutumnForest)
				{
				}
				else
				{
					local next = true;

					foreach( s in settlements )
					{
						local d = s.getTile().getDistanceTo(tile);

						if (d > 6 && d < 15)
						{
							local path = this.World.getNavigator().findPath(tile, s.getTile(), navSettings, 0);

							if (!path.isEmpty())
							{
								next = false;
								nearestVillage = s;
								break;
							}
						}
					}

					if (next)
					{
					}
					else
					{
						spawnTile = tile;
						break;
					}
				}
			}
		}
		while (1);

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", spawnTile.Coords.X, spawnTile.Coords.Y);
		this.World.Assets.updateLook(11);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		local f = nearestVillage.getFactionOfType(this.Const.FactionType.NobleHouse);
		f.addPlayerRelation(-20.0, "Fears barbarians");
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList(this.Const.Music.IntroTracks, this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.maniac_scenario_intro");
		}, null);
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

});

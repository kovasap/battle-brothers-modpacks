this.grandmaster_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.grandmaster";
		this.m.Name = "Leader - The Grandmaster";
		this.m.Description = "[p=c][img]gfx/ui/events/event_78.png[/img][/p][p]You were betrayed and attacked. The nobles you assisted in the battles against the city states conspired to destroy the Order. You barely managed to escape with the last of your brothers. You are a fugitive. You are the Grandmaster.\n\n[color=#bcad8c]Leader:[/color] Start with the Grandmaster, a named sword, and six brothers of the Order.\n[color=#bcad8c]Careful Who You Trust:[/color] Max 12 brothers in your roster. Daily wages reduced by 10%.\n[color=#bcad8c]Hated by Most:[/color] Start with bad relations with all human factions, apart from a single friendly village.\n[color=#bcad8c]Avatar:[/color] If the Grandmaster dies, the campaign ends.[/p]";
		this.m.Difficulty = 3;
		this.m.Order = 306;
	}

	function isValid()
	{
		return this.Const.DLC.Desert;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local names = [];

		for( local i = 0; i < 7; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.worsenMood(1.0, "Lost many brothers to betrayal and death");
			bro.improveMood(0.5, "Saved by friendly villagers");
			bro.m.HireTime = this.Time.getVirtualTimeF();

			while (names.find(bro.getNameOnly()) != null)
			{
				bro.setName(this.Const.Strings.CharacterNames[this.Math.rand(0, this.Const.Strings.CharacterNames.len() - 1)]);
			}

			names.push(bro.getNameOnly());
		}

		local bros = roster.getAll();
		bros[0].setStartValuesEx([
			"order_knight_background"
		]);
		bros[0].setName("Molay");
		bros[0].setTitle("Grandmaster");
		bros[0].getBackground().m.RawDescription = "Grandmaster of the Order for a very long time. Does not dwell on the past. Sometimes does.";
		bros[0].setPlaceInFormation(4);
		bros[0].improveMood(0.5, "Found a cache of supplies");
		bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].getSkills().removeByID("trait.ailing");
		bros[0].getSkills().removeByID("trait.asthmatic");
		bros[0].getSkills().removeByID("trait.athletic");
		bros[0].getSkills().removeByID("trait.bleeder");
		bros[0].getSkills().removeByID("trait.bloodthirsty");
		bros[0].getSkills().removeByID("trait.brave");
		bros[0].getSkills().removeByID("trait.bright");
		bros[0].getSkills().removeByID("trait.brute");
		bros[0].getSkills().removeByID("trait.clubfooted");
		bros[0].getSkills().removeByID("trait.clumsy");
		bros[0].getSkills().removeByID("trait.cocky");
		bros[0].getSkills().removeByID("trait.craven");
		bros[0].getSkills().removeByID("trait.dastard");
		bros[0].getSkills().removeByID("trait.deathwish");
		bros[0].getSkills().removeByID("trait.determined");
		bros[0].getSkills().removeByID("trait.dexterous");
		bros[0].getSkills().removeByID("trait.disloyal");
		bros[0].getSkills().removeByID("trait.drunkard");
		bros[0].getSkills().removeByID("trait.dumb");
		bros[0].getSkills().removeByID("trait.eagle_eyes");
		bros[0].getSkills().removeByID("trait.fainthearted");
		bros[0].getSkills().removeByID("trait.fat");
		bros[0].getSkills().removeByID("trait.fear_beasts");
		bros[0].getSkills().removeByID("trait.fear_greenskins");
		bros[0].getSkills().removeByID("trait.fear_undead");
		bros[0].getSkills().removeByID("trait.fearless");
		bros[0].getSkills().removeByID("trait.fragile");
		bros[0].getSkills().removeByID("trait.gluttonous");
		bros[0].getSkills().removeByID("trait.greedy");
		bros[0].getSkills().removeByID("trait.hate_beasts");
		bros[0].getSkills().removeByID("trait.hate_greenskins");
		bros[0].getSkills().removeByID("trait.hate_undead");
		bros[0].getSkills().removeByID("trait.hesitant");
		bros[0].getSkills().removeByID("trait.huge");
		bros[0].getSkills().removeByID("trait.impatient");
		bros[0].getSkills().removeByID("trait.insecure");
		bros[0].getSkills().removeByID("trait.iron_jaw");
		bros[0].getSkills().removeByID("trait.iron_lungs");
		bros[0].getSkills().removeByID("trait.irrational");
		bros[0].getSkills().removeByID("trait.loyal");
		bros[0].getSkills().removeByID("trait.lucky");
		bros[0].getSkills().removeByID("trait.night_blind");
		bros[0].getSkills().removeByID("trait.night_owl");
		bros[0].getSkills().removeByID("trait.optimist");
		bros[0].getSkills().removeByID("trait.paranoid");
		bros[0].getSkills().removeByID("trait.pessimist");
		bros[0].getSkills().removeByID("trait.quick");
		bros[0].getSkills().removeByID("trait.short_sighted");
		bros[0].getSkills().removeByID("trait.spartan");
		bros[0].getSkills().removeByID("trait.strong");
		bros[0].getSkills().removeByID("trait.superstitious");
		bros[0].getSkills().removeByID("trait.sure_footing");
		bros[0].getSkills().removeByID("trait.survivor");
		bros[0].getSkills().removeByID("trait.swift");
		bros[0].getSkills().removeByID("trait.teamplayer");
		bros[0].getSkills().removeByID("trait.tiny");
		bros[0].getSkills().removeByID("trait.tough");
		bros[0].getSkills().removeByID("trait.weasel");
		bros[0].m.Skills.add(this.new("scripts/skills/traits/player_character_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/spartan_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/bright_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/sure_footing_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_mastery_sword"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_fortified_mind"));
		bros[0].m.PerkPoints = 3;
		bros[0].m.LevelUps = 3;
		bros[0].m.Level = 4;
		bros[0].getBaseProperties().MeleeDefense -= 2;
		bros[0].m.Talents = [];
		local talents = bros[0].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 2;
		talents[this.Const.Attributes.Initiative] = 1;
		talents[this.Const.Attributes.MeleeSkill] = 3;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 1;
		local items = bros[0].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		local sword = this.new("scripts/items/weapons/named/named_sword");
		sword.m.Name = "Fidelio";
		items.equip(sword);
		local armor = this.new("scripts/items/armor/scale_armor");
		armor.setUpgrade(this.new("scripts/items/armor_upgrades/unhold_fur_upgrade"));
		bros[0].getItems().equip(armor);
		items.equip(this.new("scripts/items/helmets/full_helm"));
		bros[1].setStartValuesEx([
			"order_knight_background"
		]);
		bros[1].setName("Beltran");
		bros[1].setTitle("Marshal");
		bros[1].getBackground().m.RawDescription = "A veteran in the Order. Helped his friend and brother, the Grandmaster, escape. Second in command.";
		bros[1].setPlaceInFormation(5);
		bros[1].getSkills().removeByID("trait.ailing");
		bros[1].getSkills().removeByID("trait.asthmatic");
		bros[1].getSkills().removeByID("trait.athletic");
		bros[1].getSkills().removeByID("trait.bleeder");
		bros[1].getSkills().removeByID("trait.bloodthirsty");
		bros[1].getSkills().removeByID("trait.brave");
		bros[1].getSkills().removeByID("trait.bright");
		bros[1].getSkills().removeByID("trait.brute");
		bros[1].getSkills().removeByID("trait.clubfooted");
		bros[1].getSkills().removeByID("trait.clumsy");
		bros[1].getSkills().removeByID("trait.cocky");
		bros[1].getSkills().removeByID("trait.craven");
		bros[1].getSkills().removeByID("trait.dastard");
		bros[1].getSkills().removeByID("trait.deathwish");
		bros[1].getSkills().removeByID("trait.determined");
		bros[1].getSkills().removeByID("trait.dexterous");
		bros[1].getSkills().removeByID("trait.disloyal");
		bros[1].getSkills().removeByID("trait.drunkard");
		bros[1].getSkills().removeByID("trait.dumb");
		bros[1].getSkills().removeByID("trait.eagle_eyes");
		bros[1].getSkills().removeByID("trait.fainthearted");
		bros[1].getSkills().removeByID("trait.fat");
		bros[1].getSkills().removeByID("trait.fear_beasts");
		bros[1].getSkills().removeByID("trait.fear_greenskins");
		bros[1].getSkills().removeByID("trait.fear_undead");
		bros[1].getSkills().removeByID("trait.fearless");
		bros[1].getSkills().removeByID("trait.fragile");
		bros[1].getSkills().removeByID("trait.gluttonous");
		bros[1].getSkills().removeByID("trait.greedy");
		bros[1].getSkills().removeByID("trait.hate_beasts");
		bros[1].getSkills().removeByID("trait.hate_greenskins");
		bros[1].getSkills().removeByID("trait.hate_undead");
		bros[1].getSkills().removeByID("trait.hesitant");
		bros[1].getSkills().removeByID("trait.huge");
		bros[1].getSkills().removeByID("trait.impatient");
		bros[1].getSkills().removeByID("trait.insecure");
		bros[1].getSkills().removeByID("trait.iron_jaw");
		bros[1].getSkills().removeByID("trait.iron_lungs");
		bros[1].getSkills().removeByID("trait.irrational");
		bros[1].getSkills().removeByID("trait.loyal");
		bros[1].getSkills().removeByID("trait.lucky");
		bros[1].getSkills().removeByID("trait.night_blind");
		bros[1].getSkills().removeByID("trait.night_owl");
		bros[1].getSkills().removeByID("trait.optimist");
		bros[1].getSkills().removeByID("trait.paranoid");
		bros[1].getSkills().removeByID("trait.pessimist");
		bros[1].getSkills().removeByID("trait.quick");
		bros[1].getSkills().removeByID("trait.short_sighted");
		bros[1].getSkills().removeByID("trait.spartan");
		bros[1].getSkills().removeByID("trait.strong");
		bros[1].getSkills().removeByID("trait.superstitious");
		bros[1].getSkills().removeByID("trait.sure_footing");
		bros[1].getSkills().removeByID("trait.survivor");
		bros[1].getSkills().removeByID("trait.swift");
		bros[1].getSkills().removeByID("trait.teamplayer");
		bros[1].getSkills().removeByID("trait.tiny");
		bros[1].getSkills().removeByID("trait.tough");
		bros[1].getSkills().removeByID("trait.weasel");
		bros[1].m.Skills.add(this.new("scripts/skills/traits/spartan_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/traits/loyal_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/traits/determined_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/perks/perk_mastery_sword"));
		bros[1].m.Talents = [];
		local talents = bros[1].getTalents();
		bros[1].m.PerkPoints = 3;
		bros[1].m.LevelUps = 3;
		bros[1].m.Level = 4;
		bros[1].m.Talents = [];
		local talents = bros[1].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 1;
		talents[this.Const.Attributes.MeleeSkill] = 2;
		talents[this.Const.Attributes.MeleeDefense] = 3;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		local items = bros[1].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/weapons/noble_sword"));
		items.equip(this.new("scripts/items/armor/mail_hauberk"));
		items.equip(this.new("scripts/items/helmets/flat_top_with_mail"));
		items.equip(this.new("scripts/items/shields/faction_heater_shield"));
		bros[2].setStartValuesEx([
			"order_knight_background"
		]);
		bros[2].setName("Godfrey");
		bros[2].setTitle("Seneschal");
		bros[2].getBackground().m.RawDescription = "Godfrey grew up in the Order. Will never betray his brothers. Will defend them to the death, and beyond.";
		bros[2].setPlaceInFormation(3);
		bros[2].improveMood(0.5, "Responsible for the placing of the cache of supplies which proves very useful");
		bros[2].getSkills().removeByID("trait.ailing");
		bros[2].getSkills().removeByID("trait.asthmatic");
		bros[2].getSkills().removeByID("trait.athletic");
		bros[2].getSkills().removeByID("trait.bleeder");
		bros[2].getSkills().removeByID("trait.bloodthirsty");
		bros[2].getSkills().removeByID("trait.brave");
		bros[2].getSkills().removeByID("trait.bright");
		bros[2].getSkills().removeByID("trait.brute");
		bros[2].getSkills().removeByID("trait.clubfooted");
		bros[2].getSkills().removeByID("trait.clumsy");
		bros[2].getSkills().removeByID("trait.cocky");
		bros[2].getSkills().removeByID("trait.craven");
		bros[2].getSkills().removeByID("trait.dastard");
		bros[2].getSkills().removeByID("trait.deathwish");
		bros[2].getSkills().removeByID("trait.determined");
		bros[2].getSkills().removeByID("trait.dexterous");
		bros[2].getSkills().removeByID("trait.disloyal");
		bros[2].getSkills().removeByID("trait.drunkard");
		bros[2].getSkills().removeByID("trait.dumb");
		bros[2].getSkills().removeByID("trait.eagle_eyes");
		bros[2].getSkills().removeByID("trait.fainthearted");
		bros[2].getSkills().removeByID("trait.fat");
		bros[2].getSkills().removeByID("trait.fear_beasts");
		bros[2].getSkills().removeByID("trait.fear_greenskins");
		bros[2].getSkills().removeByID("trait.fear_undead");
		bros[2].getSkills().removeByID("trait.fearless");
		bros[2].getSkills().removeByID("trait.fragile");
		bros[2].getSkills().removeByID("trait.gluttonous");
		bros[2].getSkills().removeByID("trait.greedy");
		bros[2].getSkills().removeByID("trait.hate_beasts");
		bros[2].getSkills().removeByID("trait.hate_greenskins");
		bros[2].getSkills().removeByID("trait.hate_undead");
		bros[2].getSkills().removeByID("trait.hesitant");
		bros[2].getSkills().removeByID("trait.huge");
		bros[2].getSkills().removeByID("trait.impatient");
		bros[2].getSkills().removeByID("trait.insecure");
		bros[2].getSkills().removeByID("trait.iron_jaw");
		bros[2].getSkills().removeByID("trait.iron_lungs");
		bros[2].getSkills().removeByID("trait.irrational");
		bros[2].getSkills().removeByID("trait.loyal");
		bros[2].getSkills().removeByID("trait.lucky");
		bros[2].getSkills().removeByID("trait.night_blind");
		bros[2].getSkills().removeByID("trait.night_owl");
		bros[2].getSkills().removeByID("trait.optimist");
		bros[2].getSkills().removeByID("trait.paranoid");
		bros[2].getSkills().removeByID("trait.pessimist");
		bros[2].getSkills().removeByID("trait.quick");
		bros[2].getSkills().removeByID("trait.short_sighted");
		bros[2].getSkills().removeByID("trait.spartan");
		bros[2].getSkills().removeByID("trait.strong");
		bros[2].getSkills().removeByID("trait.superstitious");
		bros[2].getSkills().removeByID("trait.sure_footing");
		bros[2].getSkills().removeByID("trait.survivor");
		bros[2].getSkills().removeByID("trait.swift");
		bros[2].getSkills().removeByID("trait.teamplayer");
		bros[2].getSkills().removeByID("trait.tiny");
		bros[2].getSkills().removeByID("trait.tough");
		bros[2].getSkills().removeByID("trait.weasel");
		bros[2].m.Skills.add(this.new("scripts/skills/traits/loyal_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/traits/spartan_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/traits/teamplayer_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/perks/perk_rotation"));
		bros[2].m.Skills.add(this.new("scripts/skills/injury/injured_shoulder_injury"));
		bros[2].m.PerkPoints = 3;
		bros[2].m.LevelUps = 3;
		bros[2].m.Level = 4;
		bros[2].m.Talents = [];
		local talents = bros[2].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 2;
		talents[this.Const.Attributes.Initiative] = 1;
		talents[this.Const.Attributes.MeleeSkill] = 1;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		local items = bros[2].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/weapons/winged_mace"));
		items.equip(this.new("scripts/items/armor/mail_hauberk"));
		items.equip(this.new("scripts/items/helmets/flat_top_with_mail"));
		items.equip(this.new("scripts/items/shields/faction_heater_shield"));
		bros[3].setStartValuesEx([
			"order_knight_background"
		]);
		bros[3].setTitle("Sergeant");
		bros[3].getBackground().m.RawDescription = "Veteran in the Order. Sometimes dreams about charging the enemy without a shield.";
		bros[3].setPlaceInFormation(6);
		bros[3].getSkills().removeByID("trait.ailing");
		bros[3].getSkills().removeByID("trait.asthmatic");
		bros[3].getSkills().removeByID("trait.athletic");
		bros[3].getSkills().removeByID("trait.bleeder");
		bros[3].getSkills().removeByID("trait.bloodthirsty");
		bros[3].getSkills().removeByID("trait.brave");
		bros[3].getSkills().removeByID("trait.bright");
		bros[3].getSkills().removeByID("trait.brute");
		bros[3].getSkills().removeByID("trait.clubfooted");
		bros[3].getSkills().removeByID("trait.clumsy");
		bros[3].getSkills().removeByID("trait.cocky");
		bros[3].getSkills().removeByID("trait.craven");
		bros[3].getSkills().removeByID("trait.dastard");
		bros[3].getSkills().removeByID("trait.deathwish");
		bros[3].getSkills().removeByID("trait.determined");
		bros[3].getSkills().removeByID("trait.dexterous");
		bros[3].getSkills().removeByID("trait.disloyal");
		bros[3].getSkills().removeByID("trait.drunkard");
		bros[3].getSkills().removeByID("trait.dumb");
		bros[3].getSkills().removeByID("trait.eagle_eyes");
		bros[3].getSkills().removeByID("trait.fainthearted");
		bros[3].getSkills().removeByID("trait.fat");
		bros[3].getSkills().removeByID("trait.fear_beasts");
		bros[3].getSkills().removeByID("trait.fear_greenskins");
		bros[3].getSkills().removeByID("trait.fear_undead");
		bros[3].getSkills().removeByID("trait.fearless");
		bros[3].getSkills().removeByID("trait.fragile");
		bros[3].getSkills().removeByID("trait.gluttonous");
		bros[3].getSkills().removeByID("trait.greedy");
		bros[3].getSkills().removeByID("trait.hate_beasts");
		bros[3].getSkills().removeByID("trait.hate_greenskins");
		bros[3].getSkills().removeByID("trait.hate_undead");
		bros[3].getSkills().removeByID("trait.hesitant");
		bros[3].getSkills().removeByID("trait.huge");
		bros[3].getSkills().removeByID("trait.impatient");
		bros[3].getSkills().removeByID("trait.insecure");
		bros[3].getSkills().removeByID("trait.iron_jaw");
		bros[3].getSkills().removeByID("trait.iron_lungs");
		bros[3].getSkills().removeByID("trait.irrational");
		bros[3].getSkills().removeByID("trait.loyal");
		bros[3].getSkills().removeByID("trait.lucky");
		bros[3].getSkills().removeByID("trait.night_blind");
		bros[3].getSkills().removeByID("trait.night_owl");
		bros[3].getSkills().removeByID("trait.optimist");
		bros[3].getSkills().removeByID("trait.paranoid");
		bros[3].getSkills().removeByID("trait.pessimist");
		bros[3].getSkills().removeByID("trait.quick");
		bros[3].getSkills().removeByID("trait.short_sighted");
		bros[3].getSkills().removeByID("trait.spartan");
		bros[3].getSkills().removeByID("trait.strong");
		bros[3].getSkills().removeByID("trait.superstitious");
		bros[3].getSkills().removeByID("trait.sure_footing");
		bros[3].getSkills().removeByID("trait.survivor");
		bros[3].getSkills().removeByID("trait.swift");
		bros[3].getSkills().removeByID("trait.teamplayer");
		bros[3].getSkills().removeByID("trait.tiny");
		bros[3].getSkills().removeByID("trait.tough");
		bros[3].getSkills().removeByID("trait.weasel");
		bros[3].m.Skills.add(this.new("scripts/skills/traits/loyal_trait"));
		bros[3].m.Skills.add(this.new("scripts/skills/traits/spartan_trait"));
		bros[3].m.Skills.add(this.new("scripts/skills/traits/survivor_trait"));
		bros[3].m.Skills.add(this.new("scripts/skills/perks/perk_steel_brow"));
		bros[3].m.PerkPoints = 2;
		bros[3].m.LevelUps = 2;
		bros[3].m.Level = 3;
		bros[3].m.Talents = [];
		local talents = bros[3].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 1;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 2;
		talents[this.Const.Attributes.Initiative] = 1;
		talents[this.Const.Attributes.MeleeSkill] = 1;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		local items = bros[3].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/weapons/winged_mace"));
		items.equip(this.new("scripts/items/helmets/padded_nasal_helmet"));
		items.equip(this.new("scripts/items/armor/mail_hauberk"));
		items.equip(this.new("scripts/items/shields/faction_heater_shield"));
		bros[4].setStartValuesEx([
			"squire_background"
		]);
		bros[4].setTitle("Squire");
		bros[4].getBackground().m.RawDescription = "Just joined the Order. Timing was a bit off. Eager to learn.";
		bros[4].setPlaceInFormation(2);
		bros[4].getSkills().removeByID("trait.clubfooted");
		bros[4].getSkills().removeByID("trait.clumsy");
		bros[4].getSkills().removeByID("trait.cocky");
		bros[4].getSkills().removeByID("trait.craven");
		bros[4].getSkills().removeByID("trait.dastard");
		bros[4].getSkills().removeByID("trait.disloyal");
		bros[4].getSkills().removeByID("trait.drunkard");
		bros[4].getSkills().removeByID("trait.dumb");
		bros[4].getSkills().removeByID("trait.fat");
		bros[4].getSkills().removeByID("trait.fragile");
		bros[4].getSkills().removeByID("trait.gluttonous");
		bros[4].getSkills().removeByID("trait.greedy");
		bros[4].getSkills().removeByID("trait.hate_beasts");
		bros[4].getSkills().removeByID("trait.hate_greenskins");
		bros[4].getSkills().removeByID("trait.hate_undead");
		bros[4].getSkills().removeByID("trait.loyal");
		bros[4].getSkills().removeByID("trait.spartan");
		bros[4].getSkills().removeByID("trait.superstitious");
		bros[4].m.Skills.add(this.new("scripts/skills/traits/spartan_trait"));
		local items = bros[4].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/weapons/arming_sword"));
		items.equip(this.new("scripts/items/armor/basic_mail_shirt"));
		items.equip(this.new("scripts/items/helmets/mail_coif"));
		items.equip(this.new("scripts/items/shields/faction_kite_shield"));
		bros[5].setStartValuesEx([
			"squire_background"
		]);
		bros[5].setTitle("Squire");
		bros[5].getBackground().m.RawDescription = "Just joined the Order. Timing was a bit off. Eager to learn.";
		bros[5].setPlaceInFormation(7);
		bros[5].getSkills().removeByID("trait.clubfooted");
		bros[5].getSkills().removeByID("trait.clumsy");
		bros[5].getSkills().removeByID("trait.cocky");
		bros[5].getSkills().removeByID("trait.craven");
		bros[5].getSkills().removeByID("trait.dastard");
		bros[5].getSkills().removeByID("trait.disloyal");
		bros[5].getSkills().removeByID("trait.drunkard");
		bros[5].getSkills().removeByID("trait.dumb");
		bros[5].getSkills().removeByID("trait.fat");
		bros[5].getSkills().removeByID("trait.fragile");
		bros[5].getSkills().removeByID("trait.gluttonous");
		bros[5].getSkills().removeByID("trait.greedy");
		bros[5].getSkills().removeByID("trait.hate_beasts");
		bros[5].getSkills().removeByID("trait.hate_greenskins");
		bros[5].getSkills().removeByID("trait.hate_undead");
		bros[5].getSkills().removeByID("trait.loyal");
		bros[5].getSkills().removeByID("trait.spartan");
		bros[5].getSkills().removeByID("trait.superstitious");
		bros[5].m.Skills.add(this.new("scripts/skills/traits/spartan_trait"));
		bros[5].m.Skills.add(this.new("scripts/skills/injury/bruised_leg_injury"));
		local items = bros[5].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/weapons/arming_sword"));
		items.equip(this.new("scripts/items/armor/basic_mail_shirt"));
		items.equip(this.new("scripts/items/helmets/mail_coif"));
		items.equip(this.new("scripts/items/shields/faction_kite_shield"));
		bros[6].setStartValuesEx([
			"order_knight_background"
		]);
		bros[6].setTitle("Standard Bearer");
		bros[6].getBackground().m.RawDescription = "Veteran in the Order. Will defend the standard of the Order to the death.";
		bros[6].setPlaceInFormation(13);
		bros[6].getSkills().removeByID("trait.ailing");
		bros[6].getSkills().removeByID("trait.asthmatic");
		bros[6].getSkills().removeByID("trait.athletic");
		bros[6].getSkills().removeByID("trait.bleeder");
		bros[6].getSkills().removeByID("trait.bloodthirsty");
		bros[6].getSkills().removeByID("trait.brave");
		bros[6].getSkills().removeByID("trait.bright");
		bros[6].getSkills().removeByID("trait.brute");
		bros[6].getSkills().removeByID("trait.clubfooted");
		bros[6].getSkills().removeByID("trait.clumsy");
		bros[6].getSkills().removeByID("trait.cocky");
		bros[6].getSkills().removeByID("trait.craven");
		bros[6].getSkills().removeByID("trait.dastard");
		bros[6].getSkills().removeByID("trait.deathwish");
		bros[6].getSkills().removeByID("trait.determined");
		bros[6].getSkills().removeByID("trait.dexterous");
		bros[6].getSkills().removeByID("trait.disloyal");
		bros[6].getSkills().removeByID("trait.drunkard");
		bros[6].getSkills().removeByID("trait.dumb");
		bros[6].getSkills().removeByID("trait.eagle_eyes");
		bros[6].getSkills().removeByID("trait.fainthearted");
		bros[6].getSkills().removeByID("trait.fat");
		bros[6].getSkills().removeByID("trait.fear_beasts");
		bros[6].getSkills().removeByID("trait.fear_greenskins");
		bros[6].getSkills().removeByID("trait.fear_undead");
		bros[6].getSkills().removeByID("trait.fearless");
		bros[6].getSkills().removeByID("trait.fragile");
		bros[6].getSkills().removeByID("trait.gluttonous");
		bros[6].getSkills().removeByID("trait.greedy");
		bros[6].getSkills().removeByID("trait.hate_beasts");
		bros[6].getSkills().removeByID("trait.hate_greenskins");
		bros[6].getSkills().removeByID("trait.hate_undead");
		bros[6].getSkills().removeByID("trait.hesitant");
		bros[6].getSkills().removeByID("trait.huge");
		bros[6].getSkills().removeByID("trait.impatient");
		bros[6].getSkills().removeByID("trait.insecure");
		bros[6].getSkills().removeByID("trait.iron_jaw");
		bros[6].getSkills().removeByID("trait.iron_lungs");
		bros[6].getSkills().removeByID("trait.irrational");
		bros[6].getSkills().removeByID("trait.loyal");
		bros[6].getSkills().removeByID("trait.lucky");
		bros[6].getSkills().removeByID("trait.night_blind");
		bros[6].getSkills().removeByID("trait.night_owl");
		bros[6].getSkills().removeByID("trait.optimist");
		bros[6].getSkills().removeByID("trait.paranoid");
		bros[6].getSkills().removeByID("trait.pessimist");
		bros[6].getSkills().removeByID("trait.quick");
		bros[6].getSkills().removeByID("trait.short_sighted");
		bros[6].getSkills().removeByID("trait.spartan");
		bros[6].getSkills().removeByID("trait.strong");
		bros[6].getSkills().removeByID("trait.superstitious");
		bros[6].getSkills().removeByID("trait.sure_footing");
		bros[6].getSkills().removeByID("trait.survivor");
		bros[6].getSkills().removeByID("trait.swift");
		bros[6].getSkills().removeByID("trait.teamplayer");
		bros[6].getSkills().removeByID("trait.tiny");
		bros[6].getSkills().removeByID("trait.tough");
		bros[6].getSkills().removeByID("trait.weasel");
		bros[6].m.Skills.add(this.new("scripts/skills/traits/spartan_trait"));
		bros[6].m.Skills.add(this.new("scripts/skills/traits/swift_trait"));
		bros[6].m.Skills.add(this.new("scripts/skills/perks/perk_fortified_mind"));
		bros[6].m.PerkPoints = 3;
		bros[6].m.LevelUps = 3;
		bros[6].m.Level = 4;
		bros[6].m.Talents = [];
		local talents = bros[6].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 3;
		talents[this.Const.Attributes.Initiative] = 0;
		talents[this.Const.Attributes.MeleeSkill] = 2;
		talents[this.Const.Attributes.MeleeDefense] = 1;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 1;
		local items = bros[6].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/weapons/pike"));
		items.equip(this.new("scripts/items/armor/basic_mail_shirt"));
		items.equip(this.new("scripts/items/helmets/mail_coif"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/ground_grains_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/ground_grains_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/ground_grains_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/cured_rations_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/cured_rations_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/cured_rations_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/bandage_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/bandage_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/bandage_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/miracle_drug_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/miracle_drug_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/loot/golden_chalice_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/loot/ornate_tome_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_set_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_set_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_set_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_set_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_set_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_set_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_set_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_remover_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_remover_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/paint_remover_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/holy_water_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/holy_water_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/holy_water_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/dagger"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/dagger"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/dagger"));
		this.World.Assets.getStash().add(this.new("scripts/items/shields/faction_kite_shield"));
		this.World.Assets.getStash().add(this.new("scripts/items/armor_upgrades/metal_plating_upgrade"));
		this.World.Assets.m.BusinessReputation = 50;
		this.World.Assets.m.ArmorParts = this.World.Assets.m.ArmorParts * 3;
		this.World.Assets.m.Medicine = this.World.Assets.m.Medicine * 3;

	}

	function onSpawnPlayer()
	{
		local randomVillage;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
		{
			randomVillage = this.World.EntityManager.getSettlements()[i];

			if (!randomVillage.isMilitary() && !randomVillage.isIsolatedFromRoads() && randomVillage.getSize() == 1)
			{
				break;
			}
		}

		local randomVillageTile = randomVillage.getTile();
		this.World.Flags.set("HomeVillage", randomVillage.getName());
		local navSettings = this.World.getNavigator().createSettings();
		navSettings.ActionPointCosts = this.Const.World.TerrainTypeNavCost_Flat;

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 4), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 4));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 4), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 4));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) <= 1)
				{
				}
				else if (tile.Type != this.Const.World.TerrainType.Plains && tile.Type != this.Const.World.TerrainType.Steppe && tile.Type != this.Const.World.TerrainType.Tundra && tile.Type != this.Const.World.TerrainType.Snow)
				{
				}
				else
				{
					local path = this.World.getNavigator().findPath(tile, randomVillageTile, navSettings, 0);

					if (!path.isEmpty())
					{
						randomVillageTile = tile;
						break;
					}
				}
			}
		}
		while (1);

		local nobleHouses = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.NobleHouse);
		for( local i = 0; i < 3; i = ++i )
		{
			nobleHouses[i].addPlayerRelation(-75.0, "You are considered enemies.");
		}

		local cityStates = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.OrientalCityState);
		for( local i = 0; i < 3; i = ++i )
		{
			cityStates[i].addPlayerRelation(-35.0, "You are considered old enemies. Maybe they will tolerate you in the near future, if you do not provoke them.");
		}

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(6);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		randomVillage.getFactionOfType(this.Const.FactionType.Settlement).addPlayerRelation(80.0, "This village is friendly to members the Order.");
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/worldmap_08.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.grandmaster_scenario_intro");
		}, null);
	}

	function onInit()
	{
		this.World.Assets.m.BrothersMax = 12;
		this.World.Assets.m.DailyWageMult *= 0.90;
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

});

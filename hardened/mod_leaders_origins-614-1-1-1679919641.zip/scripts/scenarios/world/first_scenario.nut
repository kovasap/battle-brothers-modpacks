this.first_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.first";
		this.m.Name = "Leader - The First";
		this.m.Description = "[p=c][img]gfx/ui/events/event_33.png[/img][/p][p]The nightly visions convinced you of it: you\'re the first of nine great warriors that will come together to fight evil in all it\'s forms. You left your old company, the legendary \'Terrifying Twelve.\' They think you\'re mad. You might be. You sure are lucky and might just have found the Second and the Third. You are the First.\n\n[color=#bcad8c]Leader:[/color] Start with the First and two companions.\n[color=#bcad8c]Few But Fast:[/color] Faster travel on the worldmap.\n[color=#bcad8c]A Real Challenge:[/color] Max. 9 men in your roster.\n[color=#bcad8c]Avatar:[/color] Campaign ends if the First dies.[/p]";
		this.m.Difficulty = 3;
		this.m.Order = 304;
	}

	function isValid()
	{
		return this.Const.DLC.Desert;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local names = [];

		for( local i = 0; i < 3; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.m.HireTime = this.Time.getVirtualTimeF();
		}

		local bros = roster.getAll();
		bros[0].setStartValuesEx([
			"hedge_knight_background"
		]);
		bros[0].getBackground().m.RawDescription = "You had a vision. Nine. Nine. Nine. Maybe you are crazy. Maybe not. You know, somehow, nine will be enough, more than enough.";
		bros[0].setTitle("The First");
		bros[0].setPlaceInFormation(0);
		bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].worsenMood(0.5, "Still six to go");
		bros[0].improveMood(1.5, "Found two out of nine");
		bros[0].getSkills().removeByID("trait.ailing");
		bros[0].getSkills().removeByID("trait.asthmatic");
		bros[0].getSkills().removeByID("trait.athletic");
		bros[0].getSkills().removeByID("trait.bleeder");
		bros[0].getSkills().removeByID("trait.bloodthirsty");
		bros[0].getSkills().removeByID("trait.brave");
		bros[0].getSkills().removeByID("trait.bright");
		bros[0].getSkills().removeByID("trait.brute");
		bros[0].getSkills().removeByID("trait.clubfooted");
		bros[0].getSkills().removeByID("trait.clumsy");
		bros[0].getSkills().removeByID("trait.cocky");
		bros[0].getSkills().removeByID("trait.craven");
		bros[0].getSkills().removeByID("trait.dastard");
		bros[0].getSkills().removeByID("trait.deathwish");
		bros[0].getSkills().removeByID("trait.determined");
		bros[0].getSkills().removeByID("trait.dexterous");
		bros[0].getSkills().removeByID("trait.disloyal");
		bros[0].getSkills().removeByID("trait.drunkard");
		bros[0].getSkills().removeByID("trait.dumb");
		bros[0].getSkills().removeByID("trait.eagle_eyes");
		bros[0].getSkills().removeByID("trait.fainthearted");
		bros[0].getSkills().removeByID("trait.fat");
		bros[0].getSkills().removeByID("trait.fear_beasts");
		bros[0].getSkills().removeByID("trait.fear_greenskins");
		bros[0].getSkills().removeByID("trait.fear_undead");
		bros[0].getSkills().removeByID("trait.fearless");
		bros[0].getSkills().removeByID("trait.fragile");
		bros[0].getSkills().removeByID("trait.gluttonous");
		bros[0].getSkills().removeByID("trait.greedy");
		bros[0].getSkills().removeByID("trait.hate_beasts");
		bros[0].getSkills().removeByID("trait.hate_greenskins");
		bros[0].getSkills().removeByID("trait.hate_undead");
		bros[0].getSkills().removeByID("trait.hesitant");
		bros[0].getSkills().removeByID("trait.huge");
		bros[0].getSkills().removeByID("trait.impatient");
		bros[0].getSkills().removeByID("trait.insecure");
		bros[0].getSkills().removeByID("trait.iron_jaw");
		bros[0].getSkills().removeByID("trait.iron_lungs");
		bros[0].getSkills().removeByID("trait.irrational");
		bros[0].getSkills().removeByID("trait.loyal");
		bros[0].getSkills().removeByID("trait.lucky");
		bros[0].getSkills().removeByID("trait.night_blind");
		bros[0].getSkills().removeByID("trait.night_owl");
		bros[0].getSkills().removeByID("trait.optimist");
		bros[0].getSkills().removeByID("trait.paranoid");
		bros[0].getSkills().removeByID("trait.pessimist");
		bros[0].getSkills().removeByID("trait.quick");
		bros[0].getSkills().removeByID("trait.short_sighted");
		bros[0].getSkills().removeByID("trait.spartan");
		bros[0].getSkills().removeByID("trait.strong");
		bros[0].getSkills().removeByID("trait.superstitious");
		bros[0].getSkills().removeByID("trait.sure_footing");
		bros[0].getSkills().removeByID("trait.survivor");
		bros[0].getSkills().removeByID("trait.swift");
		bros[0].getSkills().removeByID("trait.teamplayer");
		bros[0].getSkills().removeByID("trait.tiny");
		bros[0].getSkills().removeByID("trait.tough");
		bros[0].getSkills().removeByID("trait.weasel");
		bros[0].m.Skills.add(this.new("scripts/skills/traits/player_character_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/lucky_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/determined_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/traits/strong_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_fortified_mind"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_pathfinder"));
		bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].m.PerkPoints = 3;
		bros[0].m.LevelUps = 3;
		bros[0].m.Level = 4;
		bros[0].getBaseProperties().MeleeDefense -= 2;
		bros[0].m.Talents = [];
		local talents = bros[0].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 1;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 0;
		talents[this.Const.Attributes.MeleeSkill] = 3;
		talents[this.Const.Attributes.MeleeDefense] = 3;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
   	local items = bros[0].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		local armor = this.new("scripts/items/armor/scale_armor");
		armor.setUpgrade(this.new("scripts/items/armor_upgrades/additional_padding_upgrade"));
		bros[0].getItems().equip(armor);
		items.equip(this.new("scripts/items/helmets/nasal_helmet_with_closed_mail"));
		items.equip(this.new("scripts/items/weapons/greatsword"));
		bros[1].setStartValuesEx([
			"wildman_background"
		]);
		bros[1].setTitle("The Second");
	  bros[1].setPlaceInFormation(1);
		bros[1].getBackground().m.RawDescription = "The First says he is the Second. He might be. Hunting orc is nice too.";
		bros[1].improveMood(0.5, "Will hunt orc");
		bros[1].getSkills().removeByID("trait.ailing");
		bros[1].getSkills().removeByID("trait.asthmatic");
		bros[1].getSkills().removeByID("trait.athletic");
		bros[1].getSkills().removeByID("trait.bleeder");
		bros[1].getSkills().removeByID("trait.bloodthirsty");
		bros[1].getSkills().removeByID("trait.brave");
		bros[1].getSkills().removeByID("trait.bright");
		bros[1].getSkills().removeByID("trait.brute");
		bros[1].getSkills().removeByID("trait.clubfooted");
		bros[1].getSkills().removeByID("trait.clumsy");
		bros[1].getSkills().removeByID("trait.cocky");
		bros[1].getSkills().removeByID("trait.craven");
		bros[1].getSkills().removeByID("trait.dastard");
		bros[1].getSkills().removeByID("trait.deathwish");
		bros[1].getSkills().removeByID("trait.determined");
		bros[1].getSkills().removeByID("trait.dexterous");
		bros[1].getSkills().removeByID("trait.disloyal");
		bros[1].getSkills().removeByID("trait.drunkard");
		bros[1].getSkills().removeByID("trait.dumb");
		bros[1].getSkills().removeByID("trait.eagle_eyes");
		bros[1].getSkills().removeByID("trait.fainthearted");
		bros[1].getSkills().removeByID("trait.fat");
		bros[1].getSkills().removeByID("trait.fear_beasts");
		bros[1].getSkills().removeByID("trait.fear_greenskins");
		bros[1].getSkills().removeByID("trait.fear_undead");
		bros[1].getSkills().removeByID("trait.fearless");
		bros[1].getSkills().removeByID("trait.fragile");
		bros[1].getSkills().removeByID("trait.gluttonous");
		bros[1].getSkills().removeByID("trait.greedy");
		bros[1].getSkills().removeByID("trait.hate_beasts");
		bros[1].getSkills().removeByID("trait.hate_greenskins");
		bros[1].getSkills().removeByID("trait.hate_undead");
		bros[1].getSkills().removeByID("trait.hesitant");
		bros[1].getSkills().removeByID("trait.huge");
		bros[1].getSkills().removeByID("trait.impatient");
		bros[1].getSkills().removeByID("trait.insecure");
		bros[1].getSkills().removeByID("trait.iron_jaw");
		bros[1].getSkills().removeByID("trait.iron_lungs");
		bros[1].getSkills().removeByID("trait.irrational");
		bros[1].getSkills().removeByID("trait.loyal");
		bros[1].getSkills().removeByID("trait.lucky");
		bros[1].getSkills().removeByID("trait.night_blind");
		bros[1].getSkills().removeByID("trait.night_owl");
		bros[1].getSkills().removeByID("trait.optimist");
		bros[1].getSkills().removeByID("trait.paranoid");
		bros[1].getSkills().removeByID("trait.pessimist");
		bros[1].getSkills().removeByID("trait.quick");
		bros[1].getSkills().removeByID("trait.short_sighted");
		bros[1].getSkills().removeByID("trait.spartan");
		bros[1].getSkills().removeByID("trait.strong");
		bros[1].getSkills().removeByID("trait.superstitious");
		bros[1].getSkills().removeByID("trait.sure_footing");
		bros[1].getSkills().removeByID("trait.survivor");
		bros[1].getSkills().removeByID("trait.swift");
		bros[1].getSkills().removeByID("trait.teamplayer");
		bros[1].getSkills().removeByID("trait.tiny");
		bros[1].getSkills().removeByID("trait.tough");
		bros[1].getSkills().removeByID("trait.weasel");
		bros[1].getSkills().removeByID("trait.quick");
		bros[1].getSkills().removeByID("trait.swift");
		bros[1].getSkills().removeByID("trait.impatient");
		bros[1].m.Skills.add(this.new("scripts/skills/traits/survivor_trait"));
	  bros[1].m.Skills.add(this.new("scripts/skills/traits/huge_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/traits/iron_lungs_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/traits/hate_greenskins_trait"));
		bros[1].m.PerkPoints = 2;
		bros[1].m.LevelUps = 2;
		bros[1].m.Level = 3;
		bros[1].m.Attributes = [];
		local talents = bros[1].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 1;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 0;
		talents[this.Const.Attributes.MeleeSkill] = 2;
		talents[this.Const.Attributes.MeleeDefense] = 3;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 1;
		bros[1].m.Attributes = [];
		bros[1].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[1].m.BaseProperties.Hitpoints = 80;
		bros[1].m.BaseProperties.MeleeSkill = 60;
		bros[1].m.BaseProperties.MeleeDefense = 10;
		local items = bros[1].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/weapons/greenskins/orc_axe"));
		bros[2].setStartValuesEx([
			"brawler_background"
		]);
		bros[2].setTitle("The Third");
	  bros[2].setPlaceInFormation(2);
		bros[2].getBackground().m.RawDescription = "Why nine? He has no idea. He knows fighting. He likes fighting. He will fight until he is dead.";
		bros[2].improveMood(0.5, "Found a real challenge");
		bros[2].getSkills().removeByID("trait.ailing");
		bros[2].getSkills().removeByID("trait.asthmatic");
		bros[2].getSkills().removeByID("trait.athletic");
		bros[2].getSkills().removeByID("trait.bleeder");
		bros[2].getSkills().removeByID("trait.bloodthirsty");
		bros[2].getSkills().removeByID("trait.brave");
		bros[2].getSkills().removeByID("trait.bright");
		bros[2].getSkills().removeByID("trait.brute");
		bros[2].getSkills().removeByID("trait.clubfooted");
		bros[2].getSkills().removeByID("trait.clumsy");
		bros[2].getSkills().removeByID("trait.cocky");
		bros[2].getSkills().removeByID("trait.craven");
		bros[2].getSkills().removeByID("trait.dastard");
		bros[2].getSkills().removeByID("trait.deathwish");
		bros[2].getSkills().removeByID("trait.determined");
		bros[2].getSkills().removeByID("trait.dexterous");
		bros[2].getSkills().removeByID("trait.disloyal");
		bros[2].getSkills().removeByID("trait.drunkard");
		bros[2].getSkills().removeByID("trait.dumb");
		bros[2].getSkills().removeByID("trait.eagle_eyes");
		bros[2].getSkills().removeByID("trait.fainthearted");
		bros[2].getSkills().removeByID("trait.fat");
		bros[2].getSkills().removeByID("trait.fear_beasts");
		bros[2].getSkills().removeByID("trait.fear_greenskins");
		bros[2].getSkills().removeByID("trait.fear_undead");
		bros[2].getSkills().removeByID("trait.fearless");
		bros[2].getSkills().removeByID("trait.fragile");
		bros[2].getSkills().removeByID("trait.gluttonous");
		bros[2].getSkills().removeByID("trait.greedy");
		bros[2].getSkills().removeByID("trait.hate_beasts");
		bros[2].getSkills().removeByID("trait.hate_greenskins");
		bros[2].getSkills().removeByID("trait.hate_undead");
		bros[2].getSkills().removeByID("trait.hesitant");
		bros[2].getSkills().removeByID("trait.huge");
		bros[2].getSkills().removeByID("trait.impatient");
		bros[2].getSkills().removeByID("trait.insecure");
		bros[2].getSkills().removeByID("trait.iron_jaw");
		bros[2].getSkills().removeByID("trait.iron_lungs");
		bros[2].getSkills().removeByID("trait.irrational");
		bros[2].getSkills().removeByID("trait.loyal");
		bros[2].getSkills().removeByID("trait.lucky");
		bros[2].getSkills().removeByID("trait.night_blind");
		bros[2].getSkills().removeByID("trait.night_owl");
		bros[2].getSkills().removeByID("trait.optimist");
		bros[2].getSkills().removeByID("trait.paranoid");
		bros[2].getSkills().removeByID("trait.pessimist");
		bros[2].getSkills().removeByID("trait.quick");
		bros[2].getSkills().removeByID("trait.short_sighted");
		bros[2].getSkills().removeByID("trait.spartan");
		bros[2].getSkills().removeByID("trait.strong");
		bros[2].getSkills().removeByID("trait.superstitious");
		bros[2].getSkills().removeByID("trait.sure_footing");
		bros[2].getSkills().removeByID("trait.survivor");
		bros[2].getSkills().removeByID("trait.swift");
		bros[2].getSkills().removeByID("trait.teamplayer");
		bros[2].getSkills().removeByID("trait.tiny");
		bros[2].getSkills().removeByID("trait.tough");
		bros[2].getSkills().removeByID("trait.weasel");
		bros[2].m.Skills.add(this.new("scripts/skills/traits/lucky_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/traits/sure_footing_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/traits/quick_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/traits/tough_trait"));
		bros[2].m.PerkPoints = 2;
		bros[2].m.LevelUps = 2;
		bros[2].m.Level = 3;
		local talents = bros[2].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 1;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 2;
		talents[this.Const.Attributes.MeleeSkill] = 3;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		bros[2].m.Attributes = [];
		bros[2].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[2].m.BaseProperties.Hitpoints = 70;
		local items = bros[2].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.equip(this.new("scripts/items/weapons/winged_mace"));
		this.World.Assets.m.BusinessReputation = 100;
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/bread_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/goat_cheese_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/cured_venison_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/weapons/dagger"));
		this.World.Assets.getStash().add(this.new("scripts/items/loot/signet_ring_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/recovery_potion_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/lionheart_potion_item"));

	}

	function onSpawnPlayer()
	{
		local randomVillage;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
		{
			randomVillage = this.World.EntityManager.getSettlements()[i];

			if (randomVillage.isMilitary() && !randomVillage.isIsolatedFromRoads() && randomVillage.getSize() >= 3 && !randomVillage.isSouthern())
			{
				break;
			}
		}

		local randomVillageTile = randomVillage.getTile();

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 1), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 1));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 1), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 1));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) == 0)
				{
				}
				else if (!tile.HasRoad)
				{
				}
				else
				{
					randomVillageTile = tile;
					break;
				}
			}
		}
		while (1);

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(3);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/worldmap_02.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.first_scenario_intro");
		}, null);
	}

	function onInit()
	{
		this.World.Assets.m.BrothersMax = 9;
		if (this.World.State.getPlayer() != null)
		{
			this.World.State.getPlayer().m.BaseMovementSpeed = 111;
		}
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

});

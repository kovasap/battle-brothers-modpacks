this.shepherd_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.shepherd";
		this.m.Name = "Leader - The Shepherd";
		this.m.Description = "[p=c][img]gfx/ui/events/event_161.png[/img][/p][p]They call you mystic, seer and blade dancer, but you are nothing more than wind and sand. Wherever you go the poor and needy follow you, like sheep. You will make them part of your flock until they become like hyenas. Together you will fight the growing darkness. You are the Shepherd.\n\n[color=#bcad8c]Leader:[/color] Start with the Shepherd, a named swordlance, low funds, and six 'sheep'.\n[color=#bcad8c]Peasant Army[/color]: Can only hire the Lowborn, hire 24 of them and use max. 16 in battle.\n[color=#bcad8c]Avatar:[/color] If the Shepherd dies, the campaign ends.[/p]";
		this.m.Difficulty = 2;
		this.m.Order = 318;
	}

	function isValid()
	{
		return this.Const.DLC.Desert;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local names = [];

		for( local i = 0; i < 7; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.m.HireTime = this.Time.getVirtualTimeF();
			bro.improveMood(1.0, "On track");
		}

		local bros = roster.getAll();
		bros[0].setStartValuesEx([
			"assassin_southern_background"
		]);
		bros[0].setTitle("The Shepherd");
		bros[0].getBackground().m.RawDescription = "You have become a master of the swordlance after many years of training at the hidden monastery. You decided not to offer your services to the nomads, as many of your brothers do. You have other plans, a mission maybe, a purpose.";
		bros[0].setPlaceInFormation(4);
		bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].getSkills().removeByID("trait.ailing");
		bros[0].getSkills().removeByID("trait.asthmatic");
		bros[0].getSkills().removeByID("trait.athletic");
		bros[0].getSkills().removeByID("trait.bleeder");
		bros[0].getSkills().removeByID("trait.bloodthirsty");
		bros[0].getSkills().removeByID("trait.brave");
		bros[0].getSkills().removeByID("trait.bright");
		bros[0].getSkills().removeByID("trait.brute");
		bros[0].getSkills().removeByID("trait.clubfooted");
		bros[0].getSkills().removeByID("trait.clumsy");
		bros[0].getSkills().removeByID("trait.cocky");
		bros[0].getSkills().removeByID("trait.craven");
		bros[0].getSkills().removeByID("trait.dastard");
		bros[0].getSkills().removeByID("trait.deathwish");
		bros[0].getSkills().removeByID("trait.determined");
		bros[0].getSkills().removeByID("trait.dexterous");
		bros[0].getSkills().removeByID("trait.disloyal");
		bros[0].getSkills().removeByID("trait.drunkard");
		bros[0].getSkills().removeByID("trait.dumb");
		bros[0].getSkills().removeByID("trait.eagle_eyes");
		bros[0].getSkills().removeByID("trait.fainthearted");
		bros[0].getSkills().removeByID("trait.fat");
		bros[0].getSkills().removeByID("trait.fear_beasts");
		bros[0].getSkills().removeByID("trait.fear_greenskins");
		bros[0].getSkills().removeByID("trait.fear_undead");
		bros[0].getSkills().removeByID("trait.fearless");
		bros[0].getSkills().removeByID("trait.fragile");
		bros[0].getSkills().removeByID("trait.gluttonous");
		bros[0].getSkills().removeByID("trait.greedy");
		bros[0].getSkills().removeByID("trait.hate_beasts");
		bros[0].getSkills().removeByID("trait.hate_greenskins");
		bros[0].getSkills().removeByID("trait.hate_undead");
		bros[0].getSkills().removeByID("trait.hesitant");
		bros[0].getSkills().removeByID("trait.huge");
		bros[0].getSkills().removeByID("trait.impatient");
		bros[0].getSkills().removeByID("trait.insecure");
		bros[0].getSkills().removeByID("trait.iron_jaw");
		bros[0].getSkills().removeByID("trait.iron_lungs");
		bros[0].getSkills().removeByID("trait.irrational");
		bros[0].getSkills().removeByID("trait.loyal");
		bros[0].getSkills().removeByID("trait.lucky");
		bros[0].getSkills().removeByID("trait.night_blind");
		bros[0].getSkills().removeByID("trait.night_owl");
		bros[0].getSkills().removeByID("trait.optimist");
		bros[0].getSkills().removeByID("trait.paranoid");
		bros[0].getSkills().removeByID("trait.pessimist");
		bros[0].getSkills().removeByID("trait.quick");
		bros[0].getSkills().removeByID("trait.short_sighted");
		bros[0].getSkills().removeByID("trait.spartan");
		bros[0].getSkills().removeByID("trait.strong");
		bros[0].getSkills().removeByID("trait.superstitious");
		bros[0].getSkills().removeByID("trait.sure_footing");
		bros[0].getSkills().removeByID("trait.survivor");
		bros[0].getSkills().removeByID("trait.swift");
		bros[0].getSkills().removeByID("trait.teamplayer");
		bros[0].getSkills().removeByID("trait.tiny");
		bros[0].getSkills().removeByID("trait.tough");
		bros[0].getSkills().removeByID("trait.weasel");
		bros[0].getSkills().add(this.new("scripts/skills/traits/player_character_trait"));
	  bros[0].getSkills().add(this.new("scripts/skills/traits/spartan_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/fearless_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/determined_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/quick_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_footwork"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_mastery_polearm"));
		bros[0].m.PerkPoints = 3;
		bros[0].m.LevelUps = 3;
		bros[0].m.Level = 4;
		bros[0].getBaseProperties().MeleeDefense -= 2;
		bros[0].m.Talents = [];
		local talents = bros[0].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 2;
		talents[this.Const.Attributes.MeleeSkill] =3;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		bros[0].m.Attributes = [];
		bros[0].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[0].m.BaseProperties.Hitpoints=69;
		bros[0].m.BaseProperties.Stamina = 111;
		bros[0].m.BaseProperties.MeleeSkill = 69;
		bros[0].m.BaseProperties.MeleeDefense = 9;
		bros[0].m.BaseProperties.RangedDefense = 9;
		local items = bros[0].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		local swordlance = this.new("scripts/items/weapons/named/named_swordlance");
		swordlance.m.Name = "The Shepherd\'s Staff";
		items.equip(swordlance);
		items.equip(this.new("scripts/items/helmets/oriental/blade_dancer_head_wrap"));
		items.equip(this.new("scripts/items/armor/oriental/assassin_robe"));
		bros[1].setStartValuesEx([
			"beggar_southern_background"
		]);
		bros[1].getBackground().m.RawDescription = "Follows the Seer.";
		bros[1].setPlaceInFormation(1);
		bros[2].setStartValuesEx([
			"daytaler_southern_background"
		]);
		bros[2].getBackground().m.RawDescription = "Follows the Blade dancer.";
		bros[2].setPlaceInFormation(2);
		bros[3].setStartValuesEx([
			"cripple_southern_background"
		]);
		bros[3].getBackground().m.RawDescription = "Follows the Mystic.";
		bros[3].setPlaceInFormation(3);
		bros[4].setStartValuesEx([
			"peddler_southern_background"
		]);
		bros[4].getBackground().m.RawDescription = "Follows the Seer.";
		bros[4].setPlaceInFormation(5);
		bros[5].setStartValuesEx([
			"gambler_southern_background"
		]);
		bros[5].getBackground().m.RawDescription = "Follows the Blade dancer.";
		bros[5].setPlaceInFormation(6);
		bros[6].setStartValuesEx([
			"eunuch_southern_background"
		]);
		bros[6].getBackground().m.RawDescription = "Likes to fight.";
		bros[6].setPlaceInFormation(7);
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/rice_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/rice_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/rice_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/dates_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/armor_upgrades/hyena_fur_upgrade"));
		this.World.Assets.m.Money = this.World.Assets.m.Money / 2 - (this.World.Assets.getEconomicDifficulty() == 0 ? 0 : 100);
		this.World.Assets.m.ArmorParts = 20;
		this.World.Assets.m.Medicine = 20;
		this.World.Assets.m.Ammo = 50;

	}

	function onSpawnPlayer()
	{
		local randomVillage;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
		{
			randomVillage = this.World.EntityManager.getSettlements()[i];

			if (!randomVillage.isIsolatedFromRoads() && randomVillage.isSouthern() && randomVillage.hasBuilding("building.arena"))
			{
				break;
			}
		}

		local randomVillageTile = randomVillage.getTile();

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 1), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 1));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 1), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 1));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) == 0)
				{
				}
				else if (!tile.HasRoad)
				{
				}
				else
				{
					randomVillageTile = tile;
					break;
				}
			}
		}
		while (1);

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(14);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/gilded_01.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.shepherd_scenario_intro");
		}, null);
	}

	function onInit()
	{
		this.World.Assets.m.BrothersMax = 25;
		this.World.Assets.m.BrothersMaxInCombat = 16;
		this.World.Assets.m.BrothersScaleMax = 14;
	}

	function onUpdateHiringRoster( _roster )
	{
		local garbage = [];
		local bros = _roster.getAll();

		foreach( i, bro in bros )
		{
			if (!bro.getBackground().isLowborn())
			{
				garbage.push(bro);
			}
		}

		foreach( g in garbage )
		{
			_roster.remove(g);
		}
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

});

this.serpent_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.serpent";
		this.m.Name = "Leader - The Serpent";
		this.m.Description = "[p=c][img]gfx/ui/events/event_149.png[/img][/p][p]City states politics are vicious. It\'s a struggle to remain in power. Your brother, the vizier, hired an assassin to kill you. The reputation that condemned you saved you as well. The assassin gave you a chance to bargain for your life. You need to disappear for a while, lay low in the north. You are not very good at laying low. You are the Serpent.\n\n[color=#bcad8c]Leader:[/color] Start with the Serpent, a named shamshir, two bodyguards and a slave.\n[color=#bcad8c]Hunted in the South:[/color] Start with bad relations with the city states.\n[color=#bcad8c]Avatar:[/color] If the Serpent dies, the campaign ends.[/p]";
		this.m.Difficulty = 2;
		this.m.Order = 316;
	}

	function isValid()
	{
		return this.Const.DLC.Desert;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local names = [];

		for( local i = 0; i < 4; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.m.HireTime = this.Time.getVirtualTimeF();
		}

		local bros = roster.getAll();
		bros[0].setStartValuesEx([
			"nomad_background"
		]);
		bros[0].getBackground().m.RawDescription = "Born into an extremely wealthy family you couldn't care less about riches, preferring freedom and adventure over everything else.";
		bros[0].setTitle("The Serpent");
		bros[0].worsenMood(1.0, "Needs to run for his life");
		bros[0].getSkills().removeByID("trait.ailing");
		bros[0].getSkills().removeByID("trait.asthmatic");
		bros[0].getSkills().removeByID("trait.athletic");
		bros[0].getSkills().removeByID("trait.bleeder");
		bros[0].getSkills().removeByID("trait.bloodthirsty");
		bros[0].getSkills().removeByID("trait.brave");
		bros[0].getSkills().removeByID("trait.bright");
		bros[0].getSkills().removeByID("trait.brute");
		bros[0].getSkills().removeByID("trait.clubfooted");
		bros[0].getSkills().removeByID("trait.clumsy");
		bros[0].getSkills().removeByID("trait.cocky");
		bros[0].getSkills().removeByID("trait.craven");
		bros[0].getSkills().removeByID("trait.dastard");
		bros[0].getSkills().removeByID("trait.deathwish");
		bros[0].getSkills().removeByID("trait.determined");
		bros[0].getSkills().removeByID("trait.dexterous");
		bros[0].getSkills().removeByID("trait.disloyal");
		bros[0].getSkills().removeByID("trait.drunkard");
		bros[0].getSkills().removeByID("trait.dumb");
		bros[0].getSkills().removeByID("trait.eagle_eyes");
		bros[0].getSkills().removeByID("trait.fainthearted");
		bros[0].getSkills().removeByID("trait.fat");
		bros[0].getSkills().removeByID("trait.fear_beasts");
		bros[0].getSkills().removeByID("trait.fear_greenskins");
		bros[0].getSkills().removeByID("trait.fear_undead");
		bros[0].getSkills().removeByID("trait.fearless");
		bros[0].getSkills().removeByID("trait.fragile");
		bros[0].getSkills().removeByID("trait.gluttonous");
		bros[0].getSkills().removeByID("trait.greedy");
		bros[0].getSkills().removeByID("trait.hate_beasts");
		bros[0].getSkills().removeByID("trait.hate_greenskins");
		bros[0].getSkills().removeByID("trait.hate_undead");
		bros[0].getSkills().removeByID("trait.hesitant");
		bros[0].getSkills().removeByID("trait.huge");
		bros[0].getSkills().removeByID("trait.impatient");
		bros[0].getSkills().removeByID("trait.insecure");
		bros[0].getSkills().removeByID("trait.iron_jaw");
		bros[0].getSkills().removeByID("trait.iron_lungs");
		bros[0].getSkills().removeByID("trait.irrational");
		bros[0].getSkills().removeByID("trait.loyal");
		bros[0].getSkills().removeByID("trait.lucky");
		bros[0].getSkills().removeByID("trait.night_blind");
		bros[0].getSkills().removeByID("trait.night_owl");
		bros[0].getSkills().removeByID("trait.optimist");
		bros[0].getSkills().removeByID("trait.paranoid");
		bros[0].getSkills().removeByID("trait.pessimist");
		bros[0].getSkills().removeByID("trait.quick");
		bros[0].getSkills().removeByID("trait.short_sighted");
		bros[0].getSkills().removeByID("trait.spartan");
		bros[0].getSkills().removeByID("trait.strong");
		bros[0].getSkills().removeByID("trait.superstitious");
		bros[0].getSkills().removeByID("trait.sure_footing");
		bros[0].getSkills().removeByID("trait.survivor");
		bros[0].getSkills().removeByID("trait.swift");
		bros[0].getSkills().removeByID("trait.teamplayer");
		bros[0].getSkills().removeByID("trait.tiny");
		bros[0].getSkills().removeByID("trait.tough");
		bros[0].getSkills().removeByID("trait.weasel");
		bros[0].getSkills().add(this.new("scripts/skills/traits/player_character_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/strong_trait"));
		bros[0].getSkills().add(this.new("scripts/skills/traits/determined_trait"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_anticipation"));
		bros[0].m.Skills.add(this.new("scripts/skills/perks/perk_underdog"));
		bros[0].setPlaceInFormation(4);
	  bros[0].getFlags().set("IsPlayerCharacter", true);
		bros[0].m.PerkPoints = 3;
		bros[0].m.LevelUps = 3;
		bros[0].m.Level = 4;
		bros[0].getBaseProperties().MeleeDefense -= 2;
		bros[0].m.Talents = [];
		local talents = bros[0].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 1;
		talents[this.Const.Attributes.Initiative] = 2;
		talents[this.Const.Attributes.MeleeSkill] = 3;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		bros[0].m.Attributes = [];
		bros[0].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[0].m.BaseProperties.Hitpoints = 60;
		bros[0].m.BaseProperties.Stamina = 110;
		bros[0].m.BaseProperties.Bravery = 50;
		bros[0].m.BaseProperties.MeleeSkill = 65;
		bros[0].m.BaseProperties.MeleeDefense = 8;
		local items = bros[0].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/helmets/oriental/southern_helmet_with_coif"));
		local sword = this.new("scripts/items/weapons/named/named_shamshir");
		sword.m.Name = "The Sting of Truth";
		items.equip(sword);
		local armor = this.new("scripts/items/armor/oriental/mail_and_lamellar_plating");
		armor.setUpgrade(this.new("scripts/items/armor_upgrades/serpent_skin_upgrade"));
		bros[0].getItems().equip(armor);
		bros[1].setStartValuesEx([
			"gladiator_background"
		]);
		bros[1].setTitle("The Bought");
		bros[1].getBackground().m.RawDescription = "You bought your freedom as a slave after your successes in the arena. Then the Serpent bought you.";
		bros[1].worsenMood(0.5, "Is going to miss city life.");
		bros[1].setPlaceInFormation(3);
		bros[1].getSkills().removeByID("trait.ailing");
		bros[1].getSkills().removeByID("trait.asthmatic");
		bros[1].getSkills().removeByID("trait.athletic");
		bros[1].getSkills().removeByID("trait.bleeder");
		bros[1].getSkills().removeByID("trait.bloodthirsty");
		bros[1].getSkills().removeByID("trait.brave");
		bros[1].getSkills().removeByID("trait.bright");
		bros[1].getSkills().removeByID("trait.brute");
		bros[1].getSkills().removeByID("trait.clubfooted");
		bros[1].getSkills().removeByID("trait.clumsy");
		bros[1].getSkills().removeByID("trait.cocky");
		bros[1].getSkills().removeByID("trait.craven");
		bros[1].getSkills().removeByID("trait.dastard");
		bros[1].getSkills().removeByID("trait.deathwish");
		bros[1].getSkills().removeByID("trait.determined");
		bros[1].getSkills().removeByID("trait.dexterous");
		bros[1].getSkills().removeByID("trait.disloyal");
		bros[1].getSkills().removeByID("trait.drunkard");
		bros[1].getSkills().removeByID("trait.dumb");
		bros[1].getSkills().removeByID("trait.eagle_eyes");
		bros[1].getSkills().removeByID("trait.fainthearted");
		bros[1].getSkills().removeByID("trait.fat");
		bros[1].getSkills().removeByID("trait.fear_beasts");
		bros[1].getSkills().removeByID("trait.fear_greenskins");
		bros[1].getSkills().removeByID("trait.fear_undead");
		bros[1].getSkills().removeByID("trait.fearless");
		bros[1].getSkills().removeByID("trait.fragile");
		bros[1].getSkills().removeByID("trait.gluttonous");
		bros[1].getSkills().removeByID("trait.greedy");
		bros[1].getSkills().removeByID("trait.hate_beasts");
		bros[1].getSkills().removeByID("trait.hate_greenskins");
		bros[1].getSkills().removeByID("trait.hate_undead");
		bros[1].getSkills().removeByID("trait.hesitant");
		bros[1].getSkills().removeByID("trait.huge");
		bros[1].getSkills().removeByID("trait.impatient");
		bros[1].getSkills().removeByID("trait.insecure");
		bros[1].getSkills().removeByID("trait.iron_jaw");
		bros[1].getSkills().removeByID("trait.iron_lungs");
		bros[1].getSkills().removeByID("trait.irrational");
		bros[1].getSkills().removeByID("trait.loyal");
		bros[1].getSkills().removeByID("trait.lucky");
		bros[1].getSkills().removeByID("trait.night_blind");
		bros[1].getSkills().removeByID("trait.night_owl");
		bros[1].getSkills().removeByID("trait.optimist");
		bros[1].getSkills().removeByID("trait.paranoid");
		bros[1].getSkills().removeByID("trait.pessimist");
		bros[1].getSkills().removeByID("trait.quick");
		bros[1].getSkills().removeByID("trait.short_sighted");
		bros[1].getSkills().removeByID("trait.spartan");
		bros[1].getSkills().removeByID("trait.strong");
		bros[1].getSkills().removeByID("trait.superstitious");
		bros[1].getSkills().removeByID("trait.sure_footing");
		bros[1].getSkills().removeByID("trait.survivor");
		bros[1].getSkills().removeByID("trait.swift");
		bros[1].getSkills().removeByID("trait.teamplayer");
		bros[1].getSkills().removeByID("trait.tiny");
		bros[1].getSkills().removeByID("trait.tough");
		bros[1].getSkills().removeByID("trait.weasel");
		bros[1].getSkills().add(this.new("scripts/skills/traits/arena_fighter_trait"));
		bros[1].getFlags().set("ArenaFightsWon", 5);
		bros[1].getFlags().set("ArenaFights", 5);
		bros[1].getSkills().add(this.new("scripts/skills/traits/tough_trait"));
		bros[1].getSkills().add(this.new("scripts/skills/traits/bloodthirsty_trait"));
		bros[1].m.Skills.add(this.new("scripts/skills/perks/perk_fast_adaption"));
		bros[1].m.PerkPoints = 3;
		bros[1].m.LevelUps = 3;
		bros[1].m.Level = 4;
		bros[1].m.Talents = [];
		local talents = bros[1].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 0;
		talents[this.Const.Attributes.Initiative] = 2;
		talents[this.Const.Attributes.MeleeSkill] = 2;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 1;
		local items = bros[1].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		local armor = this.new("scripts/items/armor/oriental/gladiator_harness");
		armor.setUpgrade(this.new("scripts/items/armor_upgrades/light_gladiator_upgrade"));
		bros[1].getItems().equip(armor);
		local helmet = this.new("scripts/items/helmets/oriental/gladiator_helmet");
		helmet.setVariant(14);
		bros[1].getItems().equip(helmet);
		items.equip(this.new("scripts/items/weapons/oriental/heavy_southern_mace"));
		items.equip(this.new("scripts/items/tools/throwing_net"));
		bros[2].setStartValuesEx([
			"assassin_southern_background"
		]);
		bros[2].setTitle("The Talon");
		bros[2].getBackground().m.RawDescription = "You were trained to become an assassin. You were paid to kill the Serpent. But you had second thoughts so you gave him a chance to negotiate for his life. The Serpent offered you more.";
		bros[2].improveMood(1.0, "Got a good deal. gets paid well.");
		bros[2].setPlaceInFormation(5);
		bros[2].getSkills().removeByID("trait.ailing");
		bros[2].getSkills().removeByID("trait.asthmatic");
		bros[2].getSkills().removeByID("trait.athletic");
		bros[2].getSkills().removeByID("trait.bleeder");
		bros[2].getSkills().removeByID("trait.bloodthirsty");
		bros[2].getSkills().removeByID("trait.brave");
		bros[2].getSkills().removeByID("trait.bright");
		bros[2].getSkills().removeByID("trait.brute");
		bros[2].getSkills().removeByID("trait.clubfooted");
		bros[2].getSkills().removeByID("trait.clumsy");
		bros[2].getSkills().removeByID("trait.cocky");
		bros[2].getSkills().removeByID("trait.craven");
		bros[2].getSkills().removeByID("trait.dastard");
		bros[2].getSkills().removeByID("trait.deathwish");
		bros[2].getSkills().removeByID("trait.determined");
		bros[2].getSkills().removeByID("trait.dexterous");
		bros[2].getSkills().removeByID("trait.disloyal");
		bros[2].getSkills().removeByID("trait.drunkard");
		bros[2].getSkills().removeByID("trait.dumb");
		bros[2].getSkills().removeByID("trait.eagle_eyes");
		bros[2].getSkills().removeByID("trait.fainthearted");
		bros[2].getSkills().removeByID("trait.fat");
		bros[2].getSkills().removeByID("trait.fear_beasts");
		bros[2].getSkills().removeByID("trait.fear_greenskins");
		bros[2].getSkills().removeByID("trait.fear_undead");
		bros[2].getSkills().removeByID("trait.fearless");
		bros[2].getSkills().removeByID("trait.fragile");
		bros[2].getSkills().removeByID("trait.gluttonous");
		bros[2].getSkills().removeByID("trait.greedy");
		bros[2].getSkills().removeByID("trait.hate_beasts");
		bros[2].getSkills().removeByID("trait.hate_greenskins");
		bros[2].getSkills().removeByID("trait.hate_undead");
		bros[2].getSkills().removeByID("trait.hesitant");
		bros[2].getSkills().removeByID("trait.huge");
		bros[2].getSkills().removeByID("trait.impatient");
		bros[2].getSkills().removeByID("trait.insecure");
		bros[2].getSkills().removeByID("trait.iron_jaw");
		bros[2].getSkills().removeByID("trait.iron_lungs");
		bros[2].getSkills().removeByID("trait.irrational");
		bros[2].getSkills().removeByID("trait.loyal");
		bros[2].getSkills().removeByID("trait.lucky");
		bros[2].getSkills().removeByID("trait.night_blind");
		bros[2].getSkills().removeByID("trait.night_owl");
		bros[2].getSkills().removeByID("trait.optimist");
		bros[2].getSkills().removeByID("trait.paranoid");
		bros[2].getSkills().removeByID("trait.pessimist");
		bros[2].getSkills().removeByID("trait.quick");
		bros[2].getSkills().removeByID("trait.short_sighted");
		bros[2].getSkills().removeByID("trait.spartan");
		bros[2].getSkills().removeByID("trait.strong");
		bros[2].getSkills().removeByID("trait.superstitious");
		bros[2].getSkills().removeByID("trait.sure_footing");
		bros[2].getSkills().removeByID("trait.survivor");
		bros[2].getSkills().removeByID("trait.swift");
		bros[2].getSkills().removeByID("trait.teamplayer");
		bros[2].getSkills().removeByID("trait.tiny");
		bros[2].getSkills().removeByID("trait.tough");
		bros[2].getSkills().removeByID("trait.weasel");
		bros[2].getSkills().add(this.new("scripts/skills/traits/greedy_trait"));
		bros[2].getSkills().add(this.new("scripts/skills/traits/quick_trait"));
		bros[2].m.Skills.add(this.new("scripts/skills/perks/perk_relentless"));
		bros[2].m.PerkPoints = 3;
		bros[2].m.LevelUps = 3;
		bros[2].m.Level = 4;
		bros[2].m.Talents = [];
		local talents = bros[2].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 0;
		talents[this.Const.Attributes.Fatigue] = 1;
		talents[this.Const.Attributes.Bravery] = 0;
		talents[this.Const.Attributes.Initiative] = 3;
		talents[this.Const.Attributes.MeleeSkill] = 2;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		local items = bros[2].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/helmets/oriental/assassin_head_wrap"));
		items.equip(this.new("scripts/items/armor/oriental/assassin_robe"));
		items.equip(this.new("scripts/items/weapons/oriental/qatal_dagger"));
		items.equip(this.new("scripts/items/tools/daze_bomb_item"));
		bros[3].setStartValuesEx([
			"slave_barbarian_background"
		]);
		bros[3].setTitle("The Thinker");
		bros[3].getBackground().m.RawDescription = "Lost your freedom. Regained it by playing a game. How rare is that? Happy to return to the north or wherever the Serpent goes.";
		bros[3].improveMood(1.0, "Going back to the north.");
		bros[3].setPlaceInFormation(13);
		bros[3].getSkills().removeByID("trait.ailing");
		bros[3].getSkills().removeByID("trait.asthmatic");
		bros[3].getSkills().removeByID("trait.athletic");
		bros[3].getSkills().removeByID("trait.bleeder");
		bros[3].getSkills().removeByID("trait.bloodthirsty");
		bros[3].getSkills().removeByID("trait.brave");
		bros[3].getSkills().removeByID("trait.bright");
		bros[3].getSkills().removeByID("trait.brute");
		bros[3].getSkills().removeByID("trait.clubfooted");
		bros[3].getSkills().removeByID("trait.clumsy");
		bros[3].getSkills().removeByID("trait.cocky");
		bros[3].getSkills().removeByID("trait.craven");
		bros[3].getSkills().removeByID("trait.dastard");
		bros[3].getSkills().removeByID("trait.deathwish");
		bros[3].getSkills().removeByID("trait.determined");
		bros[3].getSkills().removeByID("trait.dexterous");
		bros[3].getSkills().removeByID("trait.disloyal");
		bros[3].getSkills().removeByID("trait.drunkard");
		bros[3].getSkills().removeByID("trait.dumb");
		bros[3].getSkills().removeByID("trait.eagle_eyes");
		bros[3].getSkills().removeByID("trait.fainthearted");
		bros[3].getSkills().removeByID("trait.fat");
		bros[3].getSkills().removeByID("trait.fear_beasts");
		bros[3].getSkills().removeByID("trait.fear_greenskins");
		bros[3].getSkills().removeByID("trait.fear_undead");
		bros[3].getSkills().removeByID("trait.fearless");
		bros[3].getSkills().removeByID("trait.fragile");
		bros[3].getSkills().removeByID("trait.gluttonous");
		bros[3].getSkills().removeByID("trait.greedy");
		bros[3].getSkills().removeByID("trait.hate_beasts");
		bros[3].getSkills().removeByID("trait.hate_greenskins");
		bros[3].getSkills().removeByID("trait.hate_undead");
		bros[3].getSkills().removeByID("trait.hesitant");
		bros[3].getSkills().removeByID("trait.huge");
		bros[3].getSkills().removeByID("trait.impatient");
		bros[3].getSkills().removeByID("trait.insecure");
		bros[3].getSkills().removeByID("trait.iron_jaw");
		bros[3].getSkills().removeByID("trait.iron_lungs");
		bros[3].getSkills().removeByID("trait.irrational");
		bros[3].getSkills().removeByID("trait.loyal");
		bros[3].getSkills().removeByID("trait.lucky");
		bros[3].getSkills().removeByID("trait.night_blind");
		bros[3].getSkills().removeByID("trait.night_owl");
		bros[3].getSkills().removeByID("trait.optimist");
		bros[3].getSkills().removeByID("trait.paranoid");
		bros[3].getSkills().removeByID("trait.pessimist");
		bros[3].getSkills().removeByID("trait.quick");
		bros[3].getSkills().removeByID("trait.short_sighted");
		bros[3].getSkills().removeByID("trait.spartan");
		bros[3].getSkills().removeByID("trait.strong");
		bros[3].getSkills().removeByID("trait.superstitious");
		bros[3].getSkills().removeByID("trait.sure_footing");
		bros[3].getSkills().removeByID("trait.survivor");
		bros[3].getSkills().removeByID("trait.swift");
		bros[3].getSkills().removeByID("trait.teamplayer");
		bros[3].getSkills().removeByID("trait.tiny");
		bros[3].getSkills().removeByID("trait.tough");
		bros[3].getSkills().removeByID("trait.weasel");
		bros[3].m.Skills.add(this.new("scripts/skills/traits/bright_trait"));
		bros[3].m.Skills.add(this.new("scripts/skills/perks/perk_student"));
		bros[3].m.PerkPoints = 2;
		bros[3].m.LevelUps = 2;
		bros[3].m.Level = 3;
		bros[3].m.Talents = [];
		local talents = bros[3].getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.MeleeSkill] = 1;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Hitpoints] = 1;
		talents[this.Const.Attributes.Bravery] = 2;
		bros[3].m.Attributes = [];
		bros[3].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[3].m.BaseProperties.Bravery = 45;
		local items = bros[3].getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Ammo));
		items.equip(this.new("scripts/items/armor/oriental/cloth_sash"));
		this.World.Assets.m.BusinessReputation = 100;
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/rice_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/dates_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/dried_lamb_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/wine_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/antidote_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/accessory/spider_poison_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/happy_powder_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/fire_bomb_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/tools/throwing_net"));
		this.World.Assets.getStash().add(this.new("scripts/items/shields/oriental/metal_round_shield"));

	}

	function onSpawnPlayer()
	{
		local randomVillage;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
		{
			randomVillage = this.World.EntityManager.getSettlements()[i];

			if (!randomVillage.isIsolatedFromRoads() && randomVillage.isSouthern() && randomVillage.hasBuilding("building.arena"))
			{
				break;
			}
		}

		local randomVillageTile = randomVillage.getTile();

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 1), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 1));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 1), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 1));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) == 0)
				{
				}
				else if (!tile.HasRoad)
				{
				}
				else
				{
					randomVillageTile = tile;
					break;
				}
			}
		}
		while (1);

		local cityStates = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.OrientalCityState);
		for( local i = 0; i < 3; i = ++i )
		{
			cityStates[i].addPlayerRelation(-75.0, "You are considered an enemy of the city states. You need to lay low for a while.");
		}

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(15);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/worldmap_11.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.serpent_scenario_intro");
		}, null);
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

});

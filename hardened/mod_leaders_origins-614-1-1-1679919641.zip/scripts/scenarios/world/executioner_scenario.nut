this.executioner_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.executioner";
		this.m.Name = "Leader - The Executioner";
		this.m.Description = "[p=c][img]gfx/ui/events/event_03.png[/img][/p][p]They think you\'re a cultist sometimes. You burned cultists, hanged them and chopped their heads off. And not just cultists. They complained you liked your job too much. You have no job now. No friends. You need some companions to chop together. Chopping is your specialty after all. You are the Executioner.\n\n[color=#bcad8c]Leader:[/color] Start with the Executioner, a named greataxe, and low funds.\n[color=#bcad8c]Avatar:[/color] If the Executioner dies, the campaign ends.[/p]";
		this.m.Difficulty = 3;
		this.m.Order = 302;
	}

	function isValid()
	{
		return this.Const.DLC.Wildmen;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();
		local bro;
		bro = roster.create("scripts/entity/tactical/player");
		bro.setStartValuesEx([
			"lumberjack_background"
		]);
		bro.setTitle("The Executioner");
		bro.getBackground().m.RawDescription = "Started off chopping wood with your father, a woodcutter in service off a local lord. Killed a wolf with your axe. Liked it. Because of your size and scowl, you got recruited by a local executioner, to help carry the dead bodies. Became executioner yourself after the old one retired. Got fired. Needs friends.";
		bro.setPlaceInFormation(4);
		bro.getFlags().set("IsPlayerCharacter", true);
		bro.worsenMood(1.0, "Lost your job");
		bro.worsenMood(0.5, "Did not chop in a while");
		bro.improveMood(1.0, "Found a friend!");
		bro.getSkills().removeByID("trait.ailing");
		bro.getSkills().removeByID("trait.asthmatic");
		bro.getSkills().removeByID("trait.athletic");
		bro.getSkills().removeByID("trait.bleeder");
		bro.getSkills().removeByID("trait.bloodthirsty");
		bro.getSkills().removeByID("trait.brave");
		bro.getSkills().removeByID("trait.bright");
		bro.getSkills().removeByID("trait.brute");
		bro.getSkills().removeByID("trait.clubfooted");
		bro.getSkills().removeByID("trait.clumsy");
		bro.getSkills().removeByID("trait.cocky");
		bro.getSkills().removeByID("trait.craven");
		bro.getSkills().removeByID("trait.dastard");
		bro.getSkills().removeByID("trait.deathwish");
		bro.getSkills().removeByID("trait.determined");
		bro.getSkills().removeByID("trait.dexterous");
		bro.getSkills().removeByID("trait.disloyal");
		bro.getSkills().removeByID("trait.drunkard");
		bro.getSkills().removeByID("trait.dumb");
		bro.getSkills().removeByID("trait.eagle_eyes");
		bro.getSkills().removeByID("trait.fainthearted");
		bro.getSkills().removeByID("trait.fat");
		bro.getSkills().removeByID("trait.fear_beasts");
		bro.getSkills().removeByID("trait.fear_greenskins");
		bro.getSkills().removeByID("trait.fear_undead");
		bro.getSkills().removeByID("trait.fearless");
		bro.getSkills().removeByID("trait.fragile");
		bro.getSkills().removeByID("trait.gluttonous");
		bro.getSkills().removeByID("trait.greedy");
		bro.getSkills().removeByID("trait.hate_beasts");
		bro.getSkills().removeByID("trait.hate_greenskins");
		bro.getSkills().removeByID("trait.hate_undead");
		bro.getSkills().removeByID("trait.hesitant");
		bro.getSkills().removeByID("trait.huge");
		bro.getSkills().removeByID("trait.impatient");
		bro.getSkills().removeByID("trait.insecure");
		bro.getSkills().removeByID("trait.iron_jaw");
		bro.getSkills().removeByID("trait.iron_lungs");
		bro.getSkills().removeByID("trait.irrational");
		bro.getSkills().removeByID("trait.loyal");
		bro.getSkills().removeByID("trait.lucky");
		bro.getSkills().removeByID("trait.night_blind");
		bro.getSkills().removeByID("trait.night_owl");
		bro.getSkills().removeByID("trait.optimist");
		bro.getSkills().removeByID("trait.paranoid");
		bro.getSkills().removeByID("trait.pessimist");
		bro.getSkills().removeByID("trait.quick");
		bro.getSkills().removeByID("trait.short_sighted");
		bro.getSkills().removeByID("trait.spartan");
		bro.getSkills().removeByID("trait.strong");
		bro.getSkills().removeByID("trait.superstitious");
		bro.getSkills().removeByID("trait.sure_footing");
		bro.getSkills().removeByID("trait.survivor");
		bro.getSkills().removeByID("trait.swift");
		bro.getSkills().removeByID("trait.teamplayer");
		bro.getSkills().removeByID("trait.tiny");
		bro.getSkills().removeByID("trait.tough");
		bro.getSkills().removeByID("trait.weasel");
		bro.m.Skills.add(this.new("scripts/skills/traits/player_character_trait"));
		bro.m.Skills.add(this.new("scripts/skills/traits/executioner_trait"));
		bro.m.Skills.add(this.new("scripts/skills/traits/huge_trait"));
		bro.m.Skills.add(this.new("scripts/skills/traits/bloodthirsty_trait"));
		bro.m.Skills.add(this.new("scripts/skills/perks/perk_mastery_axe"));
		bro.m.Skills.add(this.new("scripts/skills/perks/perk_coup_de_grace"));
		bro.m.PerkPoints = 3;
		bro.m.LevelUps = 3;
		bro.m.Level = 4;
		bro.getBaseProperties().MeleeDefense -= 2;
		bro.m.Talents = [];
		local talents = bro.getTalents();
		talents.resize(this.Const.Attributes.COUNT, 0);
		talents[this.Const.Attributes.Hitpoints] = 1;
		talents[this.Const.Attributes.Fatigue] = 2;
		talents[this.Const.Attributes.Bravery] = 2;
		talents[this.Const.Attributes.Initiative] = 0;
		talents[this.Const.Attributes.MeleeSkill] = 3;
		talents[this.Const.Attributes.MeleeDefense] = 2;
		talents[this.Const.Attributes.RangedSkill] = 0;
		talents[this.Const.Attributes.RangedDefense] = 0;
		bro.m.Attributes = [];
		bro.fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bro.m.BaseProperties.MeleeSkill = 56;
		bro.m.BaseProperties.RangedSkill = 6;
		bro.m.BaseProperties.MeleeDefense = 11;
		bro.m.BaseProperties.RangedDefense = 11;
   	local items = bro.getItems();
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
		items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		local axe = this.new("scripts/items/weapons/named/named_greataxe");
		axe.m.Name = "The Chopper";
		items.equip(axe);
		local armor = this.new("scripts/items/armor/decayed_reinforced_mail_hauberk");
		armor.setUpgrade(this.new("scripts/items/armor_upgrades/metal_plating_upgrade"));
		bro.getItems().equip(armor);
		items.equip(this.new("scripts/items/helmets/cultist_hood"));
		local warhound = this.new("scripts/items/accessory/warhound_item");
		warhound.m.Name = "Friend";
		items.equip(warhound);
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/goat_cheese_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/bread_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/misc/happy_powder_item"));
		this.World.Assets.m.Money = this.World.Assets.m.Money / 2 - (this.World.Assets.getEconomicDifficulty() == 0 ? 0 : 100);
		this.World.Assets.m.ArmorParts = 20;
		this.World.Assets.m.Medicine = 10;
		this.World.Assets.m.Ammo = 0;

	}

	function onSpawnPlayer()
	{
		local randomVillage;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
		{
			randomVillage = this.World.EntityManager.getSettlements()[i];

			if (randomVillage.isMilitary() && !randomVillage.isIsolatedFromRoads() && randomVillage.getSize() >= 3 && !randomVillage.isSouthern())
			{
				break;
			}
		}

		local randomVillageTile = randomVillage.getTile();

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 1), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 1));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 1), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 1));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) == 0)
				{
				}
				else if (!tile.HasRoad)
				{
				}
				else
				{
					randomVillageTile = tile;
					break;
				}
			}
		}
		while (1);

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(2);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/worldmap_02.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.executioner_scenario_intro");
		}, null);
	}

	function onCombatFinished()
	{
		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			if (bro.getFlags().get("IsPlayerCharacter"))
			{
				return true;
			}
		}

		return false;
	}

});

this.mastermind_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.mastermind_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_45.png[/img]{You will hire the best warriors you can find, but not too many because you need to control them. A bodyguard of ten obedient warriors should be enough. You already have two fine specimens. These morons will die for you if you order it. But you need smart men as well. You will look for them in the cities and garrisons, offer them money or a grand vision of the future or whatever it takes to persuade them to join. And then it\'s up to you to make their every move count. Every mistake might be your last, but what else is new? You have a few tricks up your sleeve. Eradicating opposition is your specialty, after all.\n\nIt\'s all theatre, but now you left your place behind the stage you must learn to blend in. You bought a special costume just for that purpose. You really think of everything.\n\n[color=#bcad8c]Outcome:[/color]+1 hat and tunic.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Time to prepare!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

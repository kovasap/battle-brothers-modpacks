this.maniac_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.maniac_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_135.png[/img]{The truth is: everyone is crazy, stark raving mad. Stuck in their silly little lives, dreaming about things they will never actually do. At least you slay the monsters from your nightmares. Like the normal crazy people, you have ups and downs. In one of the \'downs\' you cut out one of your eyes in order to see better. It\'s no loss. You just slash at whatever threat comes near you. You became pretty good at it.\n\nWandering alone across the northern wasteland you are approached by a bunch of barbarian thralls, ready to kill you. You scream and laugh in anticipation. They scream and laugh too. You jump up and down, they mimic you. This goes on for a while. The barbarians start arguing amongst themselves and then approach you with some reverence. They offer you an eye, a grisly alp trophy you add to your collection. You offer them the hairs of a witch in return. They seem impressed.\n\nIt\'s obvious they like you. They think you are a barbarian in all but name and blood. It\'s clear they want to accompany you, hunt together. You agree. You hunt together for a few days. Afterwards some of them leave. Those who remain have accepted you as their new chieftain, it seems. They keep a bit of distance from you and your sword, though. It does not bother you. They can stick around to hunt some, fight some, whatever you do to forget your fallen brothers and kill the time.\n\n[color=#bcad8c]Outcome:[/color]+6 barbarian thralls, +2 warhounds, +1 third eye.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Time to Kill!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Blind Fury";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

this.shepherd_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.shepherd_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_150.png[/img]{They follow you with expecting gazes. Most of them are harmless as lambs, knowing little of the world. Some revere you, others fear you. Most of them are hard working people, good natured but simple minded. They are convinced it\'s part of their existence they should suffer under the hands of unjust and cruel leaders, obsessed with their own interests. The viziers and noble lords are no different than common bandits and thugs. They should all be treated as outlaws and be hunted, captured or killed\n\nYou will lead by example and show your followers the Way. You will learn them how to channel all the repressed anger and resentment into something useful. In time they will rise up, wielding their instruments of death, and help you cut away the blackness from your adversaries, freeing them all. They will become like you. They will become like howling winds and scouring sands, under the blessing of the everlasting Light: the only shepherd you have ever known.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Follow me!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Dangerous freedom";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

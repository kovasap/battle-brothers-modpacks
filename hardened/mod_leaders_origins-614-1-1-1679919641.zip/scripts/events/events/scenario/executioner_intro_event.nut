this.executioner_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.executioner_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_27.png[/img]{The stupid animal keeps following you. What is it thinking? Does it not smell you are dangerous? It must be a stray. It's huge. The barbarians keep these kind of dogs. You hope the crazy warriors are not around. They might provoke you into killing them all.\n\nYou think about what your predecessor would do. You got his axe, a brutal and thirsty weapon, when he retired. \'Never hesitate, act\' he had said many times. You wave your arm. The dog comes over, looking expectantly at you. You give it a careful pat on the head. You don\'t mess with a dog like that. It will tear a goblin in two bloody halves. It seems to like the pat on the head.\n\nThe dog\'s still walking next to you, watching everything all the time. It might be useful. You decide to keep it. You can\'t think of a name so you call it \'Friend\'. Friends come and go, some die before you. The dog will die. Better to accept it now.\n\nIt's time to find some men. And after that... \n\n[color=#bcad8c]Outcome:[/color] +1 Warhound.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Time to chop!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Friend";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

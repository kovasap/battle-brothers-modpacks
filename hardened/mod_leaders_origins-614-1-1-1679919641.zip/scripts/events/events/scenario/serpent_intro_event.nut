this.serpent_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.serpent_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_150.png[/img]{Are you a bad person as your brother seems to insist, a \'serpent\'? Maybe. Maybe not. You stole the most beautiful woman from his harem when she fell for you, rigged gladiator games for fun, set free a slave who managed to beat you at a boardgame and strangled the servant who spied on you. You probably told more lies than truths.\n\nYou just want to enjoy life, short as it is, others can act all serious and responsible. To you it\'s just a game. Nothing matters except your freedom to choose, if there's such a thing at all.\n\nThe assassin works for you now, as long as you pay the greedy bastard. Same goes for the corrupt gladiator who enjoyed your protection in the city and now acts as your bodyguard. The slave you set free will be your guide. He is eager to leave the desert, and so are you. You will gather strength in the north, then return to the south to make peace or war, you are not sure yet. \n\nYou follow an old smuggling route, careful to keep out of sight. The vizier\'s men might show up at any moment. The gladiator and the assassin are arguing. Both are convinced to be the better killer. There will be plenty of opportunity for them to find out.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "To the North!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "The Great Escape";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

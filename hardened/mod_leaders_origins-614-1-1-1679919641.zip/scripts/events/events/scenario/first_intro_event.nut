this.first_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.first_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_16.png[/img]{You\'ve found the candidate Second near the forest, strangling an orc scout. An impressive feat. It took some convincing, and some goat cheese, to get the wildman to join you. Orcs had burned his home, so you proposed to kill a lot of orcs together. The wildman was clearly impressed by your gear. You told him, in time, the candidate Second will have his own gear and superior weapon, just like you. The candidate Second seemed to like that. The real Second does not die, you told him. The wildman told you he survived in the wild for a long time. You were pleased.\n\n You found the candidate Third in a tavern, buying rounds for everybody. The brawler just won the Fight Circle tournament for the fifth time. Apart from scabbed knuckles he seemed untouched. The brawler was looking for a new challenge. You offered one. The Brawler informed about pay. You came to an agreement. You told the candidate Third he needs a weapon. You offered him a mace. He refused at first but now he is happy to carry it. You are pleased.\n\nNow they must look for the Fourth, some armor, and some evil to eliminate.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Six more to go!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Second and Third";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

this.savage_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.savage_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_135.png[/img]{It has begun. Most of the villagers fled in time. Some are dead. Your men gather the loot and set the houses on fire. Just like the villagers, most of your kin are glad to see you go. Few share your vision, few were willing to join. It does not matter to you. The favor of the gods would have been enough. You would have gone alone but some have chosen to follow you: The \'Bear\', your only true friend, who would follow you to the grave and beyond if needs be; the old chieftain who supports your cause and, you suspect, longs for a glorious death; The grumpy beastmaster who's grown tired of taming unholds; the idiot, who fell on his head as a child, but is very proficient with his throwing axes; the young warrior who wants see something of the world and preferably not return to the village.\n\nThe old chieftain offers you a valuable gift, following your first victory: precious horns to add to an armor of your choosing. You carefully tuck it away in your pack. Time waits for no man, as they say. Better get moving.\n\n[color=#bcad8c]Outcome:[/color]+1 horn armor upgrade.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "To The South!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Odd Bunch";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

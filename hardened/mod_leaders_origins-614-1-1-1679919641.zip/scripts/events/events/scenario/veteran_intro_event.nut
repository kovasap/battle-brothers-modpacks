this.veteran_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.veteran_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_74.png[/img]{Maybe you drank a little too much. But still, it\'s a good day. It\'s the start of your business. What\'s your first step? Your companions look at you but you have no one to look up to, which is kinda nice. Guess it\'s up to you to decide.\n\nYou are sellswords now. There's no army behind you anymore. You will need to hire some experienced warriors. No sneaky poachers, or smelly fishermen will join your ranks. You will create an elite unit, your own little army.\n\n [color=#bcad8c]Outcome:[/color] +4 hangovers. ",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Here we come!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Happy Hangover";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

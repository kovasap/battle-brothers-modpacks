this.engineer_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.engineer_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_161.png[/img]{It\'s a good thing the vizier supports your expensive work, but you get tired of his demands. Your wife keeps complaining too. Maybe this time you will not return from your field trip but continue your rampage. Maybe this time you will finally go your own way. Your bodyguards will follow you as long as you pay them, although they were pretty loyal from the start. They seem to like the action as much as you do.\n\nYou start to get a little excited.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Time to blow stuff up!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Indefinite \'Fieldwork\'";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

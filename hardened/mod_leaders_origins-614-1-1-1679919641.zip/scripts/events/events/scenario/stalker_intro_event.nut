this.stalker_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.stalker_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_128.png[/img]{The old hunter taught you how to craft your own weapon. The bow, your most prized possession, has become a part of you. Your prowess with it is known and admired but you never show off or give demonstrations when asked. It has only one purpose. The hunter taught you other things, certain phrases like: \'the perfect shot comes from perfect stillness\'. It took you a while to grasp what he meant by that, or you think you do.\n\n The small brotherhood you lead is your responsibility. Some you regard as students, others as equals. Your master died years ago. You visit his grave at times, a quiet place between the trees. It\'s present during battle, the quiet. Your arrows fly from it, rip through it, striking surprised opponents. A short burst of chaos, then nothing.\n\nThere\'s too much noise in the world, idle talk and worse: the screeching of witches, the sinister mumbling of necromancers, the shouting of thugs and lunatics. Your enemies make a lot of noise. They need to be silenced, so peace may return.\n\n\n\n\n\n\n\nTip: It\'s not necessary to add the Lookout to your retinue.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Get moving!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Enjoy the Silence";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

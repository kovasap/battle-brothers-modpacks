this.grandmaster_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.grandmaster_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_79.png[/img]{You are still trying to absorb it all. In a coordinated action your fellow brothers were taken by surprise, imprisoned, tortured and killed. Your land and possessions were seized. Your attackers were probably scared of your power, jealous of your wealth. Thanks to the villagers willingness to hide you from the noble troops, you are still alive. Thanks to the foresight of the Seneschal you got some much needed supplies from a hidden cache.\n\nYou can\'t stay in the village without endangering the people. It\'s time to go. A few men are still recovering from their wounds. You worry about the squires, they did not receive much training. Every sword counts now. You can\'t afford to lose more men.\n\nThe villagers were complaining about nearby bandits, beasts and even undead. You will deal with the threats, get supplies from the bandit camps and treasure from the ruins. In time the nobles will start to fight among themselves and forget about you. The city states will want to trade. If you survive long enough you will be able to regain your strength and reputation. You will create a small, but elite, force and thrive again.\n\n[color=#bcad8c]Outcome:[/color] Start with extra tools and medical supplies. A few brothers are injured.\n\n\n Tip: city states will be available for trade and contracts earlier than the noble factions, unless provoked.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "In Thy Name. Glory or Death!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Recovery";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

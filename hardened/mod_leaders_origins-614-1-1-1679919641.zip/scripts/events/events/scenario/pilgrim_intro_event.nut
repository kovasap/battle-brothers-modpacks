this.pilgrim_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.pilgrim_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_101.png[/img]{This whole pilgrimage thing might prove interesting. The first night you made camp in a deserted barn. Lupe read the old tome the abbot gave him to gain information about their destination. Now he seems scared, rambling about an ancient empire, the undead and the \'Black Monolith\', whatever that is. Hedon had a drink, naturally. He clings to the other flask as well, the one the abott gave him. At least you got something useful. The remarkable flail already has a familiar feel to it. You might need it when you encounter the undead.\n\n You suspect the abbot wants to get rid of you but if so why the gifts? \'It\'s an initiation\' Lupe keeps repeating, whatever that means. He reads too much, as a result he is the worst fighter of the three. It might be wise to get others to join you on your pilgrimage.\n\nOne of the older monks told you about the famous arena in the south, where it\'s possible to challenge dangerous opponents and earn gold and prices. Nothing wrong with a little detour. A few fights along the way won\'t hurt, you have to keep in shape after all. Maybe try to kick the abbot\'s ass when you get back, and not be destroyed for once.\n\n[color=#bcad8c]Outcome:[/color] Lupe now has fear of undead trait.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Well, let's go then!",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "A Strange Pilgrimage";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});

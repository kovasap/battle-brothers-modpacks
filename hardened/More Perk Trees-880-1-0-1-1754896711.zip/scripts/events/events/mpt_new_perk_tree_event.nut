this.mpt_new_perk_tree_event <- this.inherit("scripts/events/event", {
	m = {
		Dude = null,
		Pg_To_Unlock = null,
		Pg_To_Unlock_Clean = null,
		VeteranPoints = -1
	},
	function create()
	{
		this.m.ID = "event.mpt_new_perk_tree";
		this.m.IsSpecial = true;
		this.m.Title = "Unlock Perk Trees";
		this.m.Cooldown = 0;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_82.png[/img]Through the experiences gained via a multitude of difficult battles, %dudeName% has the opportunity to learn new ways to defeat his enemies. \n\nWhat perk tree should %dudeName% unlock? (current Veteran Points: %veteranPoints%)",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Nevermind.",
					function getResult( _event )
					{
						return 0;
					}
				},
				{
					Text = "Weapon Perk Tree (1 Veteran Point)",
					function getResult( _event )
					{
						return "B";
					}
				},
				{
					Text = "Armor Perk Tree (1 Veteran Points)",
					function getResult( _event )
					{
						return "C";
					}
				},
				{
					Text = "Fighting Style Perk Tree (1 Veteran Points)",
					function getResult( _event )
					{
						return "D";
					}
				},
				{
					Text = "Special Perk Tree (2 Veteran Points)",
					function getResult( _event )
					{
						return "E";
					}
				},
				{
					Text = "Shared Perk Tree (2 Veteran Points)",
					function getResult( _event )
					{
						return "F";
					}
				},
				{
					Text = "Exclusive Perk Tree (2 Veteran Points)",
					function getResult( _event )
					{
						return "G";
					}
				}
			],
			function start( _event )
			{
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_swordmaster") && _event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_sword"))
				{
					this.Options.push({
						Text = "Swordmaster Perk Tree (3 Veteran Points)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 3)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -3);
								_event.m.VeteranPoints -= 3;
								_event.m.Pg_To_Unlock = "pg.rf_swordmaster";
								_event.m.Pg_To_Unlock_Clean = "Swordmaster";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				_event.m.Dude.getSkills().removeByID("effects.choose_bro_for_mpt");
				this.Characters.push(_event.m.Dude.getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "B",
			Text = "Which Weapon perk tree should %dudeName% learn? Current Veteran Points: %veteranPoints%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Nevermind.",
					function getResult( _event )
					{
						return 0;
					}
				}
			],
			function start( _event )
			{
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_axe"))
				{
					this.Options.push({
						Text = "Axe Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_axe";
								_event.m.Pg_To_Unlock_Clean = "Axe";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_bow"))
				{
					this.Options.push({
						Text = "Bow Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_bow";
								_event.m.Pg_To_Unlock_Clean = "Bow";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_cleaver"))
				{
					this.Options.push({
						Text = "Cleaver Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_cleaver";
								_event.m.Pg_To_Unlock_Clean = "Cleaver";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_crossbow"))
				{
					this.Options.push({
						Text = "Crossbow Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_crossbow";
								_event.m.Pg_To_Unlock_Clean = "Crossbow";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_dagger"))
				{
					this.Options.push({
						Text = "Dagger Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_dagger";
								_event.m.Pg_To_Unlock_Clean = "Dagger";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_flail"))
				{
					this.Options.push({
						Text = "Flail Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_flail";
								_event.m.Pg_To_Unlock_Clean = "Flail";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_hammer"))
				{
					this.Options.push({
						Text = "Hammer Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_hammer";
								_event.m.Pg_To_Unlock_Clean = "Hammer";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_mace"))
				{
					this.Options.push({
						Text = "Mace Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_mace";
								_event.m.Pg_To_Unlock_Clean = "Mace";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_polearm"))
				{
					this.Options.push({
						Text = "Polearm Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_polearm";
								_event.m.Pg_To_Unlock_Clean = "Polearm";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_spear"))
				{
					this.Options.push({
						Text = "Spear Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_spear";
								_event.m.Pg_To_Unlock_Clean = "Spear";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_sword"))
				{
					this.Options.push({
						Text = "Sword Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_sword";
								_event.m.Pg_To_Unlock_Clean = "Sword";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_throwing"))
				{
					this.Options.push({
						Text = "Throwing Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_throwing";
								_event.m.Pg_To_Unlock_Clean = "Throwing";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				this.Characters.push(_event.m.Dude.getImagePath());
			}
		});
		this.m.Screens.push({
			ID = "C",
			Text = "Which Armor perk tree should %dudeName% learn? Current Veteran Points: %veteranPoints%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Nevermind.",
					function getResult( _event )
					{
						return 0;
					}
				}
			],
			function start( _event )
			{
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_light_armor"))
				{
					this.Options.push({
						Text = "Light Armor Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_light_armor";
								_event.m.Pg_To_Unlock_Clean = "Light Armor";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_medium_armor"))
				{
					this.Options.push({
						Text = "Medium Armor Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_medium_armor";
								_event.m.Pg_To_Unlock_Clean = "Medium Armor";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_heavy_armor"))
				{
					this.Options.push({
						Text = "Heavy Armor Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_heavy_armor";
								_event.m.Pg_To_Unlock_Clean = "Heavy Armor";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				this.Characters.push(_event.m.Dude.getImagePath());
			}
		});
		this.m.Screens.push({
			ID = "D",
			Text = "Which Fighting Style perk tree should %dudeName% learn? Current Veteran Points: %veteranPoints%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Nevermind.",
					function getResult( _event )
					{
						return 0;
					}
				}
			],
			function start( _event )
			{
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_power"))
				{
					this.Options.push({
						Text = "Powerful Strikes Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_power";
								_event.m.Pg_To_Unlock_Clean = "Powerful Strikes";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_ranged"))
				{
					this.Options.push({
						Text = "Ranged Combat Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_ranged";
								_event.m.Pg_To_Unlock_Clean = "Ranged Combat";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_shield"))
				{
					this.Options.push({
						Text = "Shield Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_shield";
								_event.m.Pg_To_Unlock_Clean = "Shield";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_swift"))
				{
					this.Options.push({
						Text = "Swift Strikes Perk Group (1 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 1)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -1);
								_event.m.VeteranPoints -= 1;
								_event.m.Pg_To_Unlock = "pg.rf_swift";
								_event.m.Pg_To_Unlock_Clean = "Swift Strikes";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				this.Characters.push(_event.m.Dude.getImagePath());
			}
		});
		this.m.Screens.push({
			ID = "E",
			Text = "Which Special perk tree should %dudeName% learn? Current Veteran Points: %veteranPoints%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Nevermind.",
					function getResult( _event )
					{
						return 0;
					}
				}
			],
			function start( _event )
			{
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.special.rf_back_to_basics"))
				{
					this.Options.push({
						Text = "Back to Basics Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.special.rf_back_to_basics";
								_event.m.Pg_To_Unlock_Clean = "Back to Basics";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.special.rf_discovered_talent"))
				{
					this.Options.push({
						Text = "Discovered Talent Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.special.rf_discovered_talent";
								_event.m.Pg_To_Unlock_Clean = "Discovered Talent";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.special.rf_fencer"))
				{
					this.Options.push({
						Text = "Fencer Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.special.rf_fencer";
								_event.m.Pg_To_Unlock_Clean = "Fencer";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.special.rf_gifted"))
				{
					this.Options.push({
						Text = "Gifted Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.special.rf_gifted";
								_event.m.Pg_To_Unlock_Clean = "Gifted";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.special.rf_leadership"))
				{
					this.Options.push({
						Text = "Leadership Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.special.rf_leadership";
								_event.m.Pg_To_Unlock_Clean = "Leadership";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.special.rf_man_of_steel"))
				{
					this.Options.push({
						Text = "Man of Steel Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.special.rf_man_of_steel";
								_event.m.Pg_To_Unlock_Clean = "Man of Steel";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.special.rf_marksmanship"))
				{
					this.Options.push({
						Text = "Marksmanship Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.special.rf_marksmanship";
								_event.m.Pg_To_Unlock_Clean = "Marksmanship";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.special.rf_professional"))
				{
					this.Options.push({
						Text = "Professional Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.special.rf_professional";
								_event.m.Pg_To_Unlock_Clean = "Professional";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.special.rf_rising_star"))
				{
					this.Options.push({
						Text = "Rising Star Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.special.rf_rising_star";
								_event.m.Pg_To_Unlock_Clean = "Rising Star";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.special.rf_student"))
				{
					this.Options.push({
						Text = "Student Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.special.rf_student";
								_event.m.Pg_To_Unlock_Clean = "Student";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				this.Characters.push(_event.m.Dude.getImagePath());
			}
		});
		this.m.Screens.push({
			ID = "F",
			Text = "Which Shared perk tree should %dudeName% learn? Current Veteran Points: %veteranPoints%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Nevermind.",
					function getResult( _event )
					{
						return 0;
					}
				}
			],
			function start( _event )
			{
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_agile"))
				{
					this.Options.push({
						Text = "Agile Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_agile";
								_event.m.Pg_To_Unlock_Clean = "Agile";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_fast"))
				{
					this.Options.push({
						Text = "Fast Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_fast";
								_event.m.Pg_To_Unlock_Clean = "Fast";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_tough"))
				{
					this.Options.push({
						Text = "Tough Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_tough";
								_event.m.Pg_To_Unlock_Clean = "Tough";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_vigorous"))
				{
					this.Options.push({
						Text = "Vigorous Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_vigorous";
								_event.m.Pg_To_Unlock_Clean = "Vigorous";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_tactician"))
				{
					this.Options.push({
						Text = "Tactician Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_tactician";
								_event.m.Pg_To_Unlock_Clean = "Tactician";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_trained"))
				{
					this.Options.push({
						Text = "Trained Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_trained";
								_event.m.Pg_To_Unlock_Clean = "Trained";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_unstoppable"))
				{
					this.Options.push({
						Text = "Unstoppable Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_unstoppable";
								_event.m.Pg_To_Unlock_Clean = "Unstoppable";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_vicious"))
				{
					this.Options.push({
						Text = "Vicious Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_vicious";
								_event.m.Pg_To_Unlock_Clean = "Vicious";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				this.Characters.push(_event.m.Dude.getImagePath());
			}
		});
		this.m.Screens.push({
			ID = "G",
			Text = "Which Exclusive perk tree should %dudeName% learn? Current Veteran Points: %veteranPoints%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Nevermind.",
					function getResult( _event )
					{
						return 0;
					}
				}
			],
			function start( _event )
			{
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_knave"))
				{
					this.Options.push({
						Text = "Knave Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_knave";
								_event.m.Pg_To_Unlock_Clean = "Knave";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_laborer"))
				{
					this.Options.push({
						Text = "Laborer Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_laborer";
								_event.m.Pg_To_Unlock_Clean = "Laborer";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_militia"))
				{
					this.Options.push({
						Text = "Militia Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_militia";
								_event.m.Pg_To_Unlock_Clean = "Militia";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_noble"))
				{
					this.Options.push({
						Text = "Noble Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_noble";
								_event.m.Pg_To_Unlock_Clean = "Noble";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_pauper"))
				{
					this.Options.push({
						Text = "Pauper Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_pauper";
								_event.m.Pg_To_Unlock_Clean = "Pauper";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_raider"))
				{
					this.Options.push({
						Text = "Raider Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_raider";
								_event.m.Pg_To_Unlock_Clean = "Raider";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_soldier"))
				{
					this.Options.push({
						Text = "Soldier Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_soldier";
								_event.m.Pg_To_Unlock_Clean = "Soldier";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_wildling"))
				{
					this.Options.push({
						Text = "Wildling Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_wildling";
								_event.m.Pg_To_Unlock_Clean = "Wildling";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				if(!_event.m.Dude.getPerkTree().hasPerkGroup("pg.rf_trapper"))
				{
					this.Options.push({
						Text = "Trapper Perk Group (2 VP)",
						function getResult( _event )
						{
							if(_event.m.VeteranPoints >= 2)
							{
								_event.m.Dude.m.Flags.increment("mpt_veteran_points", -2);
								_event.m.VeteranPoints -= 2;
								_event.m.Pg_To_Unlock = "pg.rf_trapper";
								_event.m.Pg_To_Unlock_Clean = "Trapper";
								return "UNLOCK";
							}
							else
							{
								return "POOR";
							}
						}
					});
				}
				this.Characters.push(_event.m.Dude.getImagePath());
			}
		});
		this.m.Screens.push({
			ID = "POOR",
			Text = "%dudeName% does not have enough Veteran Points to learn that. Current Veteran Points: %veteranPoints%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "I\'ll be back.",
					function getResult( _event )
					{
						return 0;
					}
				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.Dude.getImagePath());
			}
		});
		this.m.Screens.push({
			ID = "UNLOCK",
			Text = "%dudeName% has gained the %unlockedPG% perk group! Veteran Points remaining: %veteranPoints%",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Let\'s see it in action.",
					function getResult( _event )
					{
						_event.m.Dude.getPerkTree().addPerkGroup(_event.m.Pg_To_Unlock);
						return 0;
					}
				}
			],
			function start( _event )
			{
				this.Characters.push(_event.m.Dude.getImagePath());
			}

		});
	}

	function onUpdateScore()
	{
		local brothers = this.World.getPlayerRoster().getAll();
		local candidates = [];
		foreach (bro in brothers)
		{
			if (bro.getSkills().hasSkill("effects.choose_bro_for_mpt"))
			{
				candidates.push(bro);
			}
		}
		if (candidates.len() == 0)
		{
			candidates = brothers;
		}
		local rr = this.Math.rand(0, candidates.len() - 1);
		this.m.Dude = candidates[rr];
		this.m.VeteranPoints = (this.m.Dude.m.Flags.get("mpt_veteran_points") || 0);
	}

	function onPrepare()
	{
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"dudeName",
			this.m.Dude.getName()
		]);
		_vars.push([
			"unlockedPG",
			this.m.Pg_To_Unlock_Clean
		]);
		_vars.push([
			"veteranPoints",
			this.m.VeteranPoints
		]);
	}

	function onClear()
	{
		this.m.Dude = null;
	}
});

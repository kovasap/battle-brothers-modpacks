::modMorePerkTrees <- {
	Version = "1.0.1",
	ID = "morePerkTrees",
	Name = "More Perk Trees",
};

::modMorePerkTrees.HooksMod <- ::Hooks.register(::modMorePerkTrees.ID, ::modMorePerkTrees.Version, ::modMorePerkTrees.Name);

::modMorePerkTrees.HooksMod.queue(">mod_msu", function() {

	::modMorePerkTrees.Mod <- ::MSU.Class.Mod(::modMorePerkTrees.ID, ::modMorePerkTrees.Version, ::modMorePerkTrees.Name);

	::mods_registerJS("mod_mpt.js");
	::mods_registerCSS("mod_mpt.css");

	local page = ::modMorePerkTrees.Mod.ModSettings.addPage("General");
    local function add(elem) {
        page.addElement(elem);
    }
    ::modMorePerkTrees.conf <- function(name) {
        return ::modMorePerkTrees.Mod.ModSettings.getSetting(name).getValue();
    }

    add(::MSU.Class.RangeSetting("vetFreq", 5, 3, 10, 1, "Veteran Point Frequency",
        "The frequency (in levels) that bros will gain veteran points. First veteran point is gained at level (1 + frequency), and each subsequent point is gained (frequency) levels later. For example, with default frequency of 5, veteran points are gained at levels 6, 11, 16, etc."
    ));

	::modMorePerkTrees.HooksMod.hook("scripts/skills/backgrounds/character_background", function(q) {

		q.onUpdateLevel = @(__original) function( )
		{
			__original( );
			
			local actor = this.getContainer().getActor();
			
			if(actor.getLevel() % ::modMorePerkTrees.conf("vetFreq") == 1)
			{
				actor.m.Flags.increment("mpt_veteran_points");
			}
		}
	});

	::modMorePerkTrees.HooksMod.hook("scripts/ui/screens/world/modules/world_town_screen/town_training_dialog_module", function(q) {

		q.queryRosterInformation = @(__original) function( )
		{
			local ret = __original( );
			
			foreach (bro in ret.Roster)
			{
				local actor = this.Tactical.getEntityByID(bro.ID);
				//I'm sure there's a better way of doing this, but I was having trouble since 0 == false in squirrel
				if("" + actor.m.Flags.get("mpt_veteran_points") == "false")
				{
					local vetPts = Math.floor((actor.getLevel()-1)/::modMorePerkTrees.conf("vetFreq"));
					if(vetPts < 0)
					{
						vetPts = 0;
					}
					actor.m.Flags.set("mpt_veteran_points", vetPts);
				}
				bro.Training.push({
					id = 11,
					icon = "skills/status_effect_73.png",
					name = "Spend Veteran Points",
					tooltip = "mpt_spend_veteran_points_tooltip",
					price = actor.m.Flags.get("mpt_veteran_points")
				});
			}

			local brothers = this.World.getPlayerRoster().getAll();

			foreach( b in brothers )
			{
				if (b.getLevel() >= 11 || (b.getLevel() >= 7 && this.World.Assets.getOrigin().getID() == "scenario.manhunters" && b.getBackground().getID() == "background.slave") || b.getSkills().hasSkill("effects.trained"))
				{
					local background = b.getBackground();
					local e = {
						ID = b.getID(),
						Name = b.getName(),
						Level = b.getLevel(),
						ImagePath = b.getImagePath(),
						ImageOffsetX = b.getImageOffsetX(),
						ImageOffsetY = b.getImageOffsetY(),
						BackgroundImagePath = background.getIconColored(),
						BackgroundText = background.getDescription(),
						Training = [],
						Effects = []
					};
					//I'm sure there's a better way of doing this, but I was having trouble since 0 == false in squirrel
					if("" + b.m.Flags.get("mpt_veteran_points") == "false")
					{
						local vetPts = Math.floor((b.getLevel()-1)/::modMorePerkTrees.conf("vetFreq"));
						if(vetPts < 0)
						{
							vetPts = 0;
						}
						b.m.Flags.set("mpt_veteran_points", vetPts);
					}
					e.Training.push({
						id = 11,
						icon = "skills/status_effect_73.png",
						name = "Spend Veteran Points",
						tooltip = "mpt_spend_veteran_points_tooltip",
						price = b.m.Flags.get("mpt_veteran_points")
					});
					ret.Roster.push(e);
				}
			}
			return ret;
		}

		q.onTrain = @(__original) function( _data )
		{
			local entityID = _data[0];
			local trainingID = _data[1];
			if(trainingID == 11)
			{
				local entity = this.Tactical.getEntityByID(entityID);
				entity.getSkills().add(this.new("scripts/skills/effects/choose_bro_for_mpt_effect"));
				::World.State.getMenuStack().popAll(true);
				::World.Events.fire("event.mpt_new_perk_tree");

				//this is unnecessary, but it prevents a JS error from being thrown in the log
				local background = entity.getBackground();
				local e = {
					ID = entity.getID(),
					Name = entity.getName(),
					Level = entity.getLevel(),
					ImagePath = entity.getImagePath(),
					ImageOffsetX = entity.getImageOffsetX(),
					ImageOffsetY = entity.getImageOffsetY(),
					BackgroundImagePath = background.getIconColored(),
					BackgroundText = background.getDescription(),
					Training = [],
					Effects = []
				};
				local r = {
					Entity = e,
					Assets = this.m.Parent.queryAssetsInformation()
				};
				return r;
			}
			return __original( _data );
		}
	});

	::modMorePerkTrees.HooksMod.hook("scripts/ui/screens/tooltip/tooltip_events", function(q) {

		q.general_queryUIElementTooltipData = @(__original) function( _entityId, _elementId, _elementOwner )
		{
			if(_elementId == "mpt_spend_veteran_points_tooltip")
			{
				return [
					{
						id = 1,
						type = "title",
						text = "Spend Veteran Points"
					},
					{
						id = 2,
						type = "description",
						text = "Spend veteran points to gain access to additional perk trees. Bros gain a veteran point every " + ::modMorePerkTrees.conf("vetFreq") + " levels, starting at level " + (::modMorePerkTrees.conf("vetFreq") + 1) + "."
					}
				];
			}
			return __original( _entityId, _elementId, _elementOwner );
		}

	});

}, ::Hooks.QueueBucket.Late);

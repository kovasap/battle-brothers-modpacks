::Reforged.HooksMod.hook("scripts/skills/actives/demolish_armor_skill", function(q) {
	q.create = @(__original) { function create()
	{
		__original();

		// Add Blunt Damage type to the skill so it works properly with perks
		// that require Blunt damage. In vanilla this skill doesn't apply
		// any injuries so MSU adds DamageType.None to such skills.
		if (this.m.DamageType.len() == 0 || this.m.DamageType.len() == 1 && this.m.DamageType.contains(::Const.Damage.DamageType.None))
		{
			this.m.DamageType.remove(::Const.Damage.DamageType.None);
			this.m.DamageType.add(::Const.Damage.DamageType.Blunt);
		}
	}}.create;
});

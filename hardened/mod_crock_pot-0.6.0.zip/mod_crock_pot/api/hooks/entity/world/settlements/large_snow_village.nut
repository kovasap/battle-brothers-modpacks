::CrockPot.HooksMod.hook("scripts/entity/world/settlements/large_snow_village", function(q) {
// CrockPot Functions
	q.CP_getApplicableRandomSituations = @(__original) function()
	{
		local ret = __original();

		ret.add("snow_storms_situation", 12);

		return ret;
	}
});

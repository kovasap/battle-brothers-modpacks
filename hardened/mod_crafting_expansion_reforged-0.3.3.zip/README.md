
## Major Changes

https://docs.google.com/spreadsheets/d/18TIV0loYlzKny5q_7UKV7PJ38nORaduPnLgzn2gFjY4/edit?gid=0#gid=0


Added new crafting recipes:

Mysterious Jug: 
- Gives 1 perk when used - uses Potion of Oblivion Recipe

Potion of Oblivion
- Greatly simplified recipe

Potion of Wolf Step
- Grants Pathfinder perk to the user.

Holy Water
- just like the Tool obtained in the Event

Water Jug
- Like the Foutain of youth event
